#pragma once

#include <cstdint>
#include <vector>

namespace rts {

struct RightLookingExecutorInfo final {
  std::size_t n_ready_inputs = 0;
  bool reduction_barrier_task = false;
  inline void reset() { n_ready_inputs = 0; }
};

inline void Serialize(const RightLookingExecutorInfo& info, std::vector<std::uint64_t>& buffer) {
  buffer.push_back(info.n_ready_inputs);
}

} // namespace rts