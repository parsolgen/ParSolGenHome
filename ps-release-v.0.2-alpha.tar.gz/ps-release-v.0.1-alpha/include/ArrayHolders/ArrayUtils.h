#pragma once

#include "Task/Task.h"

#include <cassert>

namespace rts
{

template<ArrayDim N>
inline
ArrayDimSize get_array_length(const ArrayDimensions<N>& dims)
{
    if constexpr (N == 1) {
        return dims[0];
    }
    if constexpr (N == 2) {
        return dims[0] * dims[1];
    }
    if constexpr (N == 3) {
        return dims[0] * dims[1] * dims[2];
    }
    assert(false);
    return 0;
}

} // namespace rts
