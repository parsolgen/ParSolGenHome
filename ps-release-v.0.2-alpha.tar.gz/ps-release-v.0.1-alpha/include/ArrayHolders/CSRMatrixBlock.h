#pragma once

namespace rts
{

template <typename I, typename A>
struct CSRMatrixBlock final {
  I* ia;
  I* ja;
  A* a;
  I i;
  I j;
  I n;
  I m;
  I nnz;

  CSRMatrixBlock() = delete;
};

} // namespace rts
