#pragma once

#include "Mpi/Mpi.h"
#include "TaskGraphDistributors/Types.h"

namespace rts
{

class TaskGraph;

using BlockCyclicDistribution = std::vector<int>;
using LocalElements = std::unordered_set<ArrayElementCoordinates<2>>;

ArrayDimensions<2> get_local_block_cyclic_area_dims(
    const ArrayDimensions<2>& glob_dims,
    const comm::ProcessCoordinates<2>& comm_coords,
    const comm::ProcessCoordinates<2>& comm_dims);

LocalElements get_block_cyclic_local_elements(
    const ArrayDimensions<2>& area_dims,
    const comm::ProcessCoordinates<2>& comm_coords,
    const comm::ProcessCoordinates<2>& comm_dims);

BlockCyclicDistribution build_block_cyclic_distribution(
    const ArrayDimensions<2>& area_dims,
    const comm::ProcessCoordinates<2>& comm_dims,
    MPI_Comm comm);

ArrayElementCoordinates<2> block_cyclic_glob_to_loc_coord(
    const ArrayElementCoordinates<2>& coords,
    const comm::ProcessCoordinates<2>& comm_dims);

ArrayElementCoordinates<2> block_cyclic_loc_to_glob_coord(
    const ArrayElementCoordinates<2>& coords,
    const comm::ProcessCoordinates<2>& comm_coords,
    const comm::ProcessCoordinates<2>& comm_dims);

bool is_element_local_in_block_cyclic_area(
    const ArrayElementCoordinates<2>& glob_coords,
    const comm::ProcessCoordinates<2>& comm_coords,
    const comm::ProcessCoordinates<2>& comm_dims);

class BlockCyclicTaskGraphDistributor final
{
public:
    BlockCyclicTaskGraphDistributor(
        ArrayDimensions<2> area_dims,
        comm::ProcessCoordinates<2> comm_coords,
        comm::ProcessCoordinates<2> comm_dims,
        MPI_Comm comm);

    TaskGraphDistribution operator()(
        const TaskGraph& task_graph,
        int np) const noexcept;

private:
    int ncart_dims_;
    ArrayDimensions<2> area_dims_;
    comm::ProcessCoordinates<2> comm_coords_;
    comm::ProcessCoordinates<2> comm_dims_;
    MPI_Comm comm_;
};

} // namespace rts
