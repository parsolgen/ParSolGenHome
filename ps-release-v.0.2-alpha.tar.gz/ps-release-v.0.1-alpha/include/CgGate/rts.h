#pragma once

#include "TaskGraphProblem.h"
#include "TaskGraphProblemHolder.h"
#include "DeclareVector.h"
#include "Matrix.h"
#include "BlockCyclicTaskGraphDistributor.h"
#include "SparseDomainTaskGraphDistributor.h"
#include "TaskGraphUtils.h"
#include "TaskGraphsController.h"
#include "Utils.h"

#include "Mpi/Mpi.h"
#include "Task/Task.h"
#include "ArrayHolders/CSRMatrixBlock.h"
#include "ArrayHolders/TmpContiguousArray.h"
#include "ArrayHolders/ContiguousArray.h"
#include "Executors/RightLookingExecutorInfo.h"
#include "Comm/Utils.h"

#include "Algorithms/Max.h"
#include "VectorUtils/VectorUtils.h"

namespace rts
{
namespace comm
{

int get_comm_size(MPI_Comm comm);

} // namespace comm

namespace internal
{

void parse_command_line_args(int argc, char** argv);
void register_dd_vec(ArrayKey id, std::size_t size);
void set_tg_vec_local_elem(const TaskArgument& arg);

using InternalTask = std::function<void(std::size_t)>;
void exec_thread_specific_task(std::size_t tid, InternalTask task);
std::size_t get_n_threads();
void exec_task(InternalTask t);
void register_tg_related_vec(ArrayKey dst);

} // namespace internal

void register_matrix(int rank, MPI_Comm comm, const BlockedCSRMatrixSI& m);
void register_matrix(int rank, MPI_Comm comm, const BlockedCSRMatrixDI& m);

bool is_zero(const BlockedCSRMatrixSI& m, const TaskArgument& arg);
bool is_zero(const BlockedCSRMatrixDI& m, const TaskArgument& arg);

std::vector<std::string> get_command_line_args();

void abort();

bool is_vec_elem_local(const TaskArgument& arg);

void init_thread_pool();

void stop_threads();

std::size_t declare_tgp(TaskGraphProblemHolder&& p);

bool is_tgp_already_declared(std::size_t id);

void reset_tgp(std::size_t id);

void reset_tgp_inside_iter_loop(std::size_t id);

void ref_tgp_in_var(std::size_t id, const TaskArgument& arg);

void ref_tgp_out_var(std::size_t id, const TaskArgument& arg);

void register_tgp(std::size_t id);

void exec_tgp_and_wait(std::size_t id);

} // namespace rts
