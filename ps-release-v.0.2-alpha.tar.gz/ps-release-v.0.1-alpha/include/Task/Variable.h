#pragma once

#include <array>
#include <cstdint>

#include "Utils/HashCombine.h"

namespace rts {

using ArrayElementCoord = std::size_t;

using ArrayDimSize = std::size_t;

using ArrayDim = std::uint16_t;

template <ArrayDim N>
using ArrayElementCoordinates = std::array<ArrayElementCoord, N>;

template <ArrayDim N>
using ArrayDimensions = std::array<ArrayDimSize, N>;

using ArrayKey = std::uint32_t;

using ElementVersion = std::size_t;

} // namespace rts

namespace std {

template <>
struct hash<rts::ArrayElementCoordinates<2>> final {
  size_t operator()(const rts::ArrayElementCoordinates<2>& el) const {
    size_t res = 0;
    utils::hash_combine(res, el[0]);
    utils::hash_combine(res, el[1]);
    return res;
  }
};

template <>
struct hash<rts::ArrayElementCoordinates<3>> final {
  size_t operator()(const rts::ArrayElementCoordinates<2>& el) const {
    size_t res = 0;
    utils::hash_combine(res, el[0]);
    utils::hash_combine(res, el[1]);
    utils::hash_combine(res, el[2]);
    return res;
  }
};

} // namespace std