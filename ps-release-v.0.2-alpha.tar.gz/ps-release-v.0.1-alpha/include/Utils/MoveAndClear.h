#pragma once

#include <type_traits>

namespace utils
{

template<typename T>
std::remove_reference_t<T>&& move_and_clear(T&& value);

} // namespace utils

#include "MoveAndClear.inl"
