#pragma once

namespace utils {

template <class... Ts>
struct overloaded : Ts... {
  using Ts::operator()...;
};
template <class... Ts>
overloaded(Ts...) -> overloaded<Ts...>;

template <class... Ts>
overloaded<Ts...> make_overloaded(Ts&&... args) {
  return overloaded{std::forward<Ts>(args)...};
}

} // namespace utils