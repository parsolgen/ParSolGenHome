#pragma once

#include <type_traits>
#include <cstdint>

namespace utils {

template <typename T>
int mpi_size_cast(T value);

template <typename T>
std::size_t cast_to_size(T value);

template <typename T>
T cast_to_int(std::size_t value);

template <typename E>
std::underlying_type_t<E> enum_underlying_cast(E value);

template <typename D, typename S, std::enable_if_t<!std::is_pointer_v<S> and !std::is_pointer_v<D>, int>>
D& cast_to_derived(S& value);

template <typename D, typename S, std::enable_if_t<std::is_pointer_v<S> and std::is_pointer_v<D>, int>>
D cast_to_derived(S value);

} // namespace utils

#include "Cast.inl"