#pragma once

#include <tuple>

namespace utils
{

template<typename F, typename... Ts>
void for_each(F op, std::tuple<Ts...>& tuple);

template<typename F, typename... Ts>
void for_each(F op, const std::tuple<Ts...>& tuple);

template<typename F, typename... Ts>
void for_each_if(F op, std::tuple<Ts...>& tuple);

template<typename F, typename... Ts>
void for_each_if(F op, const std::tuple<Ts...>& tuple);

template<typename F, typename... Ts>
void for_each(F op, Ts&... args);

template<typename F, typename... Ts>
void for_each(F op, const Ts&... args);


} // namespace utils

#include "ForEach.inl"
