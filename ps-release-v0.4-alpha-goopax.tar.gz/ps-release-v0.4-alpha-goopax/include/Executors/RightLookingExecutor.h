#pragma once

#include "IExecutor.h"

#include "Task/TaskGraph.h"
#include "TaskQueue/BWTaskQueue.h"
#ifdef SG_USE_ACCEL
#include "DeviceUtils/Fwd.h"
#include "TaskQueue/PrioritizedBWTaskQueueDev.h"
#endif

#include <atomic>
#include <condition_variable>
#include <mutex>

namespace rts
{

class TaskGraphProblem;

class RightLookingExecutor final : public IExecutor
{
public:
    RightLookingExecutor(
        TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
        TaskGraph local_graph,
        std::size_t nthreads);

    RightLookingExecutor(
        std::size_t n_arrays,
        ArrayDimSize n1,
        ArrayDimSize n2,
#ifdef SG_USE_ACCEL
        const TaskGraphProblem& tgp,
#endif
        TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
        TaskGraph local_graph,
        std::size_t nthreads);

public: // public IExecutor
    virtual void wait() override;

    virtual void ready_var(const TaskArgument& var) override;

    virtual void start() override;

    virtual void set_ready_task_handler(OnReadyTask handler) override;

    virtual void ready_task(Task& task) override;

    virtual void stop() override;

    virtual void reset() override;

public:
    void received_var(const TaskArgument& var);

    BWTaskQueue& get_task_queue();

private:
    void execute_task(Task& t);

private:
    TaskGraph local_task_graph_;
    std::size_t nthreads_;
    BWTaskQueue task_queue_;
    OnReadyTask ready_task_handler_;
    std::atomic<std::size_t> executed_tasks_;
    std::atomic<bool> running_ = false;
    std::mutex mutex_;
#ifdef SG_USE_ACCEL
    std::unique_ptr<IDeviceScheduler> devices_scheduler_;
#endif
#ifdef SG_USE_GOOPAX
    PrioritizedBWTaskQueueDev goopax_task_queue_;
#endif
};

} // namespace rts
