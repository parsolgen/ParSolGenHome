#pragma once

#include "CSRSlaeSolverLikeAlgorithmGraphDistributor.h"

namespace rts {

template <typename W>
TaskGraphDistribution DistributeCSRSlaeSolverLikeAlgorithmGraph(const TaskGraph& graph, W&& vertex_weight) {
  TaskGraphDistribution result(graph.size());

  return result;
}

} // namespace rts