#pragma once

#include <array>
#include <cassert>
#include <limits>

namespace rts
{
enum class DriverType : int
{
    Cpu = 0,
#ifdef SG_USE_GOOPAX
    Goopax,
#endif
#ifdef SG_USE_CUDA
    Cuda,
#endif
    Last
};

using DeviceId = std::size_t;

static constexpr const DeviceId cpu_dev_id = 0;
static constexpr const std::size_t max_n_devices = 100;
static constexpr const DeviceId no_device_id = std::numeric_limits<DeviceId>::max();

using DeviceIds = std::array<DeviceId, max_n_devices>;

enum class DeviceDataType
{
    Int,
    Float,
    Double,
    CSRBlockSI,
    CSRBlockDI,
    Unknown
};

template<typename T>
struct cpp_type_to_device_dtp final
{
};

template<>
struct cpp_type_to_device_dtp<double> final
{
    static constexpr DeviceDataType value = DeviceDataType::Double;
};

template<>
struct cpp_type_to_device_dtp<float> final
{
    static constexpr DeviceDataType value = DeviceDataType::Float;
};

template<>
struct cpp_type_to_device_dtp<int> final
{
    static constexpr DeviceDataType value = DeviceDataType::Int;
};

template<typename T>
constexpr DeviceDataType cpp_type_to_device_dtp_v = cpp_type_to_device_dtp<T>::value;

template<DeviceDataType DTP>
struct device_dtp_to_cpp final
{
};

template<>
struct device_dtp_to_cpp<DeviceDataType::Double> final
{
    using type = double;
};


template<>
struct device_dtp_to_cpp<DeviceDataType::Float> final
{
    using type = float;
};

template<>
struct device_dtp_to_cpp<DeviceDataType::Int> final
{
    using type = int;
};

[[nodiscard]]
inline
std::size_t get_dev_dtp_byte_size(DeviceDataType dtp)
{
    switch (dtp)
    {
    case DeviceDataType::Int:
        return sizeof(int);
    case DeviceDataType::Float:
        return sizeof(float);
    case DeviceDataType::Double:
        return sizeof(double);
    
    default:
        assert(false);
        return 0;
    }
}

[[nodiscard]]
inline
bool is_csr_block_dtp(DeviceDataType dtp)
{
    return dtp == DeviceDataType::CSRBlockDI
        || dtp == DeviceDataType::CSRBlockSI;
}

} // namespace rts
