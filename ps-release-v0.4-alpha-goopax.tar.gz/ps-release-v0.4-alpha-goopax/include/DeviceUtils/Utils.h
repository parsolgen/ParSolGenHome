#pragma once

#include "Task/Task.h"

namespace rts
{

std::size_t get_var_byte_size(const TaskArgument& var);
std::size_t get_vars_total_size(const std::vector<TaskArgument>& vars);
std::size_t get_task_total_size(const Task& task);

} // namespace rts
