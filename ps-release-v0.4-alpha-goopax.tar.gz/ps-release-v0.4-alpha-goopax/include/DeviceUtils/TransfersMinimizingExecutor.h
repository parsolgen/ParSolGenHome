#pragma once

#include "IDeviceExecutor.h"

#include "CgGate/rts.h"

namespace rts
{

class TaskGraphProblem;

class TransfersMinimizingExecutor final : public IDeviceExecutor
{
public:
    TransfersMinimizingExecutor(
        const TaskGraphProblem& tgp,
        TaskOperations ops);

public: // public IDeviceExecutor
    virtual void execute(
        Task& task,
        DeviceId device_id,
        DriverType driver_type,
        DevicesManager& device_mgr) override;

private:
    const TaskGraphProblem& tgp_;
    TaskOperations ops_;
};

} // namespace rts
