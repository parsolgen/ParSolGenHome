#pragma once

#include "IDeviceDriver.h"

#include "DriversList.h"

#include "Storage/VersionedStorage.h"
#include "Task/Task.h"
#include "Utils/AssertOptional.h"
#include "Utils/Cast.h"
#include "Utils/SpinLock.h"

#include <boost/intrusive/list.hpp>

#include <array>
#include <deque>
#include <memory>
#include <mutex>

namespace rts
{

class TaskGraphProblem;

class DevicesManager final
{
public:
    void alloc_and_copy_to_device(
        const TaskArgument& var,
        DeviceId device_id,
        DriverType driver);

    void alloc_and_copy_to_all_devices(const TaskArgument& var);

    void alloc_and_copy_to_device_if_needed(
        TaskArgument var,
        DeviceId device_id,
        DriverType driver_type);

    void alloc_and_copy_to_all_devices_if_needed(const TaskArgument& var);

    void remove_var_from_device(DeviceId device_id, const TaskArgument& var);

    void alloc_device_buffer(
        const TaskArgument& var,
        DeviceId device_id,
        DriverType driver_type);

    static void copy_to_device(
        IDeviceBufferPtr& host_buffer,
        const void* src);

    void copy_to_host(
        const TaskArgument& var,
        DeviceId device_id);

    void copy_to_host(TaskArgument var);

    static void copy_to_host(IDeviceBufferPtr& src_buffer, void* dst);

    void register_device(DeviceId device_id, IDeviceDriverPtr&& driver);

    [[nodiscard]]
    IDeviceBuffer* get_dev_buffer_by_var(
        DeviceId device_id,
        const TaskArgument& var);

    [[nodiscard]]
    IDeviceBuffer* get_dev_ext_1_buffer_by_var(
        DeviceId device_id,
        const TaskArgument& var);

    [[nodiscard]]
    IDeviceBuffer* get_dev_ext_2_buffer_by_var(
        DeviceId device_id,
        const TaskArgument& var);

    [[nodiscard]]
    int get_dev_ext_arg_value_by_var(
        DeviceId device_id,
        const TaskArgument& var) const;

    [[nodiscard]]
    int get_dev_ext_arg_1_value_by_var(
        DeviceId device_id,
        const TaskArgument& var) const;

    [[nodiscard]]
    int get_dev_ext_arg_2_value_by_var(
        DeviceId device_id,
        const TaskArgument& var) const;

    [[nodiscard]]
    IDeviceDriver* get_dev(
        DeviceId device_id,
        const TaskArgument& var);

    [[nodiscard]]
    inline
    DeviceId get_n_devices() const noexcept
    {
#ifndef NDEBUG
    assert(initiazlied_);
#endif
#ifdef SG_USE_GOOPAX
        return device_drivers_.size();
#endif
    }

    [[nodiscard]]
    std::vector<DeviceId> get_devices_with_driver_support(
        DriverType dt) const noexcept;

    [[nodiscard]]
    inline
    IDeviceDriver& get_device(DeviceId device_id, DriverType driver)
    {
        const auto offset = get_driver_offset(device_id, driver);
        assert(offset < device_drivers_.size());
        assert(device_drivers_[offset] != nullptr);
        return *device_drivers_[offset];
    }

    [[nodiscard]]
    bool is_var_on_device(
        DeviceId device_id,
        const TaskArgument& var) const;

    void init(
        std::size_t n_arrays,
        ArrayDimSize n1,
        ArrayDimSize n2);

    void set_produced_on_device(TaskArgument var);

    void set_produced_on_host(TaskArgument var);

    [[nodiscard]]
    bool should_be_copied_to_host_immediately(
        TaskArgument var,
        const TaskGraphProblem& tgp) const;

    [[nodiscard]]
    bool should_be_copied_to_host_before_exec(
        TaskArgument var);

    [[nodiscard]]
    DeviceIds get_device_ids_by_var(const TaskArgument& var) const;

    void copy_results_to_host();

    void reset(bool independent_block = false);

    void reset_array(ArrayKey id);

    void copy_output_var_to_host_if_needed(const TaskArgument& var);

    void set_n_versions(ElementVersion n_versions);

    inline
    void set_curr_version(ElementVersion version)
    {
        curr_version_ = version;
    }

    inline
    void begin_iter_proc()
    {
        executing_iter_proc_ = true;
    }

    inline
    void end_iter_proc()
    {
        executing_iter_proc_ = false;
    }

private:
    [[nodiscard]]
    inline
    static std::size_t get_driver_offset(DeviceId device_id, DriverType driver) noexcept
    {
        return device_id
            * (utils::enum_underlying_cast(DriverType::Last))
            + utils::enum_underlying_cast(driver);
    }

private:
    struct VarDeviceDescriptor final
    {
        std::size_t device_id = 0;
        TaskArgument var;
        IDeviceBufferPtr buffer = nullptr;
        IDeviceBufferPtr ext_buffer_1 = nullptr;
        IDeviceBufferPtr ext_buffer_2 = nullptr;
        IDeviceBufferPtr ext_buffer_3 = nullptr;
        int ext_arg_value = 0;
        int ext_arg_1_value = 0;
        int ext_arg_2_value = 0;
        IDeviceDriver* dev = nullptr;
        boost::intrusive::list_member_hook<> in_device_vars_list_;

        VarDeviceDescriptor() = default;
    };

    using device_vars_list_member_hook_option =
        boost::intrusive::member_hook<
            VarDeviceDescriptor,
            boost::intrusive::list_member_hook<>,
            &VarDeviceDescriptor::in_device_vars_list_>;
    using DeviceVarsList = boost::intrusive::list<
        VarDeviceDescriptor, device_vars_list_member_hook_option>;
    using VarDevices = std::vector<VarDeviceDescriptor>;

private:
    VarDeviceDescriptor* try_get_device_var_descriptor(const TaskArgument& var);

    void alloc_copy_to_device_impl(
        const TaskArgument& var,
        DeviceId device_id,
        DriverType driver_type,
        VarDeviceDescriptor& dev_var_descriptor);

    [[nodiscard]]
    VarDeviceDescriptor& get_dev_var_descriptor(
        DeviceId dev_id,
        TaskArgument var);

    [[nodiscard]]
    const VarDeviceDescriptor& get_dev_var_descriptor(
        DeviceId dev_id,
        TaskArgument var) const;

    void copy_to_host(
        VarDeviceDescriptor& descriptorm,
        bool delete_from_list);

    [[nodiscard]]
    inline
    bool should_copy_reset_var_to_device(ArrayKey array_id) const noexcept
    {
        assert(array_id < reset_arrays_.size());
        return reset_arrays_[array_id];
    }

    void update_var_version(TaskArgument& var) const
    {
        if (n_versions_ > 0) {
            var.version = var.version % n_versions_;
        }
    }

    [[nodiscard]]
    inline
    void add_iteration_version(TaskArgument& var) const
    {
        if (executing_iter_proc_) {
            var.version = var.version + curr_version_;
        }
    }

    [[nodiscard]]
    void sub_iteration_version(TaskArgument& var) const
    {
        var.version = var.version  - curr_version_;
    }

private:
    std::deque<IDeviceDriverPtr> device_drivers_;
    utils::AssertOptional<VersionedMeshStorage<VarDevices>> vars_storage_;
    utils::AssertOptional<VersionedMeshStorage<bool>> host_copy_updated_;
    utils::AssertOptional<VersionedMeshStorage<bool>> produced_on_device_;
    utils::AssertOptional<VersionedMeshStorage<bool>> produced_on_host_;
    DeviceVarsList device_vars_list_;
    mutable std::mutex mutex_;
    std::vector<bool> reset_arrays_;
    DeviceId n_devices_ = 0;
    bool executing_independent_tgp_ = false;
    ElementVersion n_versions_ = 0;
    ElementVersion curr_version_ = 0;
    bool executing_iter_proc_ = false;

#ifndef NDEBUG
    bool initiazlied_ = false;
#endif
};

DevicesManager& get_devices_manager();

} // namespace rts
