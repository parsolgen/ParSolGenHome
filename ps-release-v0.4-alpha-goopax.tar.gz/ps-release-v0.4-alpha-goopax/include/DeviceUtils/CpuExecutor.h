#pragma once

#include "Fwd.h"

#include "Task/Task.h"

namespace rts
{

class CpuExecutor final
{
public:
    explicit CpuExecutor(TaskOperations& ops);

    void execute(const Task& task, DevicesManager& devices_mgr);

private:
    TaskOperations& ops_;
};

} // namespace rts
