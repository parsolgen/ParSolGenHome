#pragma once

#include <cstdint>

#include "Task/Task.h"

#include "Fwd.h"

#ifdef SG_USE_GOOPAX
#include <goopax>
#endif

namespace rts
{

void init_accel_support();

[[nodiscard]]
IDeviceBuffer* get_dev_buffer_by_var(DeviceId device_id, const TaskArgument& var);
[[nodiscard]]
IDeviceBuffer* get_dev_ext_1_buffer_by_var(DeviceId device_id, const TaskArgument& var);
[[nodiscard]]
IDeviceBuffer* get_dev_ext_2_buffer_by_var(DeviceId device_id, const TaskArgument& var);
[[nodiscard]]
int get_dev_ext_arg_value(DeviceId device_id, const TaskArgument& var);
[[nodiscard]]
int get_dev_ext_arg_1_value(DeviceId device_id, const TaskArgument& var);
[[nodsicard]]
int get_dev_ext_arg_2_value(DeviceId device_id, const TaskArgument& var);

#ifdef SG_USE_GOOPAX
goopax::goopax_device get_goopax_dev_by_var(DeviceId device_id, const TaskArgument& var);
#endif

} // namespace rts
