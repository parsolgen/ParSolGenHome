#pragma once

#include "IDeviceScheduler.h"

#include "Task/TaskGraph.h"

#include "Storage/VersionedStorage.h"

#include <mutex>

namespace rts
{

class GraphPartitioningScheduler final : public IDeviceScheduler
{
private:
    static constexpr const auto low_precision = 10;
    static constexpr const auto high_precision = 100;
    static constexpr const auto cpu_part_weight = 0.1;

public:
    GraphPartitioningScheduler(
        std::size_t n_arrays,
        ArrayDimSize n1,
        ArrayDimSize n2,
        const TaskGraph& local_task_graph,
        DevicesManager& devices_mgr);

public: // public IDeviceScheduler
    [[nodiscard]]
    virtual ScheduledDevice get_target_device(
        const Task& task) override;

    virtual void release_device(
        DeviceId device_id,
        const Task& task) override;

    virtual void release_device(
        DeviceId device_id,
        const TaskArgument& var) override;

    virtual void release_device(DeviceId device_id) override;

private:
    std::mutex mutex_;
    DevicesManager& dev_mgr_;
    std::vector<std::size_t> device_id_to_free_memory_;
    std::vector<std::size_t> device_id_to_total_memory_;
    VersionedMeshStorage<DeviceId> task_to_device_id_;
    std::size_t n_devices_ = 0;
};

} // namespace rts
