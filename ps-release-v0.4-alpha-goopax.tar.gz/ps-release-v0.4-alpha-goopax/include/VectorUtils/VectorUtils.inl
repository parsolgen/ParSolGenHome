#pragma once

#include "VectorUtils.h"

#include "Algorithms/Reduction.h"
#include "Utils/Cast.h"

#include <mutex>
#include <cstring>

extern "C"
{

double ddot_(const int*, const double*, const int*,  const double*, const int*);
double sdot_(const int*, const float*, const int*,  const float*, const int*);

void daxpy_(const int* n, const double* da, const double *dx, const int* incx, double *dy, const int* incy) ;
void saxpy_(const int* n, const float* da, const float *dx, const int* incx, float *dy, const int* incy) ;

void dscal_(const int* n, const double* da, double *dx, const int* incx);
void sscal_(const int* n, const double* da, double *dx, const int* incx);

}

namespace algo
{
inline namespace
{

template <typename T, std::enable_if_t<std::is_floating_point_v<T>, int> = 0>
T dot(const T* lhs, const T* rhs, std::size_t len)
{
    const int incx = 1;
    const int ilen = utils::cast_to_int<int>(len);

    if constexpr (std::is_same_v<T, double>) {
        return ddot_(&ilen, lhs, &incx, rhs, &incx);
    }
    else if constexpr (std::is_same_v<T, float>) {
        return sdot_(&ilen, lhs, &incx, rhs, &incx);
    }
}

template <typename T, std::enable_if_t<std::is_floating_point_v<T>, int> = 0>
void axpy(const T* lhs, T* rhs, T alpha, std::size_t len)
{
    const int incx = 1;
    const int ilen = utils::cast_to_int<int>(len);

    if constexpr (std::is_same_v<T, double>) {
        daxpy_(&ilen, &alpha, lhs, &incx, rhs, &incx);
    }
    else if constexpr (std::is_same_v<T, float>) {
        saxpy_(&ilen, &alpha, lhs, &incx, rhs, &incx);
    }
}

template <typename T, std::enable_if_t<std::is_floating_point_v<T>, int> = 0>
void ascal(T* rhs, T alpha, std::size_t len)
{
    const int incx = 1;
    const int ilen = utils::cast_to_int<int>(len);

    if constexpr (std::is_same_v<T, double>) {
        dscal_(&ilen, &alpha, rhs, &incx);
    }
    else if constexpr (std::is_same_v<T, float>) {
        sscal_(&ilen, &alpha, rhs, &incx);
    }
}

} // inline namespace

template <typename V>
typename V::element_t dot(
    const V& lhs,
    rts::ElementVersion version,
    MPI_Comm comm)
{
    return reduce(
        lhs,
        version,
        ReduceOperation::Sum,
        [](auto& init, const auto, const auto* ptr, const auto length)
        {
            init += dot(ptr, ptr, length);
        },
        typename V::element_t{},
        comm);
}

template <typename V1, typename V2,
    std::enable_if_t<std::is_same_v<typename V1::element_t, typename V2::element_t>, int>>
typename V1::element_t dot(
    const V1& lhs,
    const V2& rhs,
    rts::ElementVersion version,
    MPI_Comm comm)
{
    return reduce(
        lhs,
        version,
        ReduceOperation::Sum,
        [&rhs](auto& init, auto arg, const auto* ptr, const auto length){
            arg.array_or_var = rhs.GetKey();
            init += dot(ptr, rhs.GetLatestElementPtr(arg), length);
        },
        typename V1::element_t{},
        comm);
}

template <typename V1, typename V2,
    std::enable_if_t<std::is_same_v<typename V1::element_t, typename V2::element_t>, int>>
typename V1::element_t dot(
    const V1& lhs,
    rts::ElementVersion lhs_version,
    const V2& rhs,
    rts::ElementVersion rhs_version,
    MPI_Comm comm)
{
    using T = typename V1::element_t;
    const auto key = rhs.GetKey();
    std::mutex m;
    T in_result = T{};

    lhs.ForEachElementWithSpecifiedVersionParallel(
        lhs_version,
        [&in_result, key, &rhs, &m](
            const auto coord,
            const auto version,
            const auto* ptr,
            const auto length)
        {
            const auto rhs_arg = rts::TaskArgument{
                key,
                version,
                coord};
            const auto tmp = dot(ptr, rhs.GetPtr(rhs_arg), length);
            {
                std::lock_guard lk{m};
                in_result += tmp;
            }
        });
    T result;
    MPI_CHECKED_CALL(MPI_Allreduce(
        &in_result,
        &result,
        1,
        rts::comm::mpi_data_type<T>::value,
        MPI_SUM,
        comm));
    return result;
}

template<typename V>
typename V::element_t dot(
    const V& lhs,
    const V& rhs,
    rts::TaskGraph& graph,
    MPI_Comm comm)
{
    return algo::reduce(
        lhs,
        graph,
        algo::ReduceOperation::Sum,
        [&rhs](auto& init, auto arg, const auto* ptr, const auto length){
            arg.array_or_var = rhs.GetKey();
            init += dot(ptr, rhs.GetLatestElementPtr(arg), length);
        },
        typename V::element_t{},
        comm);
}

template<typename V>
typename V::element_t dot(
    const V& lhs,
    rts::TaskGraph& graph,
    MPI_Comm comm)
{
    return algo::reduce(
        lhs,
        graph,
        algo::ReduceOperation::Sum,
        [](auto& init, const auto, const auto* ptr, const auto length){
            init += dot(ptr, ptr, length);
        },
        typename V::element_t{},
        comm);
}

template<typename V1, typename V2>
void axpy(
    rts::ElementVersion version,
    const V1& lhs,
    V2& rhs,
    typename V1::element_t alpha)
{
    lhs.ForEachElementWithSpecifiedVersionParallel(
        version,
        [&rhs, alpha](
            const auto coord,
            const auto version,
            const auto* ptr,
            const auto length)
        {
            const auto rhs_arg = rts::TaskArgument{
                rhs.GetKey(),
                version,
                coord};
            auto rhs_ptr = rhs.GetPtr(rhs_arg);
            assert(length == rhs.GetLen(rhs_arg));
            axpy(ptr, rhs_ptr, alpha, length);
        });
}

template<typename V1, typename V2>
void axpy(
    const V1& x,
    rts::ElementVersion x_ver,
    V2& y,
    rts::ElementVersion y_ver,
    typename V1::element_t alpha)
{
    y.ForEachElementWithSpecifiedVersionParallel(
        y_ver,
        [&x, alpha, x_ver](
            const auto coord,
            const auto version,
            auto* ptr,
            const auto length)
        {
            const auto x_arg = rts::TaskArgument{
                x.GetKey(),
                x_ver,
                coord};
            const auto* x_ptr = x.GetPtr(x_arg);
            assert(length == x.GetLen(x_arg));
            axpy(x_ptr, ptr, alpha, length);
        });
}

template<typename V>
void scal(
    rts::ElementVersion version,
    V& rhs,
    typename V::element_t alpha)
{
    rhs.ForEachElementWithSpecifiedVersionParallel(
        version,
        [alpha](
            const auto,
            const auto,
            auto* ptr,
            const auto length)
        {
            ascal(ptr, alpha, length);
        });
}

template<typename V1, typename V2>
void vcopy(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs,
    rts::ElementVersion lhs_ver)
{
    lhs.ForEachElementWithSpecifiedVersionParallel(
        lhs_ver,
        [&rhs](
            const auto coord,
            const auto v,
            const auto* ptr,
            const auto length)
        {
            const auto arg = rts::TaskArgument{rhs.GetKey(), v, coord};
            assert(rhs.GetLen(arg) == length);
            std::memcpy(
                rhs.GetPtr(arg),
                ptr,
                length * sizeof(double));
        });
}

template<typename V1, typename V2, typename V3>
void vsum(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs_1,
    rts::ElementVersion lhs_1_ver,
    const V3& lhs_2,
    rts::ElementVersion lhs_2_ver)
{
    rhs.ForEachElementWithSpecifiedVersionParallel(
        rhs_ver,
        [&lhs_1, &lhs_2, lhs_1_ver, lhs_2_ver](
            const auto coord,
            const auto v,
            auto* ptr,
            const auto length)
        {
            const auto l1_arg = rts::TaskArgument{
                lhs_1.GetKey(),
                lhs_1_ver,
                coord};
            const auto l2_arg = rts::TaskArgument{
                lhs_2.GetKey(),
                lhs_2_ver,
                coord};
            const auto* l1_ptr = lhs_1.GetPtr(l1_arg);
            const auto* l2_ptr = lhs_2.GetPtr(l2_arg);
            assert(length == lhs_1.GetLen(l1_arg));
            assert(length == lhs_2.GetLen(l2_arg));
            for (rts::ArrayElementCoord i = 0; i < length; ++i)
            {
                ptr[i] = l1_ptr[i] + l2_ptr[i];
            }
        });
}

template<typename V1, typename V2, typename V3>
void vsub(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs_1,
    rts::ElementVersion lhs_1_ver,
    const V3& lhs_2,
    rts::ElementVersion lhs_2_ver)
{
    static_assert(std::is_same_v<typename V1::element_t, typename V2::element_t>);
    rhs.ForEachElementWithSpecifiedVersionParallel(
        rhs_ver,
        [&lhs_1, &lhs_2, lhs_1_ver, lhs_2_ver](
            const auto coord,
            const auto v,
            auto* ptr,
            const auto length)
        {
            const auto l1_arg = rts::TaskArgument{
                lhs_1.GetKey(),
                lhs_1_ver,
                coord};
            const auto l2_arg = rts::TaskArgument{
                lhs_2.GetKey(),
                lhs_2_ver,
                coord};
            const auto* l1_ptr = lhs_1.GetPtr(l1_arg);
            const auto* l2_ptr = lhs_2.GetPtr(l2_arg);
            assert(length == lhs_1.GetLen(l1_arg));
            assert(length == lhs_2.GetLen(l2_arg));
            for (rts::ArrayElementCoord i = 0; i < length; ++i)
            {
                ptr[i] = l1_ptr[i] - l2_ptr[i];
            }
        });
}

template<typename V1, typename V2, typename V3>
void vmul(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs_1,
    rts::ElementVersion lhs_1_ver,
    const V3& lhs_2,
    rts::ElementVersion lhs_2_ver)
{
    static_assert(std::is_same_v<typename V1::element_t, typename V2::element_t>);
    lhs_1.ForEachElementWithSpecifiedVersionParallel(
        lhs_1_ver,
        [&rhs, &lhs_2, rhs_ver, lhs_2_ver](
            const auto coord,
            const auto,
            const auto* ptr,
            const auto length)
        {
            const auto rhs_arg = rts::TaskArgument{rhs.GetKey(), rhs_ver, coord};
            const auto lhs_arg = rts::TaskArgument{rhs.GetKey(), lhs_2_ver, coord};
            assert(rhs.GetLen(rhs_arg) == length);
            assert(lhs_2.GetLen(lhs_arg) == length);
            auto* rhs_ptr = rhs.GetPtr(rhs_arg);
            auto* lhs_2_ptr = lhs_2.GetPtr();
            for (std::size_t i = 0; i < length; ++i) {
                rhs_ptr[i] = ptr[i] * lhs_2_ptr[i];
            }
        });
}

template<typename V1, typename V2>
void vmul(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs,
    rts::ElementVersion lhs_ver,
    typename V1::element_t alpha)
{
    if (rhs.GetKey() == lhs.GetKey()) {
        if (rhs_ver > lhs_ver && !rhs.isUpdatable() && !lhs.isUpdatable()) {
            scal(rhs_ver, rhs, alpha);
            return;
        }
    }
    lhs.ForEachElementWithSpecifiedVersionParallel(
        lhs_ver,
        [&rhs, rhs_ver, alpha](
            const auto coord,
            const auto v,
            const auto* ptr,
            const auto length)
        {
            const auto arg = rts::TaskArgument{rhs.GetKey(), rhs_ver, coord};
            assert(rhs.GetLen(arg) == length);
            auto* rhs_ptr = rhs.GetPtr(arg);
            for (rts::ArrayElementCoord i = 0; i < length; ++i) {
                rhs_ptr[i] = ptr[i] * alpha;
            }
        });
}

} // namespace algo
