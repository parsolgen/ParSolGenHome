#pragma once

#include "ContiguousArray.h"

#include "ArrayUtils.h"

namespace rts
{

template<ArrayDim N, typename T>
ContiguousArray<N, T>::ContiguousArray(ArrayKey id, ArrayElementCoord n)
    : ContiguousArray{id, ArrayElementCoordinates<1>{n}}
{
    assert(N == 1);
}

template<ArrayDim N, typename T>
ContiguousArray<N, T>::ContiguousArray(ArrayKey id, ArrayElementCoordinates<N> dims)
    : id_{id}
    , dims_{std::move(dims)}
{
    static constexpr const std::size_t n_versions = 2;

    block_size_ = data_offset_ + get_array_length<N>(dims) * sizeof(T);
    for (std::size_t i = 0; i < n_versions; ++i) {
        free_list_.emplace_back(std::make_unique<std::uint8_t[]>(block_size_));
    }
}

template<ArrayDim N, typename T>
ContiguousArray<N, T>::ContiguousArray(
    ArrayKey id,
    ArrayElementCoordinates<N> dims,
    T default_value)
    : ContiguousArray{id, std::move(dims)}
{
    for (auto& ws_pair : working_set_) {
        auto* ptr = reinterpret_cast<T*>(ws_pair.second.get() + data_offset_);
        for (std::size_t i = 0; i < get_array_length<N>(dims); ++i) {
            ptr[i] = default_value;
        }
    }
}

template<ArrayDim N, typename T>
T* ContiguousArray<N, T>::GetPtr(const TaskArgument& arg)
{
    assert(arg.array_or_var == id_);
    assert(arg.n == N);

    auto* ptr = [&]() {
        auto it = working_set_.find(arg.version);
        if (it == working_set_.end()) {
            return allocateBlock(arg.version);
        }
        return it->second.get();
    }();
    return reinterpret_cast<T*>(ptr + data_offset_);
}

template<ArrayDim N, typename T>
const T* ContiguousArray<N, T>::GetPtr(const TaskArgument& arg) const
{
    assert(arg.array_or_var == id_);
    const auto it = working_set_.find(arg.version);
    assert(it != working_set_.end());
    return reinterpret_cast<const T*>(it->second.get() + data_offset_);
}

template<ArrayDim N, typename T>
comm::SerializedMPIDataType ContiguousArray<N, T>::GetMpiTypeForReceivingBlock(
    std::uint8_t* data,
    std::size_t byte_size)
{
    return comm::construct_mpi_datatype(
        comm::ContiguousArray{
            data,
            byte_size});
}

template<ArrayDim N, typename T>
comm::SerializedMPIDataType ContiguousArray<N, T>::GetMpiTypeForSendingBlock(const TaskArgument& arg)
{
    return comm::construct_mpi_datatype(
        comm::ContiguousArray{
            reinterpret_cast<std::uint8_t*>(GetPtr(arg)),
            block_size_});
}

template<ArrayDim N, typename T>
TaskArgument ContiguousArray<N, T>::InsertReceivedBlock(
    ArrayKey key,
    std::unique_ptr<std::uint8_t[]>&& block_mem)
{
    const auto ver = *reinterpret_cast<const ElementVersion*>(block_mem.get());
    std::unique_ptr<std::uint8_t[]> result_buffer{block_mem.get()};
    block_mem.release();
    working_set_.emplace(ver, std::move(result_buffer));
    return TaskArgument{key, ver, 0};
}

template<ArrayDim N, typename T>
ArrayKey ContiguousArray<N, T>::GetKey() const
{
    return id_;
}

template<ArrayDim N, typename T>
std::size_t ContiguousArray<N, T>::GetLen(const TaskArgument& var) const
{
    assert(var.array_or_var == id_);
    return get_array_length<N>(dims_);
}

template<ArrayDim N, typename T>
bool ContiguousArray<N, T>::isLocal(const TaskArgument& var)
{
    assert(var.array_or_var == id_);
    return working_set_.find(var.version) != working_set_.end();
}

template<ArrayDim N, typename T>
void ContiguousArray<N, T>::free(const TaskArgument& var)
{
    const auto it = working_set_.find(var.version);
    assert(it != working_set_.end());
    free_list_.emplace_back(std::move(it->second));
}

template<ArrayDim N, typename T>
std::uint8_t* ContiguousArray<N, T>::allocateBlock(ElementVersion ver)
{
    if (free_list_.empty()) {
        free_list_.emplace_back(std::make_unique<uint8_t[]>(block_size_));
    }
    auto* result = free_list_.back().get();
    working_set_.emplace(ver, std::move(free_list_.back()));
    free_list_.pop_back();
    return result;
}

template<ArrayDim N, typename T>
const std::uint8_t* ContiguousArray<N, T>::allocateBlock(ElementVersion ver) const
{
    if (free_list_.empty()) {
        free_list_.emplace_back(std::make_unique<uint8_t[]>(block_size_));
    }
    const auto* result = free_list_.back().get();
    working_set_.emplace(ver, std::move(free_list_.back()));
    free_list_.pop_back();
    return result;
}

} // namespace rts
