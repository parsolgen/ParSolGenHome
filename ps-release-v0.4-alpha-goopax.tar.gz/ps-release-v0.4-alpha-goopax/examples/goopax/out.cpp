#include "ucodes.h"
#include "CgGate/rts.h"
#include <goopax>
int main(int argc, char** argv)
{
int provided_threading_level = 0;
MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE, &provided_threading_level);
if (provided_threading_level != MPI_THREAD_MULTIPLE) {
std::cerr << "Error MPI_Init_thread()\n";
return 0;
}
rts::internal::parse_command_line_args(argc, argv);
int rank = 0;
int comm_size = 0;
MPI_CHECKED_CALL(MPI_Comm_size(MPI_COMM_WORLD, &comm_size));
MPI_CHECKED_CALL(MPI_Comm_rank(MPI_COMM_WORLD, &rank));
rts::comm::ProcessCoordinates<2> comm_dims = {0, 0};
MPI_CHECKED_CALL(MPI_Dims_create(comm_size, 2, comm_dims.data()));
MPI_Comm cart_comm;
int periods[2] = {0, 0};
MPI_CHECKED_CALL(MPI_Cart_create(MPI_COMM_WORLD, 2, comm_dims.data(), periods, 0, &cart_comm));
const auto comm_coords = [&]()
{
    rts::comm::ProcessCoordinates<2> coords;
    MPI_CHECKED_CALL(MPI_Cart_coords(cart_comm, rank, 2, coords.data()));
    return coords;
}();

rts::init(1, argc, argv);
int nb = 20;
int mb = 20;
int block_n = 10;
int block_m = 10;
rts::ArrayDimensions<2> A_dims2{nb, mb};
const auto A_distr2 = rts::distribute_area(A_dims2, comm_dims, cart_comm);
const auto A_loc_sa = rts::get_local_subarray_dims_01(A_dims2, A_distr2);
const auto A_loc_sa_coords = rts::get_local_subarray_coords_01(A_dims2, comm_coords, comm_dims);
auto A = rts::declare_generic_nu_d_array(0, 2, A_dims2, A_loc_sa, A_loc_sa_coords, rts::ArrayDimensions<2>{block_n, block_m}, rts::ArrayDimensions<2>{block_n, block_m});;
if (!rts::is_tgp_already_declared(0))
{
rts::ArrayDimensions<2> area_dims_0{rts::algo::max<std::size_t>(nb, nb, nb, nb), rts::algo::max<std::size_t>(mb, mb, mb, mb)};
const auto area_distr_0 = rts::distribute_area(area_dims_0, comm_dims, cart_comm);
const auto lsa_dims_0 = rts::get_local_subarray_dims_01(area_dims_0, area_distr_0);
const auto lsa_coords_0 = rts::get_local_subarray_coords_01(area_dims_0, comm_coords, comm_dims);
rts::reset_task_op_id();
rts::TaskGraphProblemHolder tgp_0{};
tgp_0.initialize([&]() {
auto tgov_0 = utils::MakeWithCapacity<rts::TaskOperations>(100000);
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
tgov_0.emplace_back([block_m,block_n,i,j,&A](const auto& task) {
auto out_0 = A.GetPtr(task.outputs[0]);

init_el(i, j, block_n, block_m, out_0);
});
}
}
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
tgov_0.emplace_back([j,i,block_n,block_m,&A](const auto& task) {
const auto in_0 = A.GetInPtr(task.inputs[0]);
auto out_0 = A.GetPtr(task.outputs[0]);

calc_main(block_n, block_m, in_0, out_0);
});
}
}
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
tgov_0.emplace_back([block_m,block_n,i,j,&A](const auto& task) {
const auto in_0 = A.GetInPtr(task.inputs[0]);

print_el(i, j, block_n, block_m, in_0);
});
}
}
auto tgov_0_goopax = utils::MakeWithCapacity<rts::TaskOperations>(100000);
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
tgov_0_goopax.emplace_back([](auto& t) { (void)t; assert(false); });
}
}
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
tgov_0_goopax.emplace_back([j,i,block_n,block_m,&A](const auto& task) {
const auto in_0 = rts::get_goopax_buffer<double>(task.inputs[0]);
auto out_0 = rts::get_goopax_buffer<double>(task.outputs[0]);

calc_main_goopax(rts::get_goopax_device_by_task(task), block_n, block_m, in_0, out_0);
});
}
}
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
tgov_0_goopax.emplace_back([](auto& t) { (void)t; assert(false); });
}
}

if (rank == 0)
{
auto* tg_0 = rts::declare_task_graph(1, rts::algo::max<std::size_t>(nb, nb, nb, nb), rts::algo::max<std::size_t>(mb, mb, mb, mb));
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
auto task_0 = rts::Task{rts::genereate_op_id(),rts::TaskArgumentsVector{}, rts::TaskArgumentsVector{rts::TaskArgument{0, 0, rts::ArrayElementCoordinates<2>{i, j}}}};
task_0.xdata.set<rts::RightLookingExecutorInfo>(rts::RightLookingExecutorInfo{});
task_0.cpu_support_ = true;

insert_task(tg_0, std::move(task_0));
}
}
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
auto task_1 = rts::Task{rts::genereate_op_id(),rts::TaskArgumentsVector{rts::TaskArgument{0, 0, rts::ArrayElementCoordinates<2>{i, j}}}, rts::TaskArgumentsVector{rts::TaskArgument{0, 1, rts::ArrayElementCoordinates<2>{i, j}}}};
task_1.xdata.set<rts::RightLookingExecutorInfo>(rts::RightLookingExecutorInfo{});
task_1.goopax_supprot_ = true;
task_1.cpu_support_ = true;

insert_task(tg_0, std::move(task_1));
}
}
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
auto task_2 = rts::Task{rts::genereate_op_id(),rts::TaskArgumentsVector{rts::TaskArgument{0, 1, rts::ArrayElementCoordinates<2>{i, j}}}, rts::TaskArgumentsVector{}};
task_2.xdata.set<rts::RightLookingExecutorInfo>(rts::RightLookingExecutorInfo{});
task_2.cpu_support_ = true;

insert_task(tg_0, std::move(task_2));
}
}
return rts::create_tg_problem(rts::TaskGraphProblem::ProblemClass::ESSRelated, lsa_coords_0, lsa_dims_0, std::move(tgov_0), std::move(tgov_0_goopax), tg_0, rts::get_default_nthreads(), rts::comm::get_comm_size(MPI_COMM_WORLD), rts::ExplicitSolverTaskGraphDistributor{2, 
area_dims_0,
comm_dims,
cart_comm}, MPI_COMM_WORLD, A);
}
else
{
return rts::create_tg_problem(rts::TaskGraphProblem::ProblemClass::ESSRelated, lsa_coords_0, lsa_dims_0, std::move(tgov_0), std::move(tgov_0_goopax), rts::declare_task_graph(), rts::get_default_nthreads(), rts::comm::get_comm_size(MPI_COMM_WORLD), rts::ExplicitSolverTaskGraphDistributor{2, 
area_dims_0,
comm_dims,
cart_comm}, MPI_COMM_WORLD, A);
}
});
rts::declare_tgp(std::move(tgp_0));
}
rts::reset_tgp(0);
if(rts::is_tgp_first_iteration(0))
{
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
rts::ref_tgp_out_var(0, rts::TaskArgument{0, 0, rts::ArrayElementCoordinates<2>{i, j}});
}
}
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
rts::ref_tgp_in_var(0, rts::TaskArgument{0, 0, rts::ArrayElementCoordinates<2>{i, j}});
rts::ref_tgp_out_var(0, rts::TaskArgument{0, 1, rts::ArrayElementCoordinates<2>{i, j}});
}
}
for (int i = 0;
(i<nb); i++)
{
for (int j = 0;
(j<mb); ++j)
{
rts::ref_tgp_in_var(0, rts::TaskArgument{0, 1, rts::ArrayElementCoordinates<2>{i, j}});
}
}

rts::finish_tgp_first_iteration(0);
}
rts::exec_tgp_and_wait(0);
MPI_Barrier(MPI_COMM_WORLD);
rts::finalize();
MPI_Finalize();
rts::stop_threads();
return 0;
}
