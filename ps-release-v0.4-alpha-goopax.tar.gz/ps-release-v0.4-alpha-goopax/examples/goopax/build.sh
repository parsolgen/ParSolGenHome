rm out.cpp
rm a.out
sgc goopax.sol
mpicxx -std=c++17 out.cpp -DSG_USE_ACCEL=On -DSG_USE_GOOPAX=On -DPSTL_USE_PARALLEL_POLICIES=0 -I/home/usr/software/goopax/include/goopax-5.8 -L/home/usr/software/goopax/lib64 -I/home/usr/intel/oneapi/tbb/2022.2/include/ -I/home/usr/software/intel/oneapi/mkl/latest/include -I/home/usr/work/ps-release-v0.3-alpha-goopax/include -L/home/usr/work/ps-release-v0.3-alpha-goopax/lib -L/home/usr/intel/oneapi/mkl/latest/lib/intel64 -L/home/usr/intel/oneapi/tbb/2022.2/lib/intel64 -L/home/usr/software/gklib/lib -lPSRts -lmkl_intel_lp64 -lmkl_sequential -lmkl_core -lGKlib -fopenmp -lgoopax -ltbb -O3
