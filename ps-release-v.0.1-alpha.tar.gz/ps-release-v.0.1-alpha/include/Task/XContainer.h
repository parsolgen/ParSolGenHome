#pragma once

#include <optional>
#include <tuple>

#include "Executors/RightLookingExecutorInfo.h"

namespace rts {

#define CLASS(x) class x;
#define STRUCT(x) struct x;
#define LAST_CLASS(x) class x;
#define LAST_STRUCT(x) struct x;

#include "XContainerTypes.list"

#undef CLASS
#undef STRUCT
#undef LAST_CLASS
#undef LAST_STRUCT

class XContainer final {
public:
  template <typename T>
  T& get();

  template <typename T>
  const T& get() const;

  template <typename T>
  bool has_value() const;

  template <typename T>
  void set(T&& val);

  void reset();

private:
#define CLASS(x) std::optional<x>,
#define STRUCT(x) std::optional<x>,
#define LAST_CLASS(x) std::optional<x>
#define LAST_STRUCT(x) std::optional<x>
  std::tuple<
#include "XContainerTypes.list"
      >
      data_;
#undef CLASS
#undef STRUCT
#undef LAST_CLASS
#undef LAST_STRUCT
};

} // namespace rts

#include "XContainer.inl"
