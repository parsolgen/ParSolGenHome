#pragma once

#include <cstdint>

namespace rts {

using TaskId = std::size_t;

using TaskIndex = std::size_t;

using DeviceId = std::size_t;

} // namespace rts