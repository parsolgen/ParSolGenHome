#pragma once

#include "Task/Task.h"
#include "Comm/ComplexTypeConstructor.h"

#include <vector>
#include <unordered_map>
#include <memory>

namespace rts
{

template<ArrayDim N, typename T>
class ContiguousArray final
{
public:
    using element_t = T;

public:
    static_assert(N > 0, "N must be > 0");
    static_assert(N <= 3, "N must be <= 3");

    ContiguousArray(ArrayKey id, ArrayElementCoord n);
    ContiguousArray(ArrayKey id, ArrayElementCoordinates<N> dims);
    ContiguousArray(ArrayKey id, ArrayElementCoordinates<N> dims, T default_value);

public:
    T* GetPtr(const TaskArgument& arg);

    const T* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& coords);

    TaskArgument InsertReceivedBlock(ArrayKey id, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    bool isLocal(const TaskArgument& var);

    void free(const TaskArgument& var);

private:
    std::uint8_t* allocateBlock(ElementVersion ver);

    const std::uint8_t* allocateBlock(ElementVersion ver) const;

private:
    static constexpr const std::size_t data_offset_ = sizeof(ElementVersion);

private:
    ArrayKey id_;
    ArrayElementCoordinates<N> dims_;
    std::size_t block_size_;
    mutable std::vector<std::unique_ptr<std::uint8_t[]>> free_list_;
    mutable std::unordered_map<ElementVersion, std::unique_ptr<std::uint8_t[]>> working_set_;
};

} // namespace rts

#include "ContiguousArray.inl"
