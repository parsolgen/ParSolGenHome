#pragma once

#include <cstdint>

namespace utils {

template <typename T>
inline void hash_combine(std::size_t& seed, const T& v);

} // namespace utils

#include "HashCombine.inl"