#pragma once

#define SG_UNUSED_PARAMETER(x) \
    (void)x
