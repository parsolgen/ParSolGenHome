#pragma once

#include "ArrayHolders/CSRMatrixBlock.h"

#include "Comm/ComplexTypeConstructor.h"
#include "Comm/Types.h"
#include "Task/Task.h"

namespace rts
{

class BlockedCSRMatrixDI final
{
public:
    using I = std::int32_t;
    using A = double;
    static constexpr const bool is_matrix = true;

public:
  BlockedCSRMatrixDI(ArrayKey key, I n, I m, I nnz, I* ia, I* ja, A* a, I nb, I mb);
  explicit BlockedCSRMatrixDI(ArrayKey key);
  ~BlockedCSRMatrixDI();

public:
  CSRMatrixBlock<I, A> get(const ArrayElementCoordinates<2>& coords);

  CSRMatrixBlock<I, A> get(const TaskArgument& arg);

  bool is_zero(const ArrayElementCoordinates<2>& coords) const;

  bool is_zero(const TaskArgument& arg) const;

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const ArrayElementCoordinates<2>& coords);

  comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(std::uint8_t* data, std::size_t byte_size);

  TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& data);

  I* ia();

  const I* ia() const;

  I* ja();

  const I* ja() const;

  A* a();

  const A* a() const;

  std::size_t nblocks() const;

  I n() const;

  ArrayKey GetKey() const;

  I nb() const;

  I mb() const;

  static constexpr const bool is_blocked_csr_matrix = true;

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class BlockedCSRMatrixSI final
{
public:
    using I = std::int32_t;
    using A = float;
    static constexpr const bool is_matrix = true;

public:
  BlockedCSRMatrixSI(ArrayKey key, I n, I m, I nnz, I* ia, I* ja, A* a, I nb, I mb);
  explicit BlockedCSRMatrixSI(ArrayKey key);
  ~BlockedCSRMatrixSI();

public:
  CSRMatrixBlock<I, A> get(const ArrayElementCoordinates<2>& coords);

  CSRMatrixBlock<I, A> get(const TaskArgument& arg);

  bool is_zero(const ArrayElementCoordinates<2>& coords) const;

  bool is_zero(const TaskArgument& arg) const;

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const ArrayElementCoordinates<2>& coords);

  comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(std::uint8_t* data, std::size_t byte_size);

  TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& data);

  I* ia();

  const I* ia() const;

  I* ja();

  const I* ja() const;

  A* a();

  const A* a() const;

  std::size_t nblocks() const;

  I n() const;

  ArrayKey GetKey() const;

  I nb() const;

  I mb() const;

  static constexpr const bool is_blocked_csr_matrix = true;

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class NonUpdatableBlockCyclicDistributedMatrixD final
{
public:
    NonUpdatableBlockCyclicDistributedMatrixD(
        ArrayKey array_id,
        ArrayDimensions<2> global_dims,
        ArrayDimensions<2> block_dims,
        comm::ProcessCoordinates<2> comm_coords,
        comm::ProcessCoordinates<2> comm_size);

    ~NonUpdatableBlockCyclicDistributedMatrixD();

public:
    double* GetPtr(const TaskArgument& arg);

    const double* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(
        const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(
        ArrayKey key,
        std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& arg) const;

    double* GetLatestElementPtr(const TaskArgument& arg);

    const double* GetLatestElementPtr(const TaskArgument& arg) const;

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class NonUpdatableBlockCyclicDistributedMatrixS final
{
public:
    NonUpdatableBlockCyclicDistributedMatrixS(
        ArrayKey array_id,
        ArrayDimensions<2> global_dims,
        ArrayDimensions<2> block_dims,
        comm::ProcessCoordinates<2> comm_coords,
        comm::ProcessCoordinates<2> comm_size);

    ~NonUpdatableBlockCyclicDistributedMatrixS();

public:
    float* GetPtr(const TaskArgument& arg);

    const float* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(
        const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(
        ArrayKey key,
        std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& arg) const;

    float* GetLatestElementPtr(const TaskArgument& arg);

    const float* GetLatestElementPtr(const TaskArgument& arg) const;

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

} // namespace rts
