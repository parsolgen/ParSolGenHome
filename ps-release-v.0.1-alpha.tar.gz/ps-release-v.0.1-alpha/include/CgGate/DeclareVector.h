#pragma once

#include "MemoryOwningVectorHolder.h"

#include "Mpi/Mpi.h"

namespace rts
{

MemoryOwningVectorHolderD declare_vector_d(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n);

MemoryOwningVectorHolderD declare_vector_d(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n,
    std::size_t nvers_threshold);

MemoryOwningVectorHolderS declare_vector_s(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n);

MemoryOwningVectorHolderS declare_vector_s(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n,
    std::size_t nvers_threshold);

} // namespace rts
