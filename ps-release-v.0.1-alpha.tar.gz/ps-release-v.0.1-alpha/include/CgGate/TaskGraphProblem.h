#pragma once

#include "Matrix.h"

#include "TaskGraphDistributors/Types.h"
#include "Mpi/Mpi.h"
#include "Utils/MakeWithCapacity.h"
#include "Utils/ForEach.h"

#include <optional>
#include <unordered_set>

namespace rts
{
namespace impl
{

template<typename T>
struct is_matrix final : std::false_type {};

template<>
struct is_matrix<BlockedCSRMatrixSI> final
    : std::true_type {};

template<>
struct is_matrix<BlockedCSRMatrixDI> final
    : std::true_type {};

template<typename... Vs>
std::unordered_set<ArrayKey> build_matrices_set(const Vs&... vars)
{
    auto result = utils::MakeWithCapacity<std::unordered_set<ArrayKey>>(
        sizeof...(vars));
    utils::for_each([&result](const auto& var) {
        using T = std::decay_t<decltype(var)>;
        if constexpr (is_matrix<T>::value) {
            result.emplace(var.GetKey());
        }
    }, vars...);
    return result;
}

template<typename... Vs>
std::size_t get_var_holders_vector_size(const Vs&... vars)
{
    ArrayKey result = 0;
    utils::for_each([&result](const auto& holder) {
        result = std::max(result, holder.GetKey());
    }, vars...);
    return utils::cast_to_size(result) + 1;
}

} // namesapce impl

class RightLookingExecutor;
class TaskGraph;

namespace comm
{
class Communicator;
} // namespace comm


using TaskGraphPtr = std::unique_ptr<TaskGraph>;
using Distributor = std::function<TaskGraphDistribution(const TaskGraph&, int np)>;

class TaskGraphProblem final
{
public:
    ~TaskGraphProblem();

    TaskGraphProblem(const TaskGraphProblem&) = default;
    TaskGraphProblem(TaskGraphProblem&&) = default;
    TaskGraphProblem& operator=(const TaskGraphProblem&) = default;
    TaskGraphProblem& operator=(TaskGraphProblem&&) = default;

    void start();

    void stop();

    void reset();

    void reset_inside_iter_loop();

    void execute_and_wait();

    void distribute_matrices_root();

    void set_ready_var(const TaskArgument& arg);

private:
    void init_master_proc(const Distributor& task_graph_distributor);

    void init_slave_proc(int rank);

    void ctor_init(std::size_t nthreads);

private:
    struct IVariableDataHolder
    {
        virtual ~IVariableDataHolder() = default;

        virtual comm::SerializedMPIDataType recv_message_type(
            std::uint8_t* data,
            std::size_t byte_size) = 0;
        virtual TaskArgument insert_received_block(
            ArrayKey key,
            std::unique_ptr<std::uint8_t[]>&& block_mem) = 0;
        virtual comm::SerializedMPIDataType send_message_type(
            const TaskArgument& arg) = 0;

        virtual ArrayKey get_id() const = 0;
    };

    template<typename T>
    class VariableDataHolderImpl final : public IVariableDataHolder
    {
    public:
        explicit VariableDataHolderImpl(T& holder)
            : data_holder_{holder}
        {}

    public: // IVariableDataHolder
        virtual comm::SerializedMPIDataType recv_message_type(
            std::uint8_t* data,
            std::size_t byte_size) override
        {
            return data_holder_.GetMpiTypeForReceivingBlock(data, byte_size);
        }

        virtual TaskArgument insert_received_block(
            ArrayKey key,
            std::unique_ptr<std::uint8_t[]>&& block_mem) override
        {
            return data_holder_.InsertReceivedBlock(key, std::move(block_mem));
        }

        virtual ArrayKey get_id() const override
        {
            return data_holder_.GetKey();
        }

        virtual comm::SerializedMPIDataType send_message_type(
            const TaskArgument& arg) override
        {
            return data_holder_.GetMpiTypeForSendingBlock(arg);
        }
 
    private:
        T& data_holder_;
    };

    using IVariableDataHolderPtr = std::unique_ptr<IVariableDataHolder>;

public:
    TaskGraphProblem(
        TaskOperations ops,
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        std::unordered_set<ArrayKey> matrices_set,
        std::vector<IVariableDataHolderPtr> var_holders_vec,
        MPI_Comm mpi_comm);

private:
    static std::unique_ptr<TaskGraphProblem> create(
        TaskOperations ops,
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        std::unordered_set<ArrayKey> matrices_set,
        std::vector<IVariableDataHolderPtr> var_holders_vec,
        MPI_Comm mpi_comm);

    template<typename... Vs>
    friend std::unique_ptr<TaskGraphProblem> create_tg_problem(
        TaskOperations ops,
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        MPI_Comm mpi_comm,
        Vs&... vars);

private:
    IVariableDataHolderPtr& get_array_holder(ArrayKey array_id);

private:
    TaskOperations ops_;
    TaskGraphPtr task_graph_or_null_;
    int np_;
    MPI_Comm mpi_comm_;
    TaskGraphPtr local_task_graph_;
    std::unique_ptr<comm::Communicator> comm_;
    std::unique_ptr<RightLookingExecutor> executor_;
    std::size_t n_messages_to_receive_;
    std::size_t n_messages_to_receive_no_mtcs_;
    TaskGraphDistribution distr_;
    std::unordered_set<ArrayKey> matrices_set_;
    std::vector<IVariableDataHolderPtr> var_data_holders_;
    std::vector<TaskArgument> sp_mat_args_;
    int rank_ = 0;
};

template<typename... Vs>
std::unique_ptr<TaskGraphProblem> create_tg_problem(
    TaskOperations ops,
    TaskGraph* task_graph_or_null,
    std::size_t nthreads,
    int np,
    const Distributor& distributor,
    MPI_Comm mpi_comm,
    Vs&... vars)
{
    auto matrices_set = impl::build_matrices_set(vars...);
    std::vector<TaskGraphProblem::IVariableDataHolderPtr> var_data_holders;
    var_data_holders.resize(impl::get_var_holders_vector_size(
        std::forward<Vs>(vars)...));
    std::vector<TaskArgument> sp_mat_args;

    utils::for_each([&var_data_holders, &sp_mat_args](auto&& var_holder) {
        using T = std::decay_t<decltype(var_holder)>;
        const auto id = var_holder.GetKey();
        assert(id < var_data_holders.size());
        if constexpr (impl::is_matrix<T>::value) {
            for (int i = 0; i < var_holder.nb(); ++i) {
                for (int j = 0; j < var_holder.nb(); ++j) {
                    rts::TaskArgument arg{var_holder.GetKey(), 0, ArrayElementCoordinates<2>{
                        utils::cast_to_size(i), utils::cast_to_size(j)}};
                    if (!var_holder.is_zero(arg)) {
                        sp_mat_args.emplace_back(arg);
                    }
                }
            }
        }
        var_data_holders[id] = std::make_unique<TaskGraphProblem::VariableDataHolderImpl<T>>(
            var_holder);
    }, vars...);

    return TaskGraphProblem::create(
        std::move(ops),
        task_graph_or_null,
        nthreads,
        np,
        distributor,
        std::move(matrices_set),
        std::move(var_data_holders),
        mpi_comm);
}

} // namespace rts
