#pragma once

#include "TaskGraphProblem.h"

namespace rts
{

class TaskGraphProblemHolder final
{
public:
    void reset();
    void execute_and_wait();
    void stop();

    void broadcast_matrices_root();

    void set_ready_var(const TaskArgument& arg);

    TaskGraphProblem* get_prob_ptr();

    template<typename F>
    void initialize(F&& initializer)
    {
        if (task_graph_problem_or_null_ == nullptr) {
            task_graph_problem_or_null_ = initializer();
        }
    }

private:
    std::unique_ptr<TaskGraphProblem> task_graph_problem_or_null_ = nullptr;
};

} // namespace rts
