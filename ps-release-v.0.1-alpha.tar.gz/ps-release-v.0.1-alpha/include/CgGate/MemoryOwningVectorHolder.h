#pragma once

#include "Comm/ComplexTypeConstructor.h"
#include "Task/Task.h"

#include <variant>
#include <vector>
#include <memory>
#include <functional>

namespace rts
{

class MemoryOwningVectorHolderD final
{
public:
    MemoryOwningVectorHolderD(
        ArrayKey id,
        std::size_t nb,
        std::size_t block_n,
        std::size_t last_block_n);

    MemoryOwningVectorHolderD(
        ArrayKey id,
        std::size_t n,
        std::size_t block_n,
        std::size_t last_block_n,
        std::size_t nvers_threshold);

    ~MemoryOwningVectorHolderD();

    using element_t = double;

public:
    element_t* GetPtr(const TaskArgument& arg);

    const element_t* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& coords);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    std::size_t GetLen() const noexcept;

    std::vector<element_t>& GetDataOwner();

    const std::vector<element_t>& GetDataOwner() const;

    bool isLocal(const TaskArgument& var) const;

    bool isUpdatable() const;

public:
    using Op = std::function<void(ArrayElementCoord,
            ElementVersion,
            element_t*,
            std::size_t)>;

    void ForEachElementWithSpecifiedVersion(ElementVersion ver, Op op);

    void ForEachElementWithSpecifiedVersion(ElementVersion ver, Op op) const;

    void ForEachElementWithSpecifiedVersionParallel(ElementVersion ver, Op op);

    void ForEachElementWithSpecifiedVersionParallel(ElementVersion ver, Op op) const;

private:
    template<typename T>
    T* get_impl()
    {
        return reinterpret_cast<T*>(vector_holder_impl_);
    }

    template<typename T>
    const T* get_impl() const noexcept
    {
        return reinterpret_cast<const T*>(vector_holder_impl_);
    }

private:
    std::vector<element_t> initial_data_;
    bool updatable_ = false;
    std::uint8_t* vector_holder_impl_;
};

class MemoryOwningVectorHolderS final
{
public:
    MemoryOwningVectorHolderS(
        ArrayKey id,
        std::size_t nb,
        std::size_t block_n,
        std::size_t last_block_n);

    MemoryOwningVectorHolderS(
        ArrayKey id,
        std::size_t n,
        std::size_t block_n,
        std::size_t last_block_n,
        std::size_t nvers_threshold);

    ~MemoryOwningVectorHolderS();

    using element_t = double;

public:
    element_t* GetPtr(const TaskArgument& arg);

    const element_t* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& coords);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    std::size_t GetLen() const noexcept;

    std::vector<element_t>& GetDataOwner();

    const std::vector<element_t>& GetDataOwner() const;

    bool isLocal(const TaskArgument& var) const;

    bool isUpdatable() const;

public:
    using Op = std::function<void(ArrayElementCoord,
            ElementVersion,
            element_t*,
            std::size_t)>;

    void ForEachElementWithSpecifiedVersion(ElementVersion ver, Op op);

    void ForEachElementWithSpecifiedVersion(ElementVersion ver, Op op) const;

    void ForEachElementWithSpecifiedVersionParallel(ElementVersion ver, Op op);

    void ForEachElementWithSpecifiedVersionParallel(ElementVersion ver, Op op) const;

private:
    template<typename T>
    T* get_impl()
    {
        return reinterpret_cast<T*>(vector_holder_impl_);
    }

    template<typename T>
    const T* get_impl() const noexcept
    {
        return reinterpret_cast<const T*>(vector_holder_impl_);
    }

private:
    std::vector<element_t> initial_data_;
    bool updatable_ = false;
    std::uint8_t* vector_holder_impl_;
};

class ContiguousArray1D final
{
public:
    ContiguousArray1D(ArrayKey id, ArrayElementCoord n);
    ContiguousArray1D(ArrayKey id, ArrayElementCoordinates<1> dims);
    ContiguousArray1D(ArrayKey id, ArrayElementCoordinates<1> dims, double default_value);

    ~ContiguousArray1D();

public:
    double* GetPtr(const TaskArgument& arg);

    const double* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& coords);

    TaskArgument InsertReceivedBlock(ArrayKey id, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    bool isLocal(const TaskArgument& var);

    void free(const TaskArgument& var);

private:
    template<typename T>
    T* get_impl()
    {
        return reinterpret_cast<T*>(impl_);
    }

    template<typename T>
    const T* get_impl() const noexcept
    {
        return reinterpret_cast<const T*>(impl_);
    }

private:
    void* impl_;
};

class ContiguousArray1S final
{
public:
    ContiguousArray1S(ArrayKey id, ArrayElementCoord n);
    ContiguousArray1S(ArrayKey id, ArrayElementCoordinates<1> dims);
    ContiguousArray1S(ArrayKey id, ArrayElementCoordinates<1> dims, float default_value);

    ~ContiguousArray1S();

public:
    float* GetPtr(const TaskArgument& arg);

    const float* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& coords);

    TaskArgument InsertReceivedBlock(ArrayKey id, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    bool isLocal(const TaskArgument& var);

    void free(const TaskArgument& var);

private:
    template<typename T>
    T* get_impl()
    {
        return reinterpret_cast<T*>(impl_);
    }

    template<typename T>
    const T* get_impl() const noexcept
    {
        return reinterpret_cast<const T*>(impl_);
    }

private:
    void* impl_;
};

class ContiguousArray1I final
{
public:
    ContiguousArray1I(ArrayKey id, ArrayElementCoord n);
    ContiguousArray1I(ArrayKey id, ArrayElementCoordinates<1> dims);
    ContiguousArray1I(ArrayKey id, ArrayElementCoordinates<1> dims, int32_t default_value);

    ~ContiguousArray1I();

public:
    int32_t* GetPtr(const TaskArgument& arg);

    const int32_t* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& coords);

    TaskArgument InsertReceivedBlock(ArrayKey id, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    bool isLocal(const TaskArgument& var);

    void free(const TaskArgument& var);

private:
    template<typename T>
    T* get_impl()
    {
        return reinterpret_cast<T*>(impl_);
    }

    template<typename T>
    const T* get_impl() const noexcept
    {
        return reinterpret_cast<const T*>(impl_);
    }

private:
    void* impl_;
};

} // namespace rts
