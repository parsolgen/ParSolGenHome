#pragma once

#include "Task/Task.h"

#include <mutex>
#include <thread>
#include <vector>

namespace rts
{

class TaskGraphProblemHolder;

class TaskGraphsController final
{
public:
    void registerTGP(TaskGraphProblemHolder& prob);

    void set_ready_var(const TaskArgument& var);

private:
    std::mutex mutex_;
    std::vector<TaskGraphProblemHolder*> registered_tgps_;
    std::vector<TaskArgument> ready_vars_;
};

TaskGraphsController& get_tgpc();

} // namespace rts
