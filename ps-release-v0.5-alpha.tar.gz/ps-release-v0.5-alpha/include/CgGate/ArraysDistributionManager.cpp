#include "ArraysDistributionManager.h"

#include "TaskGraphProblemManager.h"

#include "Mpi/Mpi.h"

#include "Utils/FindAndAssert.h"

namespace rts
{

void ArrayDistributionMgr::init(ArrayKey max_n_arrays)
{
    MPI_CHECKED_CALL(MPI_Comm_rank(MPI_COMM_WORLD, &rank_));

    init_common(max_n_arrays);
    dd_arrays_distr_.emplace(max_n_arrays);

#ifndef NDEBUG
initialized_ = true;
#endif
}

void ArrayDistributionMgr::init(ArrayKey max_n_arrays, int n_cart_dims)
{
    if (n_cart_dims == 1) {
        init(max_n_arrays);
    }
    else if (n_cart_dims == 2) {
        init_common(max_n_arrays);
        dd_arrays_distr_.emplace(max_n_arrays, n_cart_dims);
    }
    else {
        assert(false);
    }

#ifndef NDEBUG
initialized_ = true;
#endif
}

void ArrayDistributionMgr::init_common(ArrayKey max_n_arrays)
{
    redistributed_arrays_distr_.emplace(max_n_arrays);
    redistributed_array_id_to_new_tgp_id_.reserve(max_n_arrays);

    dd_arrays_.resize(max_array_id + 1);

    gd_arrays_.resize(max_array_id + 1);
    gd_array_id_to_tgp_id_.resize(max_array_id + 1);
}

void ArrayDistributionMgr::register_dd_array(ArrayKey id, ArrayDimSize size)
{
#ifndef NDEBUG
assert(initialized_);
#endif
    assert(id < dd_arrays_.size());
    dd_arrays_[id] = true;
    dd_arrays_distr_.value().register_array(id, size);
}

void ArrayDistributionMgr::register_dd_array(ArrayKey id, ArrayDimSize size_x, ArrayDimSize size_y)
{
#ifndef NDEBUG
    assert(initialized_);
#endif
    assert(id < dd_arrays_.size());

    dd_arrays_[id] = true;
    dd_arrays_distr_.value().register_array(id, size_x, size_y);
}

void ArrayDistributionMgr::register_dd_array(
    ArrayKey id,
    const ArrayDimensions<2>& global_array_dims,
    const ArrayDimensions<2>& local_subarray_dims,
    const ArrayElementCoordinates<2>& local_subarray_coords)
{
#ifndef NDEBUG
    assert(initialized_);
#endif
    assert(id < dd_arrays_.size());
    dd_arrays_[id] = true;
    dd_arrays_distr_.value().register_array(
        id,
        global_array_dims,
        local_subarray_dims,
        local_subarray_coords);
}

std::vector<comm::ProcessCoord> ArrayDistributionMgr::get_target_procs(
    const TaskArgument& arg,
    comm::Communicator* comm) const
{
#ifndef NDEBUG
    assert(initialized_);
#endif

    if (get_array_distribution_type(arg.array_or_var) == DistributionType::Redistributed) {
        return { rank_ };
    }

    const auto array_id = arg.array_or_var;
    const auto distr_type = get_array_distribution_type(array_id);
    if (distr_type == DistributionType::DomainDecompositionDistribution) {
        return dd_arrays_distr_.value().get_target_procs(arg);
    }

    assert(distr_type == DistributionType::TaskGraphDistribution);
    assert(array_id < gd_array_id_to_tgp_id_.size());

    return get_target_procs_impl(arg, gd_array_id_to_tgp_id_[array_id]);
}

std::unordered_set<comm::ProcessCoord> ArrayDistributionMgr::get_target_procs_ignore_versions(
    const TaskArgument& arg,
    std::size_t tgp_id) const
{
#ifndef NDEBUG
    assert(initialized_);
#endif
    const auto distr_type = get_array_distribution_type(arg.array_or_var);
    if (distr_type == DistributionType::Redistributed) {
        return { rank_ };
    }

    assert(distr_type == DistributionType::TaskGraphDistribution);

    const auto& distr = get_tgp_mgr().get(tgp_id).get_prob_ptr()->get_non_versioned_distribution();
    return utils::find_and_assert(distr, to_array_element_descriptor(arg));
}

bool ArrayDistributionMgr::is_array_element_local(
    const TaskArgument& arg,
    std::size_t tgp_id) const
{
#ifndef NDEBUG
    assert(initialized_);
#endif

    assert(get_array_distribution_type(arg.array_or_var)
        == DistributionType::TaskGraphDistribution);

    const auto& target_procs = get_target_procs_ignore_versions(arg, tgp_id);
    return target_procs.find(rank_) != target_procs.end();
}

bool ArrayDistributionMgr::is_array_element_local(const TaskArgument& arg) const
{
#ifndef NDEBUG
    assert(initialized_);
#endif

    const auto distr_type = get_array_distribution_type(arg.array_or_var);

    if (distr_type == DistributionType::Redistributed) {
        return redistributed_arrays_distr_.value().is_local(arg);
    }
    else if (distr_type == DistributionType::DomainDecompositionDistribution) {
        return dd_arrays_distr_.value().is_local(arg);
    }

    const auto array_id = arg.array_or_var;
    assert(distr_type == DistributionType::TaskGraphDistribution);
    assert(array_id < gd_array_id_to_tgp_id_.size());

    return is_array_element_local(arg, gd_array_id_to_tgp_id_[array_id]);
}

void ArrayDistributionMgr::register_gd_array(ArrayKey id, std::size_t tgp_id)
{
#ifndef NDEBUG
    assert(initialized_);
#endif
    assert(id < dd_arrays_.size());
    dd_arrays_[id] = false;
    assert(id < gd_arrays_.size());
    gd_arrays_[id] = true;
    gd_array_id_to_tgp_id_[id] = tgp_id;
}

void ArrayDistributionMgr::reset(ArrayKey id)
{
#ifndef NDEBUG
    assert(initialized_);
#endif
    assert(id < dd_arrays_.size());
    dd_arrays_[id] = false;
    assert(id < gd_arrays_.size());
    gd_arrays_[id] = false;
}

std::vector<ArrayElementCoordinates<2>> ArrayDistributionMgr::get_array_local_elements(
    ArrayKey array_id,
    std::size_t tgp_id) const
{
#ifndef NDEBUG
    assert(initialized_);
#endif

    const auto distr_type = get_array_distribution_type(array_id);
    if (distr_type == DistributionType::DomainDecompositionDistribution) {
        return dd_arrays_distr_.value().get_local_elements(array_id);
    }
    else if (distr_type == DistributionType::Redistributed) {
        return redistributed_arrays_distr_.value().get_local_elements(array_id);
    }

    assert(array_id < gd_arrays_.size());

    const auto& distr = get_tgp_mgr().get(tgp_id).get_prob_ptr()->get_distribution();
    auto result = utils::MakeWithCapacity<std::vector<ArrayElementCoordinates<2>>>(
        distr.size());
    for (const auto& [var, targets] : distr) {
        if (var.array_or_var != array_id) {
            continue;
        }
        for (const auto proc : targets) {
            if (proc == rank_) {
                result.push_back(ArrayElementCoordinates<2>{var.coords_or_none[0], var.coords_or_none[1]});
            }
        }
    }
    return result;
}

[[nodiscard]]
std::vector<ArrayElementCoordinates<2>> ArrayDistributionMgr::get_array_local_elements(
    ArrayKey array_id) const
{
#ifndef NDEBUG
    assert(initialized_);
#endif

    const auto distr_type = get_array_distribution_type(array_id);
    if (distr_type == DistributionType::DomainDecompositionDistribution) {
        return dd_arrays_distr_.value().get_local_elements(array_id);
    }
    assert(distr_type == DistributionType::TaskGraphDistribution);
    assert(array_id < gd_array_id_to_tgp_id_.size());
    return get_array_local_elements(array_id, gd_array_id_to_tgp_id_[array_id]);
}

[[nodiscard]]
ArrayDistributionMgr::DistributionType ArrayDistributionMgr::get_array_distribution_type(
    ArrayKey id) const noexcept
{
#ifndef NDEBUG
    assert(initialized_);
#endif
    assert(id < max_array_id);
    assert(id < dd_arrays_.size());

    if (is_redistributed(id)) {
        return DistributionType::Redistributed;
    }

    if (dd_arrays_[id]) {
        return DistributionType::DomainDecompositionDistribution;
    }

    assert(id < gd_arrays_.size());
    assert(gd_arrays_[id]);

    return DistributionType::TaskGraphDistribution;
}

void ArrayDistributionMgr::register_redistributed_received_array_element(
    const TaskArgument& var)
{
#ifndef NDEBUG
    assert(initialized_);
#endif
    redistributed_arrays_distr_.value().set_local(to_array_element_descriptor(var));
}

std::size_t ArrayDistributionMgr::get_redistributed_tgp_id(
    ArrayKey array_id) const noexcept
{
    return utils::find_and_assert(
        redistributed_array_id_to_new_tgp_id_,
        array_id);
}

void ArrayDistributionMgr::register_redistributed_array(
    ArrayKey array_id,
    std::size_t tgp_id)
{
    redistributed_array_id_to_new_tgp_id_[array_id] = tgp_id;
}

void ArrayDistributionMgr::remove_redistributed_array_element(const TaskArgument& var)
{
    redistributed_arrays_distr_.value().reset_local(
        to_array_element_descriptor(var));
}

std::vector<comm::ProcessCoord> ArrayDistributionMgr::get_target_procs_impl(
    const TaskArgument& arg,
    std::size_t tgp_id) const
{
    const auto id = arg.array_or_var;
    const auto& distr = get_tgp_mgr().get(tgp_id).get_prob_ptr()->get_distribution();
    const auto it = distr.find(arg);
    assert(it != distr.end());
    return it->second;
}

ArrayDistributionMgr& get_var_distr_mgr()
{
    static ArrayDistributionMgr res{};
    return res;
}


} // namespace rts
