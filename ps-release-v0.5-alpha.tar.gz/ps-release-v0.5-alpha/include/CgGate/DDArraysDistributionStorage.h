#pragma once

#include "NonVersionedArrayElementsBitmap.h"

#include "Comm/Types.h"
#include "Task/Task.h"

#include <deque>

namespace rts
{

namespace comm
{
class Communicator;
} // namespace comm

class DDArraysDistribtionStorage final
{
public:
    explicit DDArraysDistribtionStorage(
        ArrayKey max_n_arrays);
    DDArraysDistribtionStorage(ArrayKey max_n_arrays, int n);

    void register_array(ArrayKey array_id, ArrayDimSize n1);
    void register_array(ArrayKey array_id, ArrayDimSize n1, ArrayDimSize n2);
    void register_array(
        ArrayKey array_id,
        const ArrayDimensions<2>& global_array_dims,
        const ArrayDimensions<2>& local_subarray_dims,
        const ArrayElementCoordinates<2>& local_subarray_coords);

    [[nodiscard]]
    bool is_local(const TaskArgument& var) const noexcept;

    std::vector<comm::ProcessCoord> get_target_procs(
        const TaskArgument& var) const;

    std::vector<ArrayElementCoordinates<2>> get_local_elements(
        ArrayKey array_id) const noexcept;

    template<typename F>
    void for_each_no_version(ArrayKey array_id, F op) const noexcept
    {
        assert(array_id < array_id_to_local_elements_.size());
        for (const auto& el : array_id_to_local_elements_[array_id]) {
            op(TaskArgument{array_id, 0, el});
        }
    }

    template<typename F>
    void for_each_no_version(ArrayKey array_id, F op)
    {
        assert(array_id < array_id_to_local_elements_.size());
        for (const auto& el : array_id_to_local_elements_[array_id]) {
            op(TaskArgument{array_id, 0, el});
        }
    }

private:
    using LocalElementCoordinatesVector = std::vector<ArrayElementCoordinates<2>>;

    int rank_ = 0;
    std::deque<ArrayDimSize> dd_arrays_size_x_;
    std::deque<ArrayDimSize> dd_arrays_size_y_;
    comm::ProcessCoordinates<2> cart_coords_;
    comm::ProcessCoordinates<2> cart_dims_;
    std::deque<LocalElementCoordinatesVector> array_id_to_local_elements_;
    std::deque<bool> registered_;
};

} // namespace rts
