#pragma once

#include "ArrayHolders/CSRMatrixBlock.h"

#include "Comm/ComplexTypeConstructor.h"
#include "Comm/Types.h"
#include "Task/Task.h"
#include "Utils/Unreachable.h"
#include "Utils/Unused.h"

#include <stdfloat>

namespace rts
{

class BlockedCSRMatrixDI final
{
public:
    using I = std::int32_t;
    using A = double;
    static constexpr const bool is_matrix = true;
    using element_t = double;

public:
  BlockedCSRMatrixDI(ArrayKey key, I n, I m, I nnz, I* ia, I* ja, A* a, I nb, I mb);
  explicit BlockedCSRMatrixDI(ArrayKey key);
  ~BlockedCSRMatrixDI();

public:
  CSRMatrixBlock<I, A> get(const ArrayElementCoordinates<2>& coords);

  CSRMatrixBlock<I, A> get(const TaskArgument& arg);

  CSRMatrixBlock<I, A> GetPtr(const TaskArgument& arg) {
    SG_UNUSED_PARAMETER(arg);
    sg_unreachable();
  }

  std::size_t GetLen(const TaskArgument& var) {
    SG_UNUSED_PARAMETER(var);
    sg_unreachable();
  }

  bool is_zero(const ArrayElementCoordinates<2>& coords) const;

  bool is_zero(const TaskArgument& arg) const;

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const ArrayElementCoordinates<2>& coords);

  comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(std::uint8_t* data, std::size_t byte_size);

  TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& data);

  void remove_element(const TaskArgument& arg) {
    SG_UNUSED_PARAMETER(arg);
    sg_unreachable();
  }

  I* ia();

  const I* ia() const;

  I* ja();

  const I* ja() const;

  A* a();

  const A* a() const;

  std::size_t nblocks() const;

  I n() const;

  ArrayKey GetKey() const;

  I nb() const;

  I mb() const;

  static constexpr const bool is_blocked_csr_matrix = true;
  void reset() {}

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class BlockedCSRMatrixSI final
{
public:
    using I = std::int32_t;
    using A = float;
    static constexpr const bool is_matrix = true;
    using element_t = float;

public:
  BlockedCSRMatrixSI(ArrayKey key, I n, I m, I nnz, I* ia, I* ja, A* a, I nb, I mb);
  explicit BlockedCSRMatrixSI(ArrayKey key);
  ~BlockedCSRMatrixSI();

public:
  CSRMatrixBlock<I, A> get(const ArrayElementCoordinates<2>& coords);

  CSRMatrixBlock<I, A> get(const TaskArgument& arg);

  CSRMatrixBlock<I, A> GetPtr(const TaskArgument& arg) {
    SG_UNUSED_PARAMETER(arg);
    sg_unreachable();
  }

  std::size_t GetLen(const TaskArgument& var) {
    SG_UNUSED_PARAMETER(var);
    sg_unreachable();
  }

  bool is_zero(const ArrayElementCoordinates<2>& coords) const;

  bool is_zero(const TaskArgument& arg) const;

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const ArrayElementCoordinates<2>& coords);

  comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(std::uint8_t* data, std::size_t byte_size);

  TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& data);

  inline
  void remove_element(const TaskArgument& arg) {
    SG_UNUSED_PARAMETER(arg);
    sg_unreachable();
  }

  I* ia();

  const I* ia() const;

  I* ja();

  const I* ja() const;

  A* a();

  const A* a() const;

  std::size_t nblocks() const;

  I n() const;

  ArrayKey GetKey() const;

  I nb() const;

  I mb() const;

  void reset() {}

  static constexpr const bool is_blocked_csr_matrix = true;

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class BlockedCSRMatrixF16 final
{
public:
    using I = std::int32_t;
    using A = std::float16_t;
    static constexpr const bool is_matrix = true;
    using element_t = std::float16_t;

public:
  BlockedCSRMatrixF16(ArrayKey key, I n, I m, I nnz, I* ia, I* ja, A* a, I nb, I mb);
  explicit BlockedCSRMatrixF16(ArrayKey key);
  ~BlockedCSRMatrixF16();

public:
  CSRMatrixBlock<I, A> get(const ArrayElementCoordinates<2>& coords);

  CSRMatrixBlock<I, A> get(const TaskArgument& arg);

  CSRMatrixBlock<I, A> GetPtr(const TaskArgument& arg) {
    SG_UNUSED_PARAMETER(arg);
    sg_unreachable();
  }

  std::size_t GetLen(const TaskArgument& var) {
    SG_UNUSED_PARAMETER(var);
    sg_unreachable();
  }

  bool is_zero(const ArrayElementCoordinates<2>& coords) const;

  bool is_zero(const TaskArgument& arg) const;

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const ArrayElementCoordinates<2>& coords);

  comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(std::uint8_t* data, std::size_t byte_size);

  TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& data);

  inline
  void remove_element(const TaskArgument& arg) {
    SG_UNUSED_PARAMETER(arg);
    sg_unreachable();
  }

  I* ia();

  const I* ia() const;

  I* ja();

  const I* ja() const;

  A* a();

  const A* a() const;

  std::size_t nblocks() const;

  I n() const;

  ArrayKey GetKey() const;

  I nb() const;

  I mb() const;

  static constexpr const bool is_blocked_csr_matrix = true;

  void reset() {}

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class BlockedCSRMatrixBF16 final
{
public:
    using I = std::int32_t;
    using A = std::float16_t;
    static constexpr const bool is_matrix = true;
    using element_t = std::float16_t;

public:
  BlockedCSRMatrixBF16(ArrayKey key, I n, I m, I nnz, I* ia, I* ja, A* a, I nb, I mb);
  explicit BlockedCSRMatrixBF16(ArrayKey key);
  ~BlockedCSRMatrixBF16();

public:
  CSRMatrixBlock<I, A> get(const ArrayElementCoordinates<2>& coords);

  CSRMatrixBlock<I, A> get(const TaskArgument& arg);

  CSRMatrixBlock<I, A> GetPtr(const TaskArgument& arg) {
    SG_UNUSED_PARAMETER(arg);
    sg_unreachable();
  }

  std::size_t GetLen(const TaskArgument& var) {
    SG_UNUSED_PARAMETER(var);
    sg_unreachable();
  }

  bool is_zero(const ArrayElementCoordinates<2>& coords) const;

  bool is_zero(const TaskArgument& arg) const;

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

  comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const ArrayElementCoordinates<2>& coords);

  comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(std::uint8_t* data, std::size_t byte_size);

  TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& data);

  inline
  void remove_element(const TaskArgument& arg) {
    SG_UNUSED_PARAMETER(arg);
    sg_unreachable();
  }

  I* ia();

  const I* ia() const;

  I* ja();

  const I* ja() const;

  A* a();

  const A* a() const;

  std::size_t nblocks() const;

  I n() const;

  ArrayKey GetKey() const;

  I nb() const;

  I mb() const;

  static constexpr const bool is_blocked_csr_matrix = true;

  void reset() {}

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class NonUpdatableBlockCyclicDistributedMatrixD final
{
public:
    NonUpdatableBlockCyclicDistributedMatrixD(
        ArrayKey array_id,
        ArrayDimensions<2> global_dims,
        ArrayDimensions<2> block_dims,
        comm::ProcessCoordinates<2> comm_coords,
        comm::ProcessCoordinates<2> comm_size);

    ~NonUpdatableBlockCyclicDistributedMatrixD();

    using element_t = double;

public:
    double* GetPtr(const TaskArgument& arg);

    const double* GetPtr(const TaskArgument& arg) const;

    const double* GetInPtr(const TaskArgument& arg) const;    

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(
        const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(
        ArrayKey key,
        std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& arg) const;

    double* GetLatestElementPtr(const TaskArgument& arg);

    const double* GetLatestElementPtr(const TaskArgument& arg) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    void reset() {}

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class NonUpdatableBlockCyclicDistributedMatrixS final
{
public:
    NonUpdatableBlockCyclicDistributedMatrixS(
        ArrayKey array_id,
        ArrayDimensions<2> global_dims,
        ArrayDimensions<2> block_dims,
        comm::ProcessCoordinates<2> comm_coords,
        comm::ProcessCoordinates<2> comm_size);

    ~NonUpdatableBlockCyclicDistributedMatrixS();

    using element_t = float;

public:
    float* GetPtr(const TaskArgument& arg);

    const float* GetPtr(const TaskArgument& arg) const;

    const float* GetInPtr(const TaskArgument& arg) const;    

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(
        const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(
        ArrayKey key,
        std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& arg) const;

    float* GetLatestElementPtr(const TaskArgument& arg);

    const float* GetLatestElementPtr(const TaskArgument& arg) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;
    
    void reset() {}

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class NonUpdatableBlockCyclicDistributedMatrixF16 final
{
public:
    NonUpdatableBlockCyclicDistributedMatrixF16(
        ArrayKey array_id,
        ArrayDimensions<2> global_dims,
        ArrayDimensions<2> block_dims,
        comm::ProcessCoordinates<2> comm_coords,
        comm::ProcessCoordinates<2> comm_size);

    ~NonUpdatableBlockCyclicDistributedMatrixF16();

    using element_t = std::float16_t;

public:
    std::float16_t* GetPtr(const TaskArgument& arg);

    const std::float16_t* GetPtr(const TaskArgument& arg) const;

    const std::float16_t* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(
        const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(
        ArrayKey key,
        std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& arg) const;

    std::float16_t* GetLatestElementPtr(const TaskArgument& arg);

    const std::float16_t* GetLatestElementPtr(const TaskArgument& arg) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    void reset() {}

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

class NonUpdatableBlockCyclicDistributedMatrixBF16 final
{
public:
    NonUpdatableBlockCyclicDistributedMatrixBF16(
        ArrayKey array_id,
        ArrayDimensions<2> global_dims,
        ArrayDimensions<2> block_dims,
        comm::ProcessCoordinates<2> comm_coords,
        comm::ProcessCoordinates<2> comm_size);

    ~NonUpdatableBlockCyclicDistributedMatrixBF16();

    using element_t = std::bfloat16_t;

public:
    std::bfloat16_t* GetPtr(const TaskArgument& arg);

    const std::bfloat16_t* GetPtr(const TaskArgument& arg) const;

    const std::bfloat16_t* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(
        const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(
        ArrayKey key,
        std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& arg) const;

    std::bfloat16_t* GetLatestElementPtr(const TaskArgument& arg);

    const std::bfloat16_t* GetLatestElementPtr(const TaskArgument& arg) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    void reset() {}

private:
    template<typename T>
    T* get_internal_mr()
    {
        return reinterpret_cast<T*>(internal_representation_);
    }

    template<typename T>
    const T* get_internal_mr() const noexcept
    {
        return reinterpret_cast<const T*>(internal_representation_);
    }

private:
    std::uint8_t* internal_representation_ = nullptr;
};

} // namespace rts
