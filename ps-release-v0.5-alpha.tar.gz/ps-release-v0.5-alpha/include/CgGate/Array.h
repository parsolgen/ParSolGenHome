#pragma once

#include "ArrayHolders/CSRMatrixBlock.h"

#include "Comm/ComplexTypeConstructor.h"
#include "Comm/Types.h"
#include "Task/Task.h"

#include "Utils/Unused.h"
#include "Utils/Unreachable.h"

#include <stdfloat>

namespace rts
{

namespace impl
{
struct IExternalOutputArrayPtr;
} // namespace impl

class ExternalOutputArrayPtrD final
{
public:
    explicit ExternalOutputArrayPtrD(
        std::unique_ptr<impl::IExternalOutputArrayPtr>&& impl);

    double* get() noexcept;

    ~ExternalOutputArrayPtrD();

private:
    std::unique_ptr<impl::IExternalOutputArrayPtr> impl_;
};

class ExternalOutputArrayPtrS final
{
public:
    explicit ExternalOutputArrayPtrS(
        std::unique_ptr<impl::IExternalOutputArrayPtr>&& impl);

    float* get() noexcept;

    ~ExternalOutputArrayPtrS();

private:
    std::unique_ptr<impl::IExternalOutputArrayPtr> impl_;
};

class NonUpdatableGeneralArrayHolderS final
{
public:
    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<3>& block_size,
        const ArrayDimensions<3>& last_block_size);

    ~NonUpdatableGeneralArrayHolderS();

    using element_t = float;

public:
    float* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const float* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const float* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    float* GetLatestElementPtr(const TaskArgument& arg);

    const float* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    ArrayDimensions<2> get_block_dim(const ArrayElementCoordinates<2>& coords) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    [[nodiscard]]
    int get_n() const noexcept;

    void remove_element(const TaskArgument& arg)
    {
        SG_UNUSED_PARAMETER(arg);
        sg_unreachable();
    }

    void reset() {}

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class NonUpdatableGeneralArrayHolderF16 final
{
public:
    NonUpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<3>& block_size,
        const ArrayDimensions<3>& last_block_size);

    ~NonUpdatableGeneralArrayHolderF16();

    using element_t = std::float16_t;

public:
    std::float16_t* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const std::float16_t* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const std::float16_t* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    std::float16_t* GetLatestElementPtr(const TaskArgument& arg);

    const std::float16_t* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    ArrayDimensions<2> get_block_dim(const ArrayElementCoordinates<2>& coords) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    [[nodiscard]]
    int get_n() const noexcept;

    void remove_element(const TaskArgument& arg)
    {
        SG_UNUSED_PARAMETER(arg);
        sg_unreachable();
    }

    void reset() {}

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class NonUpdatableGeneralArrayHolderBF16 final
{
public:
    NonUpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<3>& block_size,
        const ArrayDimensions<3>& last_block_size);

    ~NonUpdatableGeneralArrayHolderBF16();

    using element_t = std::bfloat16_t;

public:
    std::bfloat16_t* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const std::bfloat16_t* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const std::bfloat16_t* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    std::bfloat16_t* GetLatestElementPtr(const TaskArgument& arg);

    const std::bfloat16_t* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    ArrayDimensions<2> get_block_dim(const ArrayElementCoordinates<2>& coords) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    [[nodiscard]]
    int get_n() const noexcept;

    void remove_element(const TaskArgument& arg)
    {
        SG_UNUSED_PARAMETER(arg);
        sg_unreachable();
    }

    void reset() {}

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class NonUpdatableGeneralArrayHolderD final
{
public:
    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<3>& global_array_dims,
        ArrayDimensions<3> local_subarray_dims,
        ArrayElementCoordinates<3> local_subarray_coords,
        const ArrayDimensions<3>& block_size,
        const ArrayDimensions<3>& last_block_size);

    ~NonUpdatableGeneralArrayHolderD();

    using element_t = double;

public:
    double* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const double* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const double* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    double* GetLatestElementPtr(const TaskArgument& arg);

    const double* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    ArrayDimensions<2> get_block_dim(const ArrayElementCoordinates<2>& coords) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    [[nodiscard]]
    int get_n() const noexcept;

    void remove_element(const TaskArgument& arg)
    {
        SG_UNUSED_PARAMETER(arg);
        sg_unreachable();
    }

    void reset() {}

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class ExternalOutNonUpdatableGeneralArrayHolderS final
{
public:
    ExternalOutNonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ArrayDimensions<1> block_size,
        ArrayDimensions<1> last_block_size,
        std::string connection_string);

    ExternalOutNonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ArrayDimensions<2> block_size,
        ArrayDimensions<2> last_block_size,
        std::string connection_string);

    ~ExternalOutNonUpdatableGeneralArrayHolderS();

    using element_t = float;

public:
    ExternalOutputArrayPtrS GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const float* GetPtr(const TaskArgument& arg) const;

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    ExternalOutputArrayPtrS GetLatestElementPtr(const TaskArgument& arg);

    const float* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    void reset() {}

private:
    ArrayDim bn_;
    void* impl_;
};

class ExternalOutNonUpdatableGeneralArrayHolderD final
{
public:
    ExternalOutNonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ArrayDimensions<1> block_size,
        ArrayDimensions<1> last_block_size,
        std::string connection_string);

    ExternalOutNonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ArrayDimensions<2> block_size,
        ArrayDimensions<2> last_block_size,
        std::string connection_string);

    ~ExternalOutNonUpdatableGeneralArrayHolderD();

    using element_t = float;

public:
    ExternalOutputArrayPtrD GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const double* GetPtr(const TaskArgument& arg) const;

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    ExternalOutputArrayPtrD GetLatestElementPtr(const TaskArgument& arg);

    const double* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    void reset() {}

private:
    ArrayDim bn_;
    void* impl_;
};

class UpdatableGeneralArrayHolderS final
{
public:
    UpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    UpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    UpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    UpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    ~UpdatableGeneralArrayHolderS();

    using element_t = float;

public:
    float* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const float* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const float* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    float* GetLatestElementPtr(const TaskArgument& arg);

    const float* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    ArrayDimensions<2> get_block_dim(const ArrayElementCoordinates<2>& coords) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    [[nodiscard]]
    int get_n() const noexcept;

    void remove_element(const TaskArgument& arg)
    {
        SG_UNUSED_PARAMETER(arg);
        sg_unreachable();
    }

    void reset() {}

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class UpdatableGeneralArrayHolderD final
{
public:
    UpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    UpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    UpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    UpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    ~UpdatableGeneralArrayHolderD();

    using element_t = double;

public:
    double* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const double* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const double* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    double* GetLatestElementPtr(const TaskArgument& arg);

    const double* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    ArrayDimensions<2> get_block_dim(const ArrayElementCoordinates<2>& coords) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    [[nodiscard]]
    int get_n() const noexcept;

    void remove_element(const TaskArgument& arg)
    {
        SG_UNUSED_PARAMETER(arg);
        sg_unreachable();
    }

    void reset() {}

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class UpdatableGeneralArrayHolderF16 final
{
public:
    UpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    UpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    UpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    UpdatableGeneralArrayHolderF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    ~UpdatableGeneralArrayHolderF16();

    using element_t = std::float16_t;

public:
    std::float16_t* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const std::float16_t* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const std::float16_t* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    std::float16_t* GetLatestElementPtr(const TaskArgument& arg);

    const std::float16_t* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    ArrayDimensions<2> get_block_dim(const ArrayElementCoordinates<2>& coords) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    [[nodiscard]]
    int get_n() const noexcept;

    void remove_element(const TaskArgument& arg)
    {
        SG_UNUSED_PARAMETER(arg);
        sg_unreachable();
    }

    void reset() {}

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class UpdatableGeneralArrayHolderBF16 final
{
public:
    UpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    UpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    UpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    UpdatableGeneralArrayHolderBF16(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    ~UpdatableGeneralArrayHolderBF16();

    using element_t = std::bfloat16_t;

public:
    std::bfloat16_t* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const std::bfloat16_t* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const std::bfloat16_t* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    std::bfloat16_t* GetLatestElementPtr(const TaskArgument& arg);

    const std::bfloat16_t* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    ArrayDimensions<2> get_block_dim(const ArrayElementCoordinates<2>& coords) const;

    [[nodiscard]]
    int get_block_n(int dim) const;

    [[nodiscard]]
    int get_n_blocks(int dim) const;

    [[nodiscard]]
    int get_n() const noexcept;

    void remove_element(const TaskArgument& arg)
    {
        SG_UNUSED_PARAMETER(arg);
        sg_unreachable();
    }

    void reset() {}

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

} // namespace rts
