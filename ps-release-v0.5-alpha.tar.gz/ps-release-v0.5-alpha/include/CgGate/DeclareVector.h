#pragma once

#include "MemoryOwningVectorHolder.h"

#include "Mpi/Mpi.h"

namespace rts
{

MemoryOwningVectorHolderD declare_vector_d(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n);

MemoryOwningVectorHolderD declare_vector_d(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n,
    std::size_t nvers_threshold);

//

MemoryOwningVectorHolderF16 declare_vector_f16(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n);

MemoryOwningVectorHolderF16 declare_vector_f16(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n,
    std::size_t nvers_threshold);

//

MemoryOwningVectorHolderBF16 declare_vector_bf16(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n);

MemoryOwningVectorHolderBF16 declare_vector_bf16(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n,
    std::size_t nvers_threshold);

//

MemoryOwningVectorHolderS declare_vector_s(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n);

MemoryOwningVectorHolderS declare_vector_s(
    ArrayKey id,
    std::size_t nb,
    std::size_t block_n,
    std::size_t last_block_n,
    std::size_t nvers_threshold);

} // namespace rts
