#pragma once

#include "DDArraysDistributionStorage.h"

#include "Comm/Types.h"
#include "Comm/Communicator.h"

#include "Task/Task.h"

#include "Utils/AssertOptional.h"

namespace rts
{

class ArrayDistributionMgr final
{
public:
    enum class DistributionType
    {
        DomainDecompositionDistribution,
        TaskGraphDistribution,
        Redistributed
    };

public:
    ArrayDistributionMgr() = default;

    void init(ArrayKey max_n_arrays);
    void init(ArrayKey max_n_arrays, int n_cart_dims);
    void register_dd_array(ArrayKey id, ArrayDimSize size);
    void register_dd_array(ArrayKey id, ArrayDimSize size_x, ArrayDimSize size_y);
    void register_dd_array(
        ArrayKey id,
        const ArrayDimensions<2>& global_array_dims,
        const ArrayDimensions<2>& local_subarray_dims,
        const ArrayElementCoordinates<2>& local_subarray_coords);
    [[nodiscard]]
    std::vector<comm::ProcessCoord> get_target_procs(
        const TaskArgument& arg,
        comm::Communicator* comm) const;
    [[nodiscard]]
    std::unordered_set<comm::ProcessCoord> get_target_procs_ignore_versions(
        const TaskArgument& arg,
        std::size_t tgp_id) const;
    [[nodiscard]]
    bool is_array_element_local(const TaskArgument& arg, std::size_t tgp_id) const;
    [[nodiscard]]
    bool is_array_element_local(const TaskArgument& arg) const;
    void register_gd_array(ArrayKey id, std::size_t tgp_id);
    void reset(ArrayKey id);
    [[nodiscard]]
    std::vector<ArrayElementCoordinates<2>> get_array_local_elements(
        ArrayKey array_id,
        std::size_t tgp_id) const;
    [[nodiscard]]
    std::vector<ArrayElementCoordinates<2>> get_array_local_elements(
        ArrayKey array_id) const;
    [[nodiscard]]
    inline
    std::vector<ArrayElementCoordinates<2>> get_array_local_elements_no_version(
        ArrayKey array_id,
        std::size_t tgp_id) const
    {
        return get_array_local_elements(array_id, tgp_id);
    }
    [[nodiscard]]
    inline
    std::vector<ArrayElementCoordinates<2>> get_array_local_elements_no_version(
        ArrayKey array_id) const
    {
        return get_array_local_elements(array_id);
    }
    [[nodiscard]]
    DistributionType get_array_distribution_type(ArrayKey id) const noexcept;

    void register_redistributed_received_array_element(const TaskArgument& var);

    [[nodiscard]]
    std::size_t get_redistributed_tgp_id(ArrayKey array_id) const noexcept;

    void register_redistributed_array(ArrayKey array_id, std::size_t tgp_id);
    void remove_redistributed_array_element(const TaskArgument& var);

    template<typename F>
    void for_each_no_version(ArrayKey array_id, F op)
    {
        switch (get_array_distribution_type(array_id))
        {
        case DistributionType::DomainDecompositionDistribution:
            dd_arrays_distr_.value().for_each_no_version(
                array_id,
                std::forward<F>(op));
            break;
        case DistributionType::Redistributed:
            redistributed_arrays_distr_.value().for_each_local_element(
                array_id,
                std::forward<F>(op));
            break;
        case DistributionType::TaskGraphDistribution:
            assert(false);
            break;
        default:
            assert(false);
        }
    }

private:
    [[nodiscard]]
    std::vector<comm::ProcessCoord> get_target_procs_impl(
        const TaskArgument& arg,
        std::size_t tgp_id) const;

    [[nodiscard]]
    inline
    std::size_t get_target_tgp_id(ArrayKey array_id) const noexcept
    {
        assert(array_id < gd_arrays_.size());
        assert(gd_arrays_[array_id]);

        return gd_array_id_to_tgp_id_[array_id];
    }

    [[nodiscard]]
    inline
    bool is_redistributed(ArrayKey array_id) const noexcept
    {
        return redistributed_array_id_to_new_tgp_id_.find(array_id)
            != redistributed_array_id_to_new_tgp_id_.end();
    }

    void init_common(ArrayKey max_n_arrays);

private:
    static constexpr const ArrayKey max_array_id = 10000;
    using ArrayIdToRedistributedTgpId = std::unordered_map<ArrayKey, std::size_t>;

    ArrayIdToRedistributedTgpId redistributed_array_id_to_new_tgp_id_;
    utils::AssertOptional<NonVersionedArrayElementsBitmap> redistributed_arrays_distr_;
    utils::AssertOptional<DDArraysDistribtionStorage> dd_arrays_distr_;

    comm::ProcessCoord rank_;
    int np_;
    std::vector<bool> dd_arrays_;
    std::vector<bool> gd_arrays_;
    std::vector<std::size_t> gd_array_id_to_tgp_id_;
#ifndef NDEBUG
    bool initialized_ = false;
#endif
};

ArrayDistributionMgr& get_var_distr_mgr();

} // namespace rts