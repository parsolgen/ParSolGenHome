#pragma once

#include "DeclareArray.h"
#include "DeclareVector.h"
#include "TaskGraphProblem.h"
#include "TaskGraphProblemHolder.h"
#include "DeclareVector.h"
#include "Matrix.h"
#include "BlockCyclicTaskGraphDistributor.h"
#include "SparseDomainTaskGraphDistributor.h"
#include "ExplicitSolverTaskGraphDistributor.h"
#include "TaskGraphUtils.h"
#include "TaskGraphsController.h"
#include "Utils.h"

#include "Mpi/Mpi.h"
#include "Task/Task.h"
#include "ArrayHolders/CSRMatrixBlock.h"
#include "ArrayHolders/TmpContiguousArray.h"
#include "ArrayHolders/ContiguousArray.h"
#include "ArrayHolders/NonUpdatableGeneralGrowingVectorHolder.h"
#include "Executors/RightLookingExecutorInfo.h"
#include "Comm/Utils.h"
#include "TaskGraphDistributors/ExplicitSolverGraphDistributor.h"
#include "ESSUtils/ESSDistributorContainer.h"
#include "ESSUtils/ESSUtils.h"

#ifdef SG_USE_GOOPAX
#include "DeviceUtils/GoopaxBuffer.h"
#endif

#include "Algorithms/Max.h"
#include "VectorUtils/VectorUtils.h"

#ifdef SG_USE_ACCEL
#include "DeviceUtils/Types.h"
#include "DeviceUtils/Init.h"
#endif

#ifdef SG_USE_GOOPAX
#include <goopax>
#endif

namespace rts
{

class TaskGraph;
class ESSProblemHolder;
class ESSDistributor;

namespace comm
{

int get_comm_size(MPI_Comm comm);

} // namespace comm

namespace internal
{

using ArrayHolder = std::variant<
    MemoryOwningVectorHolderS*,
    MemoryOwningVectorHolderD*,
    MemoryOwningVectorHolderF16*,
    MemoryOwningVectorHolderBF16*,
    BlockedCSRMatrixDI*,
    BlockedCSRMatrixSI*,
    NonUpdatableGeneralArrayHolderS*,
    NonUpdatableGeneralArrayHolderF16*,
    NonUpdatableGeneralArrayHolderBF16*,
    NonUpdatableGeneralArrayHolderD*,
    UpdatableGeneralArrayHolderS*,
    UpdatableGeneralArrayHolderD*,
    UpdatableGeneralArrayHolderF16*,
    UpdatableGeneralArrayHolderBF16*,
    INonUpdatableSerializableArray*>;

class ArrayHoldersMgr final
{
public:
    void register_vec_holder(MemoryOwningVectorHolderD& holder);

    void register_vec_holder(MemoryOwningVectorHolderS& holder);

    void register_vec_holder(MemoryOwningVectorHolderF16& holder);

    void register_vec_holder(MemoryOwningVectorHolderBF16& holder);

    void register_nu_array(NonUpdatableGeneralArrayHolderD& array);

    void register_nu_array(NonUpdatableGeneralArrayHolderS& array);

    void register_nu_array(NonUpdatableGeneralArrayHolderF16& array);

    void register_nu_array(NonUpdatableGeneralArrayHolderBF16& array);

    template<ArrayDim N, typename T>
    void register_nu_growing_array(NonUpdatableGeneralGrowingVectorHolder<N, T>& array)
    {
        id_to_array_holder_[array.GetKey()] = &array;
    }

    void register_spmat(BlockedCSRMatrixDI& holder);

    void register_spmat(BlockedCSRMatrixSI& holder);

    template<typename V>
    constexpr
    decltype(auto) visit(ArrayKey id, V visitor)
    {
        auto it = id_to_array_holder_.find(id);
        assert(it != id_to_array_holder_.end());

        return std::visit([&visitor](auto* raw_holder) {
            return visitor(raw_holder);
        }, it->second);
    }

    template<typename V>
    constexpr
    decltype(auto) visit(ArrayKey id, V visitor) const
    {
        const auto it = id_to_array_holder_.find(id);
        assert(it != id_to_array_holder_.end());

        return std::visit([&visitor](const auto* raw_holder) {
            return visitor(raw_holder);
        }, it->second);
    }

    void remove_element(const TaskArgument& var);

private:
    std::unordered_map<ArrayKey, ArrayHolder> id_to_array_holder_;
};

ArrayHoldersMgr& get_array_holders_mgr();

template<typename V>
decltype(auto) visit_array_holder(ArrayKey id, V&& visitor)
{
    return get_array_holders_mgr().visit(id, std::forward<V>(visitor));
}

void parse_command_line_args(int argc, char** argv);
void register_dd_array(ArrayKey id, std::size_t size);

using InternalTask = std::function<void(std::size_t)>;
void exec_thread_specific_task(std::size_t tid, InternalTask task);
std::size_t get_n_threads();
void exec_task(InternalTask t);

void exec_hp_task(InternalTask t);
void exec_thread_specific_hp_task(std::size_t tid, InternalTask task);

#ifdef SG_USE_ACCEL
void exec_dev_task(InternalTask t, DeviceId dev_id);
void exec_dev_hp_task(InternalTask t, DeviceId dev_id);
#endif

void register_vec_holder(MemoryOwningVectorHolderD& v);
void register_vec_holder(MemoryOwningVectorHolderS& v);
void register_vec_holder(MemoryOwningVectorHolderF16& v);
void register_vec_holder(MemoryOwningVectorHolderBF16& v);

void register_nu_array(NonUpdatableGeneralArrayHolderD& array);
void register_nu_array(NonUpdatableGeneralArrayHolderS& array);
void register_nu_array(NonUpdatableGeneralArrayHolderF16& array);
void register_nu_array(NonUpdatableGeneralArrayHolderBF16& array);
template<ArrayDim N, typename T>
void register_nu_growing_array(NonUpdatableGeneralGrowingVectorHolder<N, T>& array)
{
    internal::get_array_holders_mgr().register_nu_growing_array(array);
}

void register_tg(std::size_t tgp_id, TaskGraph& local_graph);

void* get_ptr_by_arg(const TaskArgument& var);
const void* get_in_ptr_by_arg(const TaskArgument& var);
void register_array_id(ArrayKey array_id, IVariableDataHolder* vh);
#ifdef SG_USE_ACCEL
void register_array_id(ArrayKey array_id, DeviceDataType dev_dtp);
DeviceDataType get_dev_dtp_by_array_id(ArrayKey array_id);
#endif
std::size_t get_el_len_by_arg(const TaskArgument& var);
[[nodiscard]]
TaskArgument insert_received_block(
    ArrayKey array_id,
    std::unique_ptr<std::uint8_t[]>&& block_mem);
[[nodiscard]]
comm::SerializedMPIDataType send_message_type(
    const TaskArgument& arg);
} // namespace internal

void register_matrix(int rank, MPI_Comm comm, BlockedCSRMatrixSI& m);
void register_matrix(int rank, MPI_Comm comm, BlockedCSRMatrixDI& m);

bool is_zero(const BlockedCSRMatrixSI& m, const TaskArgument& arg);
bool is_zero(const BlockedCSRMatrixDI& m, const TaskArgument& arg);

std::vector<std::string> get_command_line_args();

bool is_array_element_local(const TaskArgument& el);

bool is_array_element_local(const TaskArgument& el, std::size_t tgp_id);

std::vector<comm::ProcessCoord> get_array_el_targets(const TaskArgument& var);

std::vector<comm::ProcessCoord> get_array_el_targets(
    const TaskArgument& var,
    comm::Communicator* comm);

void abort();
void abort(const std::string& message);

void init_thread_pool();

void stop_threads();

std::size_t declare_tgp(TaskGraphProblemHolder&& p);

bool is_tgp_already_declared(std::size_t id);

void reset_tgp(std::size_t id);

void reset_tgp_inside_iter_loop(std::size_t id);

void ref_tgp_in_var(std::size_t id, const TaskArgument& arg);

void ref_tgp_out_var(std::size_t id, const TaskArgument& arg);

void register_tgp(std::size_t id);

void exec_tgp_and_wait(std::size_t id, bool reset_device_mgr = false);

bool is_tgp_first_iteration(std::size_t id);

void finish_tgp_first_iteration(std::size_t id);

std::size_t declare_essp(ESSProblemHolder&& p);

void execute_essp_and_wait(std::size_t pid);

void commit_essp(std::size_t pid);

void reset_essp(std::size_t pid);

void clear_essp(std::size_t pid);

bool is_essp_declared(std::size_t pid);

void finalize();

void begin_iteration(int new_version, int n_versions);

ArrayDimensions<2> get_local_subarray_dims_01(
    const ArrayDimensions<2>& array_dims,
    const ArrayDimensions<2>& area_dist);

ArrayElementCoordinates<2> get_local_subarray_coords_01(
    const ArrayDimensions<2>& area_dims,
    const comm::ProcessCoordinates<2>& cart_coords,
    const comm::ProcessCoordinates<2>& cart_size);

enum class TGRedistributionStrategy
{
    ByInputs,
    ByOuputs
};

void redistribute_array_sync(
    ArrayKey actual_array_id,
    ArrayKey connected_array_id,
    std::size_t tgp_id,
    TGRedistributionStrategy strategy);

void redistribute_array(ArrayKey array_id, const ArrayDimSize len);

#ifndef NDEBUG
void print_vector(const MemoryOwningVectorHolderD& vec);
void print_vector(const MemoryOwningVectorHolderS& vec);
void print_vector(const ContiguousArray1D& v);
void print_vector(const ContiguousArray1I& v);
#endif

void init_arrays_storage(ArrayKey max_n_arrays);

void init_arrays_storage(ArrayKey max_n_arrays, int ndims);

void init(ArrayKey n_arrays, int argc, char** argv);

namespace impl
{

void init_reduction_tmp_arrays_storage();

} // namespace impl

double reduce_array_2_2(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderD& array,
    ElementVersion version,
    MPI_Op op,
    int np,
    MPI_Comm comm);

float reduce_array_2_2(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderS& array,
    ElementVersion version,
    MPI_Op op,
    int np,
    MPI_Comm comm);

std::float16_t reduce_array_2_2(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderF16& array,
    ElementVersion version,
    MPI_Op op,
    int np,
    MPI_Comm comm);

std::bfloat16_t reduce_array_2_2(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderBF16& array,
    ElementVersion version,
    MPI_Op op,
    int np,
    MPI_Comm comm);

double reduce_array_3_3(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderD& array,
    ElementVersion version,
    const ESSDistributorContainer& distributors,
    MPI_Op op,
    int np,
    MPI_Comm comm);

float reduce_array_3_3(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderS& array,
    ElementVersion version,
    const ESSDistributorContainer& distributors,
    MPI_Op op,
    int np,
    MPI_Comm comm);

std::float16_t reduce_array_3_3(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderF16& array,
    ElementVersion version,
    const ESSDistributorContainer& distributors,
    MPI_Op op,
    int np,
    MPI_Comm comm);

std::bfloat16_t reduce_array_3_3(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderBF16& array,
    ElementVersion version,
    const ESSDistributorContainer& distributors,
    MPI_Op op,
    int np,
    MPI_Comm comm);

void reduce_array_2_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderD& array,
    ElementVersion src_version,
    MPI_Op op,
    ArrayDim dim,
    MemoryOwningVectorHolderD& result,
    ElementVersion dst_version,
    int in_src_dim_0,
    int in_src_dim_1,
    int in_dst_dim,
    int np,
    MPI_Comm comm);

void reduce_array_2_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderS& array,
    ElementVersion src_version,
    MPI_Op op,
    ArrayDim dim,
    MemoryOwningVectorHolderS& result,
    ElementVersion dst_version,
    int in_src_dim_0,
    int in_src_dim_1,
    int in_dst_dim,
    int np,
    MPI_Comm comm);

//
void reduce_array_2_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderF16& array,
    ElementVersion src_version,
    MPI_Op op,
    ArrayDim dim,
    MemoryOwningVectorHolderF16& result,
    ElementVersion dst_version,
    int in_src_dim_0,
    int in_src_dim_1,
    int in_dst_dim,
    int np,
    MPI_Comm comm);

void reduce_array_2_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const NonUpdatableGeneralArrayHolderBF16& array,
    ElementVersion src_version,
    MPI_Op op,
    ArrayDim dim,
    MemoryOwningVectorHolderBF16& result,
    ElementVersion dst_version,
    int in_src_dim_0,
    int in_src_dim_1,
    int in_dst_dim,
    int np,
    MPI_Comm comm);

//

void reduce_array_2_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const UpdatableGeneralArrayHolderD& array,
    ElementVersion src_version,
    MPI_Op op,
    ArrayDim dim,
    MemoryOwningVectorHolderD& result,
    ElementVersion dst_version,
    int in_src_dim_0,
    int in_src_dim_1,
    int in_dst_dim,
    int np,
    MPI_Comm comm);

void reduce_array_2_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const UpdatableGeneralArrayHolderS& array,
    ElementVersion src_version,
    MPI_Op op,
    ArrayDim dim,
    MemoryOwningVectorHolderS& result,
    ElementVersion dst_version,
    int in_src_dim_0,
    int in_src_dim_1,
    int in_dst_dim,
    int np,
    MPI_Comm comm);

void reduce_array_2_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const UpdatableGeneralArrayHolderF16& array,
    ElementVersion src_version,
    MPI_Op op,
    ArrayDim dim,
    MemoryOwningVectorHolderF16& result,
    ElementVersion dst_version,
    int in_src_dim_0,
    int in_src_dim_1,
    int in_dst_dim,
    int np,
    MPI_Comm comm);

void reduce_array_2_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const UpdatableGeneralArrayHolderBF16& array,
    ElementVersion src_version,
    MPI_Op op,
    ArrayDim dim,
    MemoryOwningVectorHolderBF16& result,
    ElementVersion dst_version,
    int in_src_dim_0,
    int in_src_dim_1,
    int in_dst_dim,
    int np,
    MPI_Comm comm);

//

int reduce_i_array_1_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const MemoryOwningVectorHolderS& array,
    ElementVersion version,
    MPI_Op op,
    ElementVersion unused,
    int in_src_dim,
    int np,
    MPI_Comm comm);

int reduce_i_array_1_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const MemoryOwningVectorHolderD& array,
    ElementVersion version,
    MPI_Op op,
    ElementVersion unused,
    int in_src_dim,
    int np,
    MPI_Comm comm);

int reduce_i_array_1_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const MemoryOwningVectorHolderF16& array,
    ElementVersion version,
    MPI_Op op,
    ElementVersion unused,
    int in_src_dim,
    int np,
    MPI_Comm comm);

int reduce_i_array_1_1(
#ifdef SG_USE_ACCEL
    bool src_version_ref_iter_var,
#endif
    const MemoryOwningVectorHolderBF16& array,
    ElementVersion version,
    MPI_Op op,
    ElementVersion unused,
    int in_src_dim,
    int np,
    MPI_Comm comm);

#ifdef SG_USE_ACCEL
CSRMatrixBlock<int, float> get_csr_block_si(const TaskArgument& var);
CSRMatrixBlock<int, double> get_csr_block_di(const TaskArgument& var);
void begin_iter_proc();
void end_iter_proc();
#endif

#ifdef SG_USE_GOOPAX
template<typename T>
goopax::buffer<T> get_goopax_buffer(DeviceId device_id, const TaskArgument& var)
{
    auto* buffer = get_dev_buffer_by_var(device_id, var);
    assert(buffer != nullptr);
    assert(dynamic_cast<GoopaxBuffer*>(buffer) != nullptr);
    return static_cast<GoopaxBuffer*>(buffer)->get<T>();
}

goopax::buffer<int> get_goopax_buffer_csr_ia(DeviceId device_id, const TaskArgument& var);
goopax::buffer<int> get_goopax_buffer_csr_ja(DeviceId device_id, const TaskArgument& var);
int get_csr_n(DeviceId device_id, const TaskArgument& var);
int get_csr_m(DeviceId device_id, const TaskArgument& var);
int get_csr_nnz(DeviceId device_id, const TaskArgument& var);

template<typename T>
goopax::buffer<T> get_goopax_buffer_csr_a(DeviceId device_id, const TaskArgument& var)
{
    auto* buffer = get_dev_ext_2_buffer_by_var(device_id, var);
    assert(buffer != nullptr);
    assert(dynamic_cast<GoopaxBuffer*>(buffer) != nullptr);
    return static_cast<GoopaxBuffer*>(buffer)->get<T>();
}

goopax::goopax_device get_goopax_device_by_task(DeviceId device_id, const Task& task);
#endif

void reset_tgpc();

void reset_devices_mgr();

bool is_tgp_registered(std::size_t id);

void reset_tgpc();

void reset_array(ArrayKey array_id);

} // namespace rts

void _read_ghost_double(int in_n, int in_m, int ghost_edge_len, const double* a, double* ghost_edge);

void _read_ghost_float(int in_n, int in_m, int ghost_edge_len, const float* a, float* ghost_edge);

void _read_ghost_double(int in_n, int in_m, int in_p, int ghost_edge_len, const double* a, double* ghost_edge);

void _read_ghost_float(int in_n, int in_m, int in_p, int ghost_edge_len, const float* a, float* ghost_edge);

void _read_ghost3d_double(int in_n, int in_m, int in_p, int ghost_edge_len, const double* a, double* ghost_edge);

void _read_ghost3d_float(int in_n, int in_m, int in_p, int ghost_edge_len, const float* a, float* ghost_edge);

void _write_ghost_double(
	int in_n,
	int in_m,
	int ghost_edge_len,
	const double* left,
	const double* right,
	const double* up,
	const double* down,
	const double* a,
	double* b);

void _write_ghost_float(
	int in_n,
	int in_m,
	int ghost_edge_len,
	const float* left,
	const float* right,
	const float* up,
	const float* down,
	const float* a,
	float* b);

void _write_ghost_double(
	int in_n,
	int in_m,
	int in_p,
	int ghost_edge_len,
	const double* left,
	const double* right,
	const double* up,
	const double* down,
	const double* front,
	const double* back,
	const double* a,
	double* b);

void _write_ghost_float(
	int in_n,
	int in_m,
	int in_p,
	int ghost_edge_len,
	const float* left,
	const float* right,
	const float* up,
	const float* down,
	const float* front,
	const float* back,
	const float* a,
	float* b);

void _write_ghost3d_double(
	int in_n,
	int in_m,
	int in_p,
	int ghost_edge_len,
	const double* left,
	const double* right,
	const double* up,
	const double* down,
	const double* front,
	const double* back,
	const double* a,
	double* b);

void _write_ghost3d_float(
	int in_n,
	int in_m,
	int in_p,
	int ghost_edge_len,
	const float* left,
	const float* right,
	const float* up,
	const float* down,
	const float* front,
	const float* back,
	const float* a,
	float* b);

// 26-neighbor additive ("full sum") 3D block exchange - the generic runtime
// primitive backing pysol_update_array_3d_26_full_sum(). Unlike
// _read_ghost3d_/_write_ghost3d_ (which exchange only a thin 1-cell halo on
// each of the 6 faces), this pair is for the overlapping-node domain
// decomposition used e.g. by pic3d_v2's exchange_density_additive_block: a
// block owns a full n x m x p array with no separate ghost layer, and the
// 2-cell-thick slab at each face/edge/corner physically overlaps the
// matching slab of up to 7 other neighboring blocks (2 across a shared
// face, 4 along a shared edge, 8 at a shared corner) - so the correct value
// at any such node is the SUM of every block's independent contribution,
// not a copy from one of them. _read_ghost_26_full_sum_<type> extracts a
// block's own full data into a stable scratch copy (stage 1); every
// subsequent block's _write_ghost_26_full_sum_<type> call (stage 2) then
// reads only from these stable scratch copies - never another block's live,
// possibly-still-being-written array - avoiding the "can't read and write
// the same array element in one kernel" restriction.
//
// Direction codes follow pic3d_v2's own convention: a 3-digit code "XYZ"
// with each digit in {0,1,2} meaning {lo,mid,hi} along that axis (axis0=n,
// axis1=m, axis2=p); "111" (self) is omitted, leaving the 26 neighbor
// directions below. existsXYZ is 0/1: whether that neighbor block actually
// exists (false at a domain boundary), computed by the caller (see
// exchange_3d_26_full_sum.sol) - a missing direction contributes nothing
// (not even a self-substitution), since the self contribution is already
// included via the initial self-copy. Requires n >= 3, m >= 3, p >= 3 (each
// axis needs a 2-cell-wide lo band and a disjoint-from-mid-only-in-the-
// middle hi band), matching the implicit precondition already relied on by
// exchange_density_additive_block.
void _read_ghost_26_full_sum_double(int n, int m, int p, int ghost_len, const double* a, double* ghost);

void _read_ghost_26_full_sum_float(int n, int m, int p, int ghost_len, const float* a, float* ghost);

void _write_ghost_26_full_sum_double(
	int n, int m, int p, int ghost_len,
	const double* nbr000, int exists000,
	const double* nbr001, int exists001,
	const double* nbr002, int exists002,
	const double* nbr010, int exists010,
	const double* nbr011, int exists011,
	const double* nbr012, int exists012,
	const double* nbr020, int exists020,
	const double* nbr021, int exists021,
	const double* nbr022, int exists022,
	const double* nbr100, int exists100,
	const double* nbr101, int exists101,
	const double* nbr102, int exists102,
	const double* nbr110, int exists110,
	const double* nbr112, int exists112,
	const double* nbr120, int exists120,
	const double* nbr121, int exists121,
	const double* nbr122, int exists122,
	const double* nbr200, int exists200,
	const double* nbr201, int exists201,
	const double* nbr202, int exists202,
	const double* nbr210, int exists210,
	const double* nbr211, int exists211,
	const double* nbr212, int exists212,
	const double* nbr220, int exists220,
	const double* nbr221, int exists221,
	const double* nbr222, int exists222,
	const double* a, double* b);

void _write_ghost_26_full_sum_float(
	int n, int m, int p, int ghost_len,
	const float* nbr000, int exists000,
	const float* nbr001, int exists001,
	const float* nbr002, int exists002,
	const float* nbr010, int exists010,
	const float* nbr011, int exists011,
	const float* nbr012, int exists012,
	const float* nbr020, int exists020,
	const float* nbr021, int exists021,
	const float* nbr022, int exists022,
	const float* nbr100, int exists100,
	const float* nbr101, int exists101,
	const float* nbr102, int exists102,
	const float* nbr110, int exists110,
	const float* nbr112, int exists112,
	const float* nbr120, int exists120,
	const float* nbr121, int exists121,
	const float* nbr122, int exists122,
	const float* nbr200, int exists200,
	const float* nbr201, int exists201,
	const float* nbr202, int exists202,
	const float* nbr210, int exists210,
	const float* nbr211, int exists211,
	const float* nbr212, int exists212,
	const float* nbr220, int exists220,
	const float* nbr221, int exists221,
	const float* nbr222, int exists222,
	const float* a, float* b);
