#pragma once

namespace rts
{
namespace prof
{

void start_init_phase();
void end_init_phase();

void start_rts_phase();
void end_rts_phase();

void start_dev_mgr_phase();
void end_dev_mgr_phase();

void start_exec_phase();
void end_exec_phase();

double get_total_init_time();
double get_total_rts_time();
double get_total_rts_time_main_thread();
double get_total_device_transfer_time();
double get_total_device_mgr_time();
double get_total_exec_time();

class ProfileInitPhase final
{
public:
    ProfileInitPhase();
    ~ProfileInitPhase();
};

class ProfileRtsPhase final
{
public:
    ProfileRtsPhase();
    ~ProfileRtsPhase();
};

class ProfileDevTransfer final
{
public:
    ProfileDevTransfer();
    ~ProfileDevTransfer();
};

class ProfileDevManager final
{
public:
    ProfileDevManager();
    ~ProfileDevManager();
};

class ProfileExecPhase final
{
public:
    ProfileExecPhase();
    ~ProfileExecPhase();
};

} // namespace prof
} // namespace rts
