#pragma once

#include "Utils.h"

#include "Utils/HashCombine.h"

namespace rts
{
namespace impl
{

template<typename T>
ArrayKey TmpArrayIdsStorage::generate_tmp_var_id(
    const T& array_holder,
    int i0,
    int i1)
{
    return ids_storage_[Key{array_holder.GetKey(), i0, i1}];
}

} // namespace impl

template<typename T>
std::size_t get_element_len(
    const T& array,
    ElementVersion ver,
    ArrayElementCoord coord)
{
    return array.GetLen(TaskArgument{
        array.GetKey(),
        ver,
        coord});
}

template<typename T, typename... Indices>
ArrayKey generate_tmp_var_id(const T& array_holder, Indices... indices)
{
    return impl::get_tmp_array_ids_storage().generate_tmp_var_id(
        array_holder,
        indices...);
}

} // namespace rts
