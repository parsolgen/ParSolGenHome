#pragma once

#include "Array.h"

namespace rts
{

NonUpdatableGeneralArrayHolderS declare_generic_nu_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderS declare_generic_nu_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderS declare_generic_nu_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderS declare_generic_nu_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderS declare_generic_nu_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderS declare_generic_nu_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderS declare_generic_nu_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<3>& block_size,
    const ArrayDimensions<3>& last_block_size);

//

NonUpdatableGeneralArrayHolderF16 declare_generic_nu_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderF16 declare_generic_nu_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderF16 declare_generic_nu_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderF16 declare_generic_nu_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderF16 declare_generic_nu_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderF16 declare_generic_nu_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderF16 declare_generic_nu_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<3>& block_size,
    const ArrayDimensions<3>& last_block_size);

//

NonUpdatableGeneralArrayHolderBF16 declare_generic_nu_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderBF16 declare_generic_nu_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderBF16 declare_generic_nu_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderBF16 declare_generic_nu_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderBF16 declare_generic_nu_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderBF16 declare_generic_nu_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderBF16 declare_generic_nu_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<3>& block_size,
    const ArrayDimensions<3>& last_block_size);

//

NonUpdatableGeneralArrayHolderD declare_generic_nu_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderD declare_generic_nu_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderD declare_generic_nu_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderD declare_generic_nu_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderD declare_generic_nu_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

NonUpdatableGeneralArrayHolderD declare_generic_nu_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

NonUpdatableGeneralArrayHolderD declare_generic_nu_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<3>& global_array_dims,
    ArrayDimensions<3> local_subarray_dims,
    ArrayElementCoordinates<3> local_subarray_coords,
    const ArrayDimensions<3>& block_size,
    const ArrayDimensions<3>& last_block_size);

// ==============================================================================
UpdatableGeneralArrayHolderS declare_generic_u_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

UpdatableGeneralArrayHolderS declare_generic_u_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

UpdatableGeneralArrayHolderS declare_generic_u_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

UpdatableGeneralArrayHolderS declare_generic_u_s_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

//

UpdatableGeneralArrayHolderD declare_generic_u_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

UpdatableGeneralArrayHolderD declare_generic_u_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

UpdatableGeneralArrayHolderD declare_generic_u_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

UpdatableGeneralArrayHolderD declare_generic_u_d_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

//

UpdatableGeneralArrayHolderF16 declare_generic_u_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

UpdatableGeneralArrayHolderF16 declare_generic_u_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

UpdatableGeneralArrayHolderF16 declare_generic_u_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

UpdatableGeneralArrayHolderF16 declare_generic_u_f16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

//

UpdatableGeneralArrayHolderBF16 declare_generic_u_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

UpdatableGeneralArrayHolderBF16 declare_generic_u_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

UpdatableGeneralArrayHolderBF16 declare_generic_u_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<1>& global_array_dims,
    ArrayDimensions<1> local_subarray_dims,
    ArrayElementCoordinates<1> local_subarray_coords,
    const ArrayDimensions<2>& block_size,
    const ArrayDimensions<2>& last_block_size);

UpdatableGeneralArrayHolderBF16 declare_generic_u_bf16_array(
    ArrayKey array_id,
    ElementVersion nversions,
    const ArrayDimensions<2>& global_array_dims,
    ArrayDimensions<2> local_subarray_dims,
    ArrayElementCoordinates<2> local_subarray_coords,
    const ArrayDimensions<1>& block_size,
    const ArrayDimensions<1>& last_block_size);

//

ExternalOutNonUpdatableGeneralArrayHolderS declare_generic_nu_out_ext_s_array(
    ArrayKey array_id,
    ArrayDimensions<1> block_size,
    ArrayDimensions<1> last_block_size,
    std::string connection_string);

ExternalOutNonUpdatableGeneralArrayHolderS declare_generic_nu_out_ext_s_array(
    ArrayKey array_id,
    ArrayDimensions<2> block_size,
    ArrayDimensions<2> last_block_size,
    std::string connection_string);

ExternalOutNonUpdatableGeneralArrayHolderD declare_generic_nu_out_ext_d_array(
    ArrayKey array_id,
    ArrayDimensions<1> block_size,
    ArrayDimensions<1> last_block_size,
    std::string connection_string);

ExternalOutNonUpdatableGeneralArrayHolderD declare_generic_nu_out_ext_d_array(
    ArrayKey array_id,
    ArrayDimensions<2> block_size,
    ArrayDimensions<2> last_block_size,
    std::string connection_string);


} // namespace rts
