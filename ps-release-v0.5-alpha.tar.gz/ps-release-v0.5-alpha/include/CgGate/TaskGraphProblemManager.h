#pragma once

#include "TaskGraphProblem.h"
#include "TaskGraphProblemHolder.h"

#include <deque>

namespace rts
{

class TaskGraphProblemsMgr final
{
public:
    [[nodiscard]]
    std::size_t declare(TaskGraphProblemHolder&& p);

    void reset(std::size_t id);

    void reset();

    void reset_in_iter_loop(std::size_t id);

    [[nodiscard]]
    bool is_declared(std::size_t id) const noexcept;

    void ref_in_var(std::size_t id, const TaskArgument& arg);

    void ref_out_var(std::size_t id, const TaskArgument& arg);

    void register_in_controller(std::size_t id);

    [[nodiscard]]
    bool is_tgp_registered(std::size_t id);

    void exec_and_wait(std::size_t id, bool reset_device_mgr);

    [[nodiscard]]
    bool is_tgp_first_iteration(std::size_t id) const noexcept;

    void finish_tgp_first_iteration(std::size_t id) noexcept;

    [[nodiscard]]
    TaskGraphProblemHolder& get(std::size_t id);

    [[nodiscard]]
    const TaskGraphProblemHolder& get(std::size_t id) const noexcept;

    void begin_iteration(int new_version, int n_veresions);

    [[nodiscard]]
    inline
    std::size_t get_current_executing_tgp() const noexcept
    {
        return current_executing_tgp_;
    }

private:
    std::deque<TaskGraphProblemHolder> declared_tgps_;
    std::size_t registered_tgps_ = 0;
    std::size_t current_executing_tgp_ = 0;
};

TaskGraphProblemsMgr& get_tgp_mgr();

} // namespace rts
