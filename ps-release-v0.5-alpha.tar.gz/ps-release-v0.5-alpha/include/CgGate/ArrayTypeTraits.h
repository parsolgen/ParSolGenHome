#pragma once

#include "Array.h"
#include "ArrayHolders/NonUpdatableGeneralGrowingVectorHolder.h"

#include <type_traits>

namespace rts
{
namespace traits
{

template <typename T>
struct is_nu_array : std::false_type
{
};

template <>
struct is_nu_array<NonUpdatableGeneralArrayHolderS> : std::true_type
{
};

template <>
struct is_nu_array<NonUpdatableGeneralArrayHolderF16> : std::true_type
{
};

template <>
struct is_nu_array<NonUpdatableGeneralArrayHolderBF16> : std::true_type
{
};

template <>
struct is_nu_array<NonUpdatableGeneralArrayHolderD> : std::true_type
{
};

template<>
struct is_nu_array<INonUpdatableSerializableArray> : std::true_type
{};

template <typename T>
inline constexpr bool is_nu_array_v = is_nu_array<T>::value;

} // namespace traits
} // namespace rts
