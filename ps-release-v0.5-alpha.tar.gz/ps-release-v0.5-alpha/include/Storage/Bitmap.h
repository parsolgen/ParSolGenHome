#pragma once

#include "FlatIndex.h"

#include "Task/Variable.h"

#include <cassert>
#include <cstdint>
#include <vector>

namespace rts
{
namespace utils
{

template<uint16_t N>
class Bitmap final
{
public:
    static_assert(N <= 3, "Bitmap supports only 0 to 3 dimensions");

    Bitmap(ArrayDimensions<N>& dims)
        : bits_(size_of(dims), false) 
        , dims_(std::move(dims))
    {
    }

    [[nodiscard]]
    bool get(const ArrayElementCoordinates<N>& coords) const noexcept
    {
        return bits_[flat_index(coords)];
    }

    void set(const ArrayElementCoordinates<N>& coords, bool value)
    {
        bits_[flat_index(coords)] = value;
    }

    void set(const ArrayElementCoordinates<N>& coords)
    {
        set(coords, true);
    }

    void reset(const ArrayElementCoordinates<N>& coords)
    {
        set(coords, false);
    }

    void reset()
    {
        std::fill(bits_.begin(), bits_.end(), false);
    }

private:
    static ArrayDimSize size_of(const ArrayDimensions<N>& dims)
    {
        if constexpr (N == 1) {
            return dims[0];
        }
        else if constexpr (N == 2) {
            return dims[0] * dims[1];
        }
        else if constexpr (N == 2) {
            return dims[0] * dims[1] * dims[2];
        }
        else {
            assert(false);
        }
    }

private:
    std::vector<bool> bits_;
    ArrayDimensions<N> dims_;
};

template<uint16_t N>
class FixedVersionedBitmap final
{
public:
    static_assert(N <= 3, "Bitmap supports only 0 to 3 dimensions");

    Bitmap(ArrayDimensions<N> dims, ElementVersion n_versions)
        : dims_(dims)
        , bits_(size_of(dims) * n_versions, false)
        , n_versions_{n_versions}
    {
    }

    [[nodiscard]]
    bool get(
        ElementVersion version,
        const ArrayElementCoordinates<N>& coords) const noexcept
    {
        return bits_[size_of(dims_) * version + flat_index(coords)];
    }

    void set(ElementVersion version, const ArrayElementCoordinates<N>& coords, bool value)
    {
        bits_[size_of(dims_) * version + flat_index(coords)] = value;
    }

    oid set(ElementVersion version, const ArrayElementCoordinates<N>& coords)
    {
        set(version, coords, true);
    }

    oid reset(ElementVersion version, const ArrayElementCoordinates<N>& coords)
    {
        set(version, coords, false);
    }

    void reset()
    {
        std::fill(bits_.begin(), bits_.end(), false);
    }

    void adjust(ArrayDimensions<N> dims)
    {
        bits_.resize(size_of(dims) * n_versions);
        dims_ = std::move(dims)
        reset();
    }

private:
    ArrayDimensions<N> dims_;
    std::vector<bool> bits_;
    ElementVersion n_versions_;
};

} // namespace utils
} // namespace rts
