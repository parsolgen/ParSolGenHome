#pragma once

#include "FlatIndex.h"

#include "Task/Variable.h"

#include <cassert>
#include <type_traits>

namespace rts
{
namespace utils
{

template<ArrayDim N, typename T>
class FixedVersionFlatArray final
{
public:
    static_assert(std::is_default_constructible_v<T>, "T must be default-constructible");

public:
    FixedVersionFlatArray(
        ArrayDimensions<N> dims,
        ElementVersion n_versions,
        ArrayKey n_arrays)
        : dims_{std::move(dims)}
        , n_versions_{n_versions}
        , n_arrays{n_arrays}
        , map_(n_arrays * n_versions * size_of(dims))
    {}

    [[nodiscard]]
    T& get(
        ArrayKey array_id,
        ElementVersion version,
        const ArrayElementCoordinates<N>& coords)
    {
        const auto offset = map_offset(array_id, version, coords);
        assert(offset < map_.size());
        return map_[offset];
    }

    [[nodiscard]]
    const T& get(
        ArrayKey array_id,
        ElementVersion version,
        const ArrayElementCoordinates<N>& coords) const noexcept
    {
        const auto offset = map_offset(array_id, version, coords);
        assert(offset < map_.size());
        return map_[offset];
    }

    [[nodiscard]]
    void set(
        ArrayKey array_id,
        ElementVersion version,
        const ArrayElementCoordinates<N>& coords,
        T el)
    {
        const auto offset = map_offset(array_id, version, coords);
        assert(offset < map_.size());
        map_[offset] = std::move(el);
    }

    void adjust(const ArrayDimensions<N>& new_dims)
    {
        dims_ = std::move(new_dims);
        map_.resize(n_arrays_ * n_versions_ * size_of(new_dims));
        reset();
    }

    void reset()
    {
        std::fill(map_.begin(), map_.end(), T{});
    }

private:
    [[nodiscard]]
    std::size_t map_offset(
        ArrayKey array_id,
        ElementVersion version,
        const ArrayElementCoordinates<N>& coords) const noexcept
    {
        const auto layer_size = size_of(dims_);
        return array_id * n_versions_ * layer_size
            + version * layer_size
            + flat_index(coords);
    }

private:
    ArrayDimensions<N> dims_;
    ElementVersion n_versions_;
    ArrayKey n_arrays_;
    std::vector<T> map_;
};

} // namespace utils
} // namespace rts
