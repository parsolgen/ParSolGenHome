#pragma once

#include "Task/Task.h"

#include <list>
#include <type_traits>
#include <unordered_map>
#include <vector>
#include <mutex>

namespace rts
{

template<typename T>
class VersionedMeshStorage final
{
public:
    VersionedMeshStorage(
        std::size_t n_arrays,
        ArrayDimSize n1,
        ArrayDimSize n2)
        : n_arrays_{n_arrays}
        , n1_{n1}
        , n2_{n2}
    {
    }

    [[nodiscard]]
    T& get(const TaskArgument& var)
    {
        std::lock_guard guard_{mutex_};

        return data_[var];
    }

    [[nodiscard]]
    const T& get(const TaskArgument& var) const
    {
        std::lock_guard guard_{mutex_};

        const auto it = data_.find(var);
        assert(it != data_.end());
        return it->second;
    }

    [[nodiscard]]
    bool has(const TaskArgument& var) const
    {
        std::lock_guard guard_{mutex_};

        return (data_.find(var) != data_.end());
    }

    [[nodiscard]]
    T& operator[](const TaskArgument& var)
    {
        return get(var);
    }

    [[nodiscard]]
    const T& operator[](const TaskArgument& var) const
    {
        return get(var);
    }

    void reset()
    {
        std::lock_guard guard_{mutex_};

        data_.clear();
    }

    template<typename F>
    void for_each_array_element(ArrayKey array_id, F op) const
    {
        for (const auto& pair : data_)
        {
            op(pair.second);
        }
    }

    template<typename F>
    void for_each_array_element(ArrayKey array_id, F op)
    {
        for (auto& pair : data_)
        {
            op(pair.second);
        }
    }

private:
    std::size_t n_arrays_;
    ArrayDimSize n1_;
    ArrayDimSize n2_;
    mutable std::mutex mutex_;

    std::unordered_map<TaskArgument, T> data_;
};

template<>
class VersionedMeshStorage<bool> final
{
public:
    VersionedMeshStorage(
        std::size_t n_arrays,
        ArrayDimSize n1,
        ArrayDimSize n2)
        : n_arrays_{n_arrays}
        , n1_{n1}
        , n2_{n2}
    {
    }

    [[nodiscard]]
    bool get(const TaskArgument& var) const
    {
        std::lock_guard guard_{mutex_};

        const auto it = data_.find(var);
        if (it == data_.end()) {
            return false;
        }
        return it->second;
    }

    void set(const TaskArgument& var, bool value)
    {
        std::lock_guard guard_{mutex_};

        data_[var] = value;
    }

    void set(const TaskArgument& var)
    {
        set(var, true);
    }

    void reset(const TaskArgument& var)
    {
        set(var, false);
    }

    [[nodiscard]]
    bool has(const TaskArgument& var) const
    {
        std::lock_guard guard_{mutex_};

        return (data_.find(var) != data_.end());
    }

    [[nodiscard]]
    bool operator[](const TaskArgument& var) const
    {
        return get(var);
    }

    void reset()
    {
        std::lock_guard guard_{mutex_};

        data_.clear();
    }

    template<typename F>
    void for_each_array_element(ArrayKey array_id, F op) const
    {
        for (const auto& pair : data_)
        {
            op(pair.second);
        }
    }

    template<typename F>
    void for_each_array_element(ArrayKey array_id, F op)
    {
        for (auto& pair : data_)
        {
            op(pair.second);
        }
    }

private:
    std::size_t n_arrays_;
    ArrayDimSize n1_;
    ArrayDimSize n2_;
    mutable std::mutex mutex_;

    std::unordered_map<TaskArgument, bool> data_;
};

template<typename T>
class NonVersioned3DMeshStorage final
{
public:
    using iterator = typename std::vector<T>::iterator;
    using const_iterator = typename std::vector<T>::const_iterator;

public:
    NonVersioned3DMeshStorage(
        std::size_t n_arrays,
        ElementVersion n_versions,
        ArrayDimSize n1,
        ArrayDimSize n2,
        ArrayDimSize n3)
        : n_arrays_{n_arrays}
        , n_versions_{n_versions}
        , n1_{n1}
        , n2_{n2}
        , n3_{n3}
        , data_(n_arrays * n_versions * n1_ * n2_ * n3_)
    {
    }

    [[nodiscard]]
    T& get(const TaskArgument& var)
    {
        assert(var.n == 3);
        const auto offset = get_offset(var.array_or_var, var.version, var.coords_or_none);
        assert(offset < data_.size());
        return data_[offset];
    }

    [[nodiscard]]
    const T& get(const TaskArgument& var) const
    {
        assert(var.n == 3);
        const auto offset = get_offset(var.array_or_var, var.version, var.coords_or_none);
        assert(offset < data_.size());
        return data_[offset];
    }

    [[nodiscard]]
    T& operator[](const TaskArgument& var)
    {
        return get(var);
    }

    [[nodiscard]]
    const T& operator[](const TaskArgument& var) const
    {
        return get(var);
    }

    void reset()
    {
        data_.clear();
    }

    const_iterator cbegin() const noexcept
    {
        return data_.cbegin();
    }

    const_iterator cend() const noexcept
    {
        return data_.cend();
    }

    iterator begin() const noexcept
    {
        return data_.begin();
    }

    iterator end() const noexcept
    {
        return data_.end();
    }

    [[nodiscard]]
    ArrayDimSize get_n1() const noexcept
    {
        return n1_;
    }

    [[nodiscard]]
    ArrayDimSize get_n2() const noexcept
    {
        return n2_;
    }

    [[nodiscard]]
    ArrayDimSize get_n3() const noexcept
    {
        return n3_;
    }

private:
    [[nodiscard]]
    std::size_t get_offset(
        ArrayKey array_id,
        ElementVersion version,
        const ArrayElementCoordinates<3> coords) const noexcept
    {
        const auto slice_3d_len = n1_ * n2_ * n3_;
        return slice_3d_len * n_versions_ * array_id
            + slice_3d_len * version
            + n1_ * n2_ * coords[2]
            + n2_ * coords[0]
            + coords[1];
    }

private:
    std::size_t n_arrays_;
    ElementVersion n_versions_;
    ArrayDimSize n1_;
    ArrayDimSize n2_;
    ArrayDimSize n3_;
    std::vector<T> data_;
};

template<>
class NonVersioned3DMeshStorage<bool> final
{
public:
    using const_iterator = typename std::vector<bool>::const_iterator;

public:
    NonVersioned3DMeshStorage(
        std::size_t n_arrays,
        ElementVersion n_versions,
        ArrayDimSize n1,
        ArrayDimSize n2,
        ArrayDimSize n3)
        : n_arrays_{n_arrays}
        , n_versions_{n_versions}
        , n1_{n1}
        , n2_{n2}
        , n3_{n3}
        , data_(n_arrays * n_versions * n1_ * n2_ * n3_)
    {
    }

    [[nodiscard]]
    bool get(const TaskArgument& var) const
    {
        assert(var.n == 3);
        const auto offset = get_offset(var.array_or_var, var.version, var.coords_or_none);
        assert(offset < data_.size());
        return data_[offset];
    }

    void set(const TaskArgument& var, bool value)
    {
        assert(var.n == 3);
        const auto offset = get_offset(var.array_or_var, var.version, var.coords_or_none);
        assert(offset < data_.size());
        data_[offset] = value;
    }

    void set(const TaskArgument& var)
    {
        set(var, true);
    }

    void reset(const TaskArgument& var)
    {
        set(var, false);
    }

    [[nodiscard]]
    bool operator[](const TaskArgument& var) const
    {
        return get(var);
    }

    void reset()
    {
        data_.clear();
    }

    const_iterator cbegin() const noexcept
    {
        return data_.cbegin();
    }

    const_iterator cend() const noexcept
    {
        return data_.cend();
    }

    const_iterator begin() const noexcept
    {
        return data_.begin();
    }

    const_iterator end() const noexcept
    {
        return data_.end();
    }

    [[nodiscard]]
    ArrayDimSize get_n1() const noexcept
    {
        return n1_;
    }

    [[nodiscard]]
    ArrayDimSize get_n2() const noexcept
    {
        return n2_;
    }

    [[nodiscard]]
    ArrayDimSize get_n3() const noexcept
    {
        return n3_;
    }

private:
    [[nodiscard]]
    std::size_t get_offset(
        ArrayKey array_id,
        ElementVersion version,
        const ArrayElementCoordinates<3> coords) const noexcept
    {
        const auto slice_3d_len = n1_ * n2_ * n3_;
        return slice_3d_len * n_versions_ * array_id
            + slice_3d_len * version
            + n1_ * n2_ * coords[2]
            + n2_ * coords[0]
            + coords[1];
    }

private:
    std::size_t n_arrays_;
    ElementVersion n_versions_;
    ArrayDimSize n1_;
    ArrayDimSize n2_;
    ArrayDimSize n3_;
    std::vector<bool> data_;
};

} // namespace rts
