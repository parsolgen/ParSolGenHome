#pragma once

#include "Task/Variable.h"

namespace rts
{
namespace utils
{

template<ArrayDim N>
[[nodiscard]]
std::size_t flat_index(const rts::ArrayElementCoordinates<N>& coords)
{
    if constexpr (N == 1) {
        return coords[0];
    }
    else if constexpr (N == 2) {
        return coords[0] * dims_[1] + coords[1];
    }
    else if constexpr (N == 2) {
        return coords[0] * dims_[2] * dims_[1] + coords[1] * dims_[2] + coords[2];
    }
    else {
        assert(false);
    }
}

template<ArrayDim N>
[[nodiscard]]
ArrayDimSize size_of(const ArrayDimensions<N>& dims)
{
    if constexpr (N == 1) {
        return dims[0];
    }
    else if constexpr (N == 2) {
        return dims[0] * dims[1];
    }
    else if constexpr (N == 2) {
        return dims[0] * dims[1] * dims[2];
    }
    else {
        assert(false);
    }
}

} // namespace utils
} // namespace rts
