#pragma once

#include "Task/Task.h"

#include <list>

namespace rts
{

template<typename T>
class NonVersionedMeshStorage final
{
public:
    NonVersionedMeshStorage(
        std::size_t n_arrays,
        ArrayDimSize n1,
        ArrayDimSize n2)
        : n_arrays_{n_arrays}
        , n1_{n1}
        , n2_{n2}
    {
        ptrs_.resize(n_arrays * n1 * n2, nullptr);
    }

public:
    T& get(const TaskArgument& var)
    {
        const auto offset = var.array_or_var * n1_ * n2_
            + var.coords_or_none[0] * n2_ + var.coords_or_none[1];
        assert(offset < ptrs_.size());
        if (ptrs_[offset] == nullptr) {
            data_.emplace_back(T{});
            ptrs_[offset] = &data_.back();
        }
        return *ptrs_[offset];
    }

    const T& get(const TaskArgument& var) const
    {
        const auto offset = var.array_or_var * n1_ * n2_
            + var.coords_or_none[0] * n2_ + var.coords_or_none[1];
        assert(offset < ptrs_.size());
        if (ptrs_[offset] == nullptr) {
            data_.emplace_back(T{});
            ptrs_[offset] = &data_.back();
        }
        return *ptrs_[offset];
    }

    T& operator[](const TaskArgument& var)
    {
        return get(var);
    }

    const T& operator[](const TaskArgument& var) const
    {
        return get(var);
    }

    void reset()
    {
        std::fill(ptrs_.begin(), ptrs_.end(), nullptr);
    }

private:
    std::size_t n_arrays_;
    ArrayDimSize n1_;
    ArrayDimSize n2_;
    mutable std::vector<T*> ptrs_;
    mutable std::list<T> data_;
};

template<>
class NonVersionedMeshStorage<bool> final
{
public:
    NonVersionedMeshStorage(
        std::size_t n_arrays,
        ArrayDimSize n1,
        ArrayDimSize n2)
        : n_arrays_{n_arrays}
        , n1_{n1}
        , n2_{n2}
    {
        values_.resize(n_arrays * n1 * n2, false);
    }

public:
    bool get(const TaskArgument& var) const
    {
        const auto offset = var.array_or_var * n1_ * n2_
            + var.coords_or_none[0] * n2_ + var.coords_or_none[1];
        assert(offset < values_.size());
        return values_[offset];
    }

    void set(const TaskArgument& var, bool value)
    {
        const auto offset = var.array_or_var * n1_ * n2_
            + var.coords_or_none[0] * n2_ + var.coords_or_none[1];
        assert(offset < values_.size());
        values_[offset] = value;
    }

    void set(const TaskArgument& var)
    {
        set(var, true);
    }

    void reset(const TaskArgument& var)
    {
        set(var, false);
    }

    bool operator[](const TaskArgument& var) const
    {
        return get(var);
    }

    void reset()
    {
        std::fill(values_.begin(), values_.end(), false);
    }

private:
    std::size_t n_arrays_;
    ArrayDimSize n1_;
    ArrayDimSize n2_;
    std::vector<bool> values_;
};

} // namespace rts
