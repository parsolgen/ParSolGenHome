#pragma once

#include <cassert>
#include <cstdint>
#include <type_traits>
#include <vector>

namespace utils
{

template<typename T>
class ArrayMap final
{
private:
    using internal_storage_t = std::vector<T>;

public:
    using pointer = T*;
    using const_pointer = const T*;
    using iterator = T*;
    using const_iterator = const T*;
    using reference = T&;
    using const_reference = const T&;

public:
    static_assert(std::is_default_constructible_v<T>, "T must be default-constructible");

    explicit ArrayMap(std::size_t n)
    {
        data_.resize(n);
        presence_bitmap_.resize(n);
    }

    std::pair<iterator, bool> insert(std::size_t key, T value)
    {
        if (key >= presence_bitmap_.size()) {
            return std::make_pair(end(), false);
        }
    }

    [[nodiscard]]
    iterator end()
    {
        return nullptr;
    }

    [[nodiscard]]
    const iterator cend() const
    {
        return nullptr;
    }

    [[nodiscard]]
    iterator find(std::size_t i) noexcept
    {

    }

private:
    internal_storage_t data_;
    std::vector<bool> presence_bitmap_;
};

} // namespace utils
