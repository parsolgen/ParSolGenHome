#pragma once

namespace utils
{

template<typename InputIt, typename OutputIt, typename F>
OutputIt find_all(InputIt first, InputIt last, OutputIt d_first, F op)
{
    for (; first != last; ++first)
    {
        if (op(*first)) {
            *d_first = *first;
            ++d_first;
        }
    }

    return d_first;
}

} // namespace utils
