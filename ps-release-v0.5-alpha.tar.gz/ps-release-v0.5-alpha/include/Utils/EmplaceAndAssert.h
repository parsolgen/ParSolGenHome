#pragma once

#include <cassert>
#include <unordered_map>
#include <unordered_set>

namespace utils
{

template<typename T>
void insert_and_assert(T& map, const typename T::key_type key, const typename T::mapped_type& value)
{
#ifndef NDEBUG
    assert(map.emplace(key, value).second);
#else
    map.emplace(key, value);
#endif
}

template<typename T>
void insert_and_assert(T& map, const typename T::key_type key, typename T::mapped_type&& value)
{
#ifndef NDEBUG
    assert(map.emplace(key, std::forward<typename T::mapped_type>(value)).second);
#else
    map.emplace(key, std::forward<typename T::mapped_type>(value));
#endif
}

template<typename K, typename V, typename... Args>
void emplace_and_assert(std::unordered_map<K, V>& map, const K key, Args&&... values)
{
#ifndef NDEBUG
    assert(map.insert(key, std::forward<V>(values)...).second);
#else
    map.insert(key, std::forward<V>(values)...);
#endif
}

template<typename V>
void insert_and_assert(std::unordered_set<V>& set, V&& value)
{
#ifndef NDEBUG
    assert(set.insert(std::forward<V>(value)).second);
#else
    set.insert(std::forward<V>(value));
#endif
}

template<typename V>
void insert_and_assert(std::unordered_set<V>& set, const V& value)
{
#ifndef NDEBUG
    assert(set.insert(value).second);
#else
    set.insert(value);
#endif
}

} // namespace utils
