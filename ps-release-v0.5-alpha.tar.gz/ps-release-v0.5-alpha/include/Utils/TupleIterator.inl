#pragma once

#include "TupleIterator.h"

namespace rts {
namespace impl {

template <typename F, std::size_t I, typename... Ts>
void for_each_type(F&& visitor, const std::tuple<Ts...>& tuple) {
  visitor(std::get<I>(tuple), I);
  if constexpr (I < sizeof...(Ts) - 1) {
    for_each_type<F, I + 1, Ts...>(std::forward<F>(visitor), tuple);
  }
}

template <typename F, std::size_t I, typename... Ts>
void for_each_type(F&& visitor, std::tuple<Ts...>& tuple) {
  visitor(std::get<I>(tuple), I);
  if constexpr (I < sizeof...(Ts) - 1) {
    for_each_type<F, I + 1, Ts...>(std::forward<F>(visitor), tuple);
  }
}

} // namespace impl

template <typename F, typename... Ts>
void for_each_type(F&& visitor, const std::tuple<Ts...>& tuple) {
  impl::for_each_type<F, 0, Ts...>(std::forward<F>(visitor), tuple);
}

template <typename F, typename... Ts>
void for_each_type(F&& visitor, std::tuple<Ts...>& tuple) {
  impl::for_each_type<F, 0, Ts...>(std::forward<F>(visitor), tuple);
}

} // namespace rts