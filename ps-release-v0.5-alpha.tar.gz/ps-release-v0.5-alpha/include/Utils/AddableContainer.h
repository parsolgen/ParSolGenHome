#pragma once

namespace utils
{

template<typename C>
class AddableContainer final
{
public:
    template<typename T>
    AddableContainer<C>& operator+(const T& rhs)
    {
        static_assert<dynamic_cast<C*>(this) != nullptr);
        auto& instance = static<C&>(*this);
        instance.push_back(rhs);
        return *this;
    }
};

} // namespace utils
