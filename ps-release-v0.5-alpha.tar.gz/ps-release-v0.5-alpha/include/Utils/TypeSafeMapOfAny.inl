#pragma once

#include "TypeSafeMapOfAny.h"

#include <typeinfo>
#include <cassert>

namespace utils
{

template<typename T1, typename T2>
const T1* TypeSafeMapOfAny::value_or_none() const
{
    const auto it = rhs_type_to_data_.find(std::type_index(typeid(T2)));
    if (it == rhs_type_to_data_.end()) {
        return nullptr;
    }
    return std::any_cast<const T1>(&it->second);
}

template<typename T1, typename T2>
T1* TypeSafeMapOfAny::value_or_none()
{
    auto it = rhs_type_to_data_.find(std::type_index(typeid(T2)));
    if (it == rhs_type_to_data_.end()) {
        return nullptr;
    }
    return std::any_cast<T1>(&it->second);
}

template<typename T1, typename T2>
T1& TypeSafeMapOfAny::create_or_get_value()
{
    static_assert(std::is_default_constructible_v<T1>);
    const auto rhs_type_id = std::type_index(typeid(T1));
    const auto lhs_type_id = std::type_index(typeid(T2));
    auto result_it = rhs_type_to_data_.find(rhs_type_id);
    if (result_it == rhs_type_to_data_.end()) {
        auto it = rhs_type_to_data_.emplace(rhs_type_id, T1{}).first;
        return std::any_cast<T1&>(it->second);
    }
    assert(result_it->second.has_value());
    assert(std::type_index(result_it->second.type()) == lhs_type_id);
    return std::any_cast<T1&>(result_it->second);
}

template<typename T1, typename T2>
const T1& TypeSafeMapOfAny::create_or_get_value()
{
    static_assert(std::is_default_constructible_v<T1>);
    const auto rhs_type_id = std::type_index(typeid(T1));
    const auto lhs_type_id = std::type_index(typeid(T2));
    const auto result_it = rhs_type_to_data_.find(rhs_type_id);
    if (result_it == rhs_type_to_data_.end()) {
        const auto it = rhs_type_to_data_.emplace(rhs_type_id, T1{}).first;
        return std::any_cast<const T1&>(it->second);
    }
    assert(result_it->second.has_value());
    assert(std::type_index(result_it->second.type()) == lhs_type_id);
    return std::any_cast<const T1&>(result_it->second);
}

template<typename T1, typename T2>
void TypeSafeMapOfAny::insert(T1&& value)
{
    const auto rhs_type_id = std::type_index(typeid(T1));
#ifndef NDEBUG
    assert(rhs_type_to_data_.emplace(rhs_type_id, std::forward<T1>(value)).second);
#else
    rhs_type_to_data_.emplace(rhs_type_id, std::forward<T1>(value));
#endif
}

} // namespace utils