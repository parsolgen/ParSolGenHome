#pragma once

#include <cassert>

namespace utils
{

template<typename T>
class IterableContainer
{
public:
    using iterator = typename T::iterator;
    using const_iterator = typename T::const_iterator;

public:
    explicit IterableContainer(T data)
        : data_{std::move(data)}
    {}

public:
    iterator begin()
    {
        return data_.begin();
    }

    const_iterator begin() const
    {
        return data_.begin();
    }

    const_iterator cbegin() const noexcept
    {
        return data_.cbegin();
    }

    iterator end()
    {
        return data_.end();
    }

    const_iterator end() const
    {
        return data_.end();
    }

    const_iterator cend() const
    {
        return data_.cend();
    }

    T& data()
    {
        return data_;
    }

    const T& data() const
    {
        return data_;
    }

private:
    T data_;
};

} // namespace utils
