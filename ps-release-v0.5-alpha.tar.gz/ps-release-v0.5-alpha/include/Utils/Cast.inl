#pragma once

#include "Cast.h"
#include "TypeTraits.h"

#include <cassert>
#include <limits>
#include <type_traits>

namespace utils {
namespace detail {

template <typename T, typename std::enable_if_t<std::is_signed_v<T>, int> = 0>
std::size_t cast_to_size(T value) {
  assert(value >= 0);
  static_assert(sizeof(T) <= sizeof(std::size_t));
  return static_cast<T>(value);
}

template <typename T, typename std::enable_if_t<std::is_unsigned_v<T>, int> = 0>
std::size_t cast_to_size(T value) {
  static_assert(sizeof(T) <= sizeof(std::size_t));
  return static_cast<T>(value);
}

template <typename T, typename std::enable_if_t<std::is_unsigned_v<T> and (sizeof(T) >= sizeof(int)), int> = 0>
int mpi_size_cast(T value) {
  assert(value <= static_cast<T>(std::numeric_limits<int>::max()));
  return static_cast<int>(value);
}

template <typename T, typename std::enable_if_t<std::is_signed_v<T> and (sizeof(T) >= sizeof(int)), int> = 0>
int mpi_size_cast(T value) {
  assert(value >= 0);
  assert(value <= static_cast<T>(std::numeric_limits<int>::max()));
  return static_cast<int>(value);
}

template <typename T, typename std::enable_if_t<std::is_unsigned_v<T> and (sizeof(T) < sizeof(int)), int> = 0>
int mpi_size_cast(T value) {
  assert(static_cast<int>(value) <= (std::numeric_limits<int>::max()));
  return static_cast<int>(value);
}

template <typename T, typename std::enable_if_t<std::is_signed_v<T> and (sizeof(T) < sizeof(int)), int> = 0>
int mpi_size_cast(T value) {
  assert(value >= 0);
  assert(static_cast<int>(value) <= (std::numeric_limits<int>::max()));
  return static_cast<int>(value);
}

} // namespace detail

template <typename T>
int mpi_size_cast(T value) {
  static_assert(std::is_integral_v<T>, "Type must be integral");
  return detail::mpi_size_cast<T>(value);
}

template <typename T>
std::size_t cast_to_size(T value) {
  static_assert(std::is_integral_v<T>, "Type must be integral");
  return detail::cast_to_size(value);
}

template <typename T>
T cast_to_int(std::size_t value) {
  static_assert(std::is_integral_v<T>, "Type must be integral");
  assert(static_cast<std::size_t>(std::numeric_limits<T>::max()) >= value);
  return static_cast<T>(value);
}

template <typename T, typename S, typename std::enable_if_t<std::is_floating_point_v<S>, int> = 0>
T cast_to_int(S value) {
  assert(static_cast<double>(std::numeric_limits<T>::max()) >= value);
  return static_cast<T>(value);
}

template <typename E>
std::underlying_type_t<E> enum_underlying_cast(E value)
{
  static_assert(std::is_enum_v<E>, "E must be an enumeration type");
  return static_cast<std::underlying_type_t<E>>(value);
}

template <typename D, typename S>
D& cast_to_derived(S& value)
{
  using RawSource = remove_cvrefptr_t<S>;
  using RawDest = remove_cvrefptr_t<D>;

  static_assert(std::is_base_of_v<
    RawSource,
    RawDest>, "Destanation type must be derived from source");
  return static_cast<D&>(value);
}

template <typename D, typename S>
const D& cast_to_derived(const S& value)
{
  using RawSource = remove_cvrefptr_t<S>;
  using RawDest = remove_cvrefptr_t<D>;

  static_assert(std::is_base_of_v<
    RawSource,
    RawDest>, "Destanation type must be derived from source");
  return static_cast<D&>(value);
}

} // namespace utils
