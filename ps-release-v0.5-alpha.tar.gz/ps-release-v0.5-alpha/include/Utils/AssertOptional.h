#pragma once

#include <cassert>
#include <optional>

namespace utils
{

template<typename T>
class AssertOptional final
{
public:
    AssertOptional() = default;
    explicit AssertOptional(T value)
        : internal_value_or_none_{std::move(value)}
    {}

    template<typename... Args>
    AssertOptional(Args&&... values)
    {
        internal_value_or_none_.emplace(std::forward<Args>(values)...);
    }

    void insert(T value)
    {
        assert(!internal_value_or_none_.has_value());
        internal_value_or_none_ = std::move(value);
    }

    template<typename... Args>
    void emplace(Args&&... args)
    {
        assert(!internal_value_or_none_.has_value());
        internal_value_or_none_.emplace(std::forward<Args>(args)...);
    }

    T& value() noexcept
    {
        assert(internal_value_or_none_.has_value());
        return internal_value_or_none_.value();
    }

    const T& value() const noexcept
    {
        assert(internal_value_or_none_.has_value());
        return internal_value_or_none_.value();
    }

private:
    std::optional<T> internal_value_or_none_;
};

} // namespace utils
