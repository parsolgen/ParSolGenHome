#pragma once

#include "MakeWithCapacity.h"

#include <unordered_set>
#include <vector>

namespace utils
{

template<typename T>
void set_union(std::unordered_set<T>& destanation, const std::unordered_set<T>& source)
{
    for (const auto& e : source) {
        destanation.insert(e);
    }
}

template<typename T>
std::unordered_set<T> set_union_and_create(
    const std::unordered_set<T>& lhs,
    const std::unordered_set<T>& rhs)
{
    auto res = MakeWithCapacity<std::unordered_set<T>>(lhs.size() + rhs.size());
    set_union(res, lhs);
    set_union(res, rhs);
    return res;
}

template<typename T>
std::vector<T> to_vector(const std::unordered_set<T>& uset)
{
    auto result = utils::MakeWithCapacity<std::vector<T>>(uset.size());
    for (const auto& e : uset) {
        result.push_back(e);
    }
    return result;
}

} // namespace utils
