#pragma once

#include "TypeTraits.h"

#include <algorithm>
#include <cassert>
#include <unordered_map>
#include <unordered_set>

namespace utils
{

template<typename K, typename V>
V& find_and_assert(std::unordered_map<K, V>& map, const K key)
{
    auto it = map.find(key);
    assert(it != map.end());
    return it->second;
}

template<typename K, typename V>
const V& find_and_assert(const std::unordered_map<K, V>& map, const K key)
{
    const auto it = map.find(key);
    assert(it != map.end());
    return it->second;
}

template<typename T>
T& find_and_assert(std::unordered_set<T>& set, const T key)
{
    auto it = set.find(key);
    assert(it != set.end());
    return *it;
}

template<typename T>
const T& find_and_assert(const std::unordered_set<T>& set, const T key)
{
    const auto it = set.find(key);
    assert(it != set.end());
    return *it;
}

template<typename T, std::enable_if_t<utils::is_standard_container_v<T>, int> = 0>
decltype(auto) find_and_assert(const T& collection, typename T::value_type value)
{
    auto it = std::find(
        collection.begin(),
        collection.end(),
        value);
    assert(it != collection.end());
    return *it;
}

template<typename K, typename V>
std::optional<V> get_or_none(const std::unordered_map<K, V>& map, K key)
{
    const auto it = map.find(key);
    if (it == map.end()) {
        return {};
    }
    return it->second;
}

} // namespace utils
