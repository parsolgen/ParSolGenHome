#pragma once

#include "MakeWithCapacity.h"

namespace utils {

template <typename T>
T MakeWithCapacity(std::size_t capacity) {
  T result;
  result.reserve(capacity);
  return result;
}

} // namespace utils