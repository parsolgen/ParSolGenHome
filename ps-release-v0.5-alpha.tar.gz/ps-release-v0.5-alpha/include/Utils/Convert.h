#pragma once

#include <list>
#include <unordered_set>
#include <vector>

namespace utils
{

template<typename T>
std::unordered_set<T> to_uset(const std::vector<T>& vec)
{
    std::unordered_set<T> result;
    result.reserve(vec.size());
    std::copy(vec.begin(), vec.end(), std::inserter(result, result.end()));
    return result;
}

template<typename T>
std::unordered_set<T> to_uset(const std::list<T>& vec)
{
    std::unordered_set<T> result;
    result.reserve(vec.size());
    std::copy(vec.begin(), vec.end(), std::inserter(result, result.end()));
    return result;
}


} // namespace utils
