#pragma once

#include "MoveAndClear.h"

namespace utils
{

template<typename T>
std::remove_reference_t<T>&& move_and_clear(T&& value)
{
    T tmp = std::move(value);
    value.clear();
    return std::move(tmp);
}

} // namespace utils
