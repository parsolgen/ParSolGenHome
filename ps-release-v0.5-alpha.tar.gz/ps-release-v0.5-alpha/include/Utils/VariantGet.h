#pragma once

#include <variant>
#include <cassert>

template<typename T, typename V>
T assert_get(V&& variant)
{
    assert(std::holds_alternative<T>(variant));
    return std::get<T>(variant);
}