#pragma once

#include <unordered_map>
#include <any>
#include <typeindex>

namespace utils
{

class TypeSafeMapOfAny final
{
public:
    void reserve(std::size_t capacity);
    void clear();

    template<typename T1, typename T2>
    const T1* value_or_none() const;

    template<typename T1, typename T2>
    T1* value_or_none();

    template<typename T1, typename T2>
    T1& create_or_get_value();

    template<typename T1, typename T2>
    const T1& create_or_get_value();

    template<typename T1, typename T2>
    void insert(T1&& value);

private:
    std::unordered_map<std::type_index, std::any> rhs_type_to_data_;
};

} // namespace utils

#include "TypeSafeMapOfAny.inl"
