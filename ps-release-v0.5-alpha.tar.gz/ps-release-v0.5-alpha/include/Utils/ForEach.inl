#pragma once

#include "ForEach.h"

namespace utils
{
namespace impl {

template <typename F, std::size_t I, typename... Ts>
void for_each(F visitor, const std::tuple<Ts...>& tuple) {
  visitor(std::get<I>(tuple));
  if constexpr (I < sizeof...(Ts) - 1) {
    for_each<F, I + 1, Ts...>(std::forward<F>(visitor), tuple);
  }
}

template <typename F, std::size_t I, typename... Ts>
void for_each(F visitor, std::tuple<Ts...>& tuple) {
  visitor(std::get<I>(tuple));
  if constexpr (I < sizeof...(Ts) - 1) {
    for_each<F, I + 1, Ts...>(std::forward<F>(visitor), tuple);
  }
}

template <typename F, std::size_t I, typename... Ts>
void for_each_if(F visitor, const std::tuple<Ts...>& tuple) {
  if (!visitor(std::get<I>(tuple))) {
    return;
  }
  if constexpr (I < sizeof...(Ts) - 1) {
    for_each_if<F, I + 1, Ts...>(std::forward<F>(visitor), tuple);
  }
}

template <typename F, std::size_t I, typename... Ts>
void for_each_if(F visitor, std::tuple<Ts...>& tuple) {
  if (!visitor(std::get<I>(tuple))) {
    return;
  }
  if constexpr (I < sizeof...(Ts) - 1) {
    for_each_if<F, I + 1, Ts...>(std::forward<F>(visitor), tuple);
  }
}

} // namespace impl

template <typename F, typename... Ts>
void for_each(F visitor, const std::tuple<Ts...>& tuple) {
  if constexpr (sizeof...(Ts) == 0) {
    (void)visitor;
    return;
  }
  else {
    impl::for_each<F, 0, Ts...>(std::forward<F>(visitor), tuple);
  }
}

template <typename F, typename... Ts>
void for_each(F visitor, std::tuple<Ts...>& tuple) {
  if constexpr (sizeof...(Ts) == 0) {
    (void)visitor;
    return;
  }
  else {
    impl::for_each<F, 0, Ts...>(std::forward<F>(visitor), tuple);
  }
}

template <typename F, typename... Ts>
void for_each_if(F visitor, const std::tuple<Ts...>& tuple) {
  if constexpr (sizeof...(Ts) == 0) {
    (void)visitor;
    return;
  }
  else {
    impl::for_each_if<F, 0, Ts...>(std::forward<F>(visitor), tuple);
  }
}

template <typename F, typename... Ts>
void for_each_if(F visitor, std::tuple<Ts...>& tuple) {
  if constexpr (sizeof...(Ts) == 0) {
    (void)visitor;
    return;
  }
  else {
    impl::for_each_if<F, 0, Ts...>(std::forward<F>(visitor), tuple);
  }
}

namespace detail {

template<typename F, typename TFirst, typename... Ts>
void for_each(F op, const TFirst& first, const Ts&... args) {
    op(first);
    if constexpr (sizeof...(args) == 0) {
        return;
    }
    else {
        for_each(op, args...);
    }
}

template<typename F, typename TFirst, typename... Ts>
void for_each(F op, TFirst& first, Ts&... args) {
    op(first);
    if constexpr (sizeof...(args) == 0) {
        return;
    }
    else {
        for_each(op, args...);
    }
}

} // namespace detail

template<typename F, typename... Ts>
void for_each(F op, const Ts&... args) {
    if constexpr (sizeof...(args) == 0) {
        return;
    }
    else {
        detail::for_each(op, args...);
    }
}

template<typename F, typename... Ts>
void for_each(F op, Ts&... args) {
    if constexpr (sizeof...(args) == 0) {
        return;
    }
    else {
        detail::for_each(op, args...);
    }
}

} // namespace utils
