#pragma once

#include <atomic>

namespace rts {

class SpinLock final {
public:
  SpinLock();

public:
  void lock();

  void unlock();

private:
  std::atomic<bool> locked_;
};

} // namespace rts