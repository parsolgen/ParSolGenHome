#pragma once

#include "Types.h"

#include "Mpi/Mpi.h"

namespace rts
{
namespace comm
{

int get_comm_size(MPI_Comm comm);
int get_my_rank(MPI_Comm comm);

} // namespace comm
} // namespace rts
