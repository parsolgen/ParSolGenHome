#pragma once

#include "ComplexTypeConstructor.h"

#include "Utils/Cast.h"
#include "Utils/TupleIterator.h"

#include <algorithm>
#include <array>

namespace rts {
namespace comm {
namespace impl {

template <typename T>
std::pair<MPI_Datatype, void*> create_mpi_type(const ContiguousArray<T>& array);

template <typename T>
std::pair<MPI_Datatype, void*> create_mpi_type(const ArrayWithStride<T>& array);

template <typename... Ts>
std::pair<MPI_Datatype, void*> create_mpi_type(const Struct<Ts...>& str);

template <typename T>
std::pair<MPI_Datatype, void*> create_mpi_type(const ContiguousArray<T>& array) {
  MPI_Datatype result;
  MPI_CHECKED_CALL(MPI_Type_contiguous(utils::mpi_size_cast(array.size), mpi_data_type<T>::value, &result));
  MPI_CHECKED_CALL(MPI_Type_commit(&result));
  return std::make_pair(result, array.ptr);
}

template <typename T>
std::pair<MPI_Datatype, void*> create_mpi_type(const ArrayWithStride<T>& array) {
  MPI_Datatype result;
  MPI_CHECKED_CALL(MPI_Type_vector(utils::mpi_size_cast(array.size), utils::mpi_size_cast(array.block_size),
      utils::mpi_size_cast(array.stride), mpi_data_type<T>::value, &result));
  MPI_CHECKED_CALL(MPI_Type_commit(&result));
  return std::make_pair(result, array.ptr);
}

template <typename T>
std::pair<MPI_Datatype, void*> create_mpi_type(const StructElement<T>& element) {
  return std::make_pair(mpi_data_type<T>::value, element.ptr);
}

template <typename... Ts>
std::pair<MPI_Datatype, void*> create_mpi_type(const Struct<Ts...>& str) {
  static constexpr const auto n = sizeof...(Ts);
  std::array<int, n> array_of_blklens;
  std::array<MPI_Datatype, n> array_of_types;
  std::array<MPI_Aint, n> array_of_displs;
  std::array<void*, n> array_of_ptrs;

  MPI_Datatype result;

  std::fill(array_of_blklens.begin(), array_of_blklens.end(), 1);

  for_each_type(
      [&array_of_ptrs, &array_of_types](const auto& value, const auto i) {
        const auto result = create_mpi_type(value);
        array_of_types[i] = result.first;
        array_of_ptrs[i] = result.second;
      },
      str.values);

  const auto first_field_addr = reinterpret_cast<MPI_Aint>(array_of_ptrs[0]);
  array_of_displs[0] = 0;
  for (std::size_t i = 1; i < n; ++i) {
    MPI_Aint field_address = 0;
    MPI_CHECKED_CALL(MPI_Get_address(array_of_ptrs[i], &field_address));
    array_of_displs[i] = MPI_Aint_diff(field_address, first_field_addr);
  }
  MPI_CHECKED_CALL(MPI_Type_create_struct(
      utils::mpi_size_cast(n), array_of_blklens.data(), array_of_displs.data(), array_of_types.data(), &result));
  MPI_CHECKED_CALL(MPI_Type_commit(&result));
  return std::make_pair(result, array_of_ptrs[0]);
}

} // namespace impl

template <typename T>
std::pair<MPI_Datatype, void*> construct_mpi_datatype(const T& type) {
  return impl::create_mpi_type(type);
}

template <typename T>
StructElement<T>::StructElement(T* in_ptr) : ptr{in_ptr} {}

template <typename T>
ContiguousArray<T>::ContiguousArray(T* in_ptr, std::size_t in_size) : ptr{in_ptr}, size{in_size} {}

template <typename T>
ArrayWithStride<T>::ArrayWithStride(T* in_ptr, std::size_t in_size, std::size_t in_block_size, std::size_t in_stride)
    : ptr{in_ptr}, size{in_size}, block_size{in_block_size}, stride{in_stride} {}

template <typename... Ts>
Struct<Ts...>::Struct(typename Struct<Ts...>::types in_values) : values{std::move(in_values)} {}

} // namespace comm
} // namespace rts