#pragma once

#include "Communicator.h"

#include <iostream>

namespace rts {
namespace comm {

template <std::uint16_t N>
int Communicator::ProcCoordsToRank(const ProcessCoordinates<N>& coords) {
  int result = 0;
  if (comm_ == MPI_COMM_WORLD) {
    return utils::mpi_size_cast(coords[0]);
  }
  MPI_CHECKED_CALL(MPI_Cart_rank(comm_, coords.data(), &result));
  return result;
}

template <typename P, typename R, typename S>
void Communicator::StartAndWaitAllMessagesReceived(P&& on_ready_message, R&& on_receive_mesasge, S&& serializer) {
  for (std::size_t probed_messages = 0; probed_messages < n_messages_to_receive_; ++probed_messages) {
    MPI_Status status;
    MPI_CHECKED_CALL(MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, comm_, &status));
    int message_byte_size = 0;
    MPI_Request req;
    MPI_CHECKED_CALL(MPI_Get_count(&status, MPI_BYTE, &message_byte_size));
    //std::cout << "Mesage from " << status.MPI_SOURCE << "\n";
    auto buffer = on_ready_message(status.MPI_TAG, utils::cast_to_size(message_byte_size));
    MPI_CHECKED_CALL(MPI_Recv(buffer.get(), message_byte_size, MPI_BYTE,
        status.MPI_SOURCE, status.MPI_TAG, comm_, MPI_STATUS_IGNORE));
    on_receive_mesasge(status.MPI_TAG, std::move(buffer));
  }
}

} // namespace comm
} // namespace rts
