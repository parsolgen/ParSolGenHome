#pragma once

#include "XContainer.h"

#include <cassert>

namespace rts {

template <typename T>
T& XContainer::get() {
  auto& value_or_none = std::get<std::optional<T>>(data_);
  assert(value_or_none);
  return *value_or_none;
}

template <typename T>
const T& XContainer::get() const {
  const auto& value_or_none = std::get<std::optional<T>>(data_);
  assert(value_or_none);
  return *value_or_none;
}

template <typename T>
bool XContainer::has_value() const {
  return std::get<std::optional<T>>(data_).has_value();
}

template <typename T>
void XContainer::set(T&& val) {
  std::get<std::optional<T>>(data_) = std::move(val);
}

} // namespace rts