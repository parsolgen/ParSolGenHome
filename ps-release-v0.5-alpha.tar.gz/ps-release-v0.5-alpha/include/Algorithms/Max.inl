#pragma once

#include "Max.h"

#include <algorithm>

namespace rts
{
namespace algo
{

namespace detail
{

template<typename T, typename TFirst, typename... TRest>
T max(TFirst first, TRest... rest)
{
    if constexpr (sizeof...(rest) == 0) {
        return first;
    }
    else {
        return std::max(first, max<TRest...>(rest...));
    }
}

template<typename T, typename... Ts>
T max(Ts... args)
{
    if constexpr (sizeof...(args) == 0) {
        return T{};
    }
    else {
        return detail::max(args...);
    }
}

} // namespace detail

template<typename T, typename... Ts>
T max(const Ts&... args)
{
    return detail::max<Ts...>(args...);
}

} // namespace algo
} // namespace rts
