#pragma once

#include "Reduction.h"

#include "Comm/ComplexTypeConstructor.h"
#include "Utils/Cast.h"

namespace algo
{
namespace impl
{

template<typename T>
T reduce(
    T input,
    ReduceOperation op_kind,
    MPI_Comm comm)
{
    static MPI_Op op_kind_to_mpi_op[] = {
        MPI_SUM,
        MPI_MAX,
        MPI_MIN
    };
    T result;
    MPI_CHECKED_CALL(MPI_Allreduce(
        &input,
        &result,
        1,
        rts::comm::mpi_data_type<T>::value,
        op_kind_to_mpi_op[utils::enum_underlying_cast(op_kind)],
        comm));
    return result;
}

} // namespace impl

template <typename V, typename F>
typename V::element_t reduce(
    const V& vec,
    rts::ElementVersion version,
    ReduceOperation oper_kind,
    F op,
    typename V::element_t init,
    MPI_Comm comm)
{
    const auto key = vec.GetKey();
    vec.ForEachElementWithSpecifiedVersionParallel(
        version,
        [&init, &op, key](
            const auto coord,
            const auto version,
            const auto* ptr,
            const auto length)
        {
            const auto arg = rts::TaskArgument{
                key,
                version,
                coord};
            op(init, arg, ptr, length);
        });
    return impl::reduce(init, oper_kind, comm);
}

template <typename V, typename F, typename E>
typename V::element_t reduce(
    const V& vec,
    rts::ElementVersion version,
    ReduceOperation oper_kind,
    F op,
    typename V::element_t init,
    MPI_Comm comm,
    E& executor)
{
    const auto key = vec.GetKey();
    vec.ForEachElementWithSpecifiedVersionWithExecutor(
        version,
        [&init, &op, key](
            const auto coord,
            const auto version,
            const auto* ptr,
            const auto length)
        {
            const auto arg = rts::TaskArgument{
                key,
                version,
                coord};
            op(init, arg, ptr, length);
        },
        executor);
    return impl::reduce(init, oper_kind, comm);
}

} // namespace algo
