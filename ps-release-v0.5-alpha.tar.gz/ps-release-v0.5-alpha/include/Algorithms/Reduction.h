#pragma once

#include "Mpi/Mpi.h"
#include "Task/Task.h"

namespace algo
{

enum class ReduceOperation : std::uint16_t
{
    Sum = 0,
    Max,
    Min,
};

namespace impl
{

template<typename T>
T reduce(
    T input,
    ReduceOperation op_kind,
    MPI_Comm comm);

} // namespace impl

template <typename V, typename F>
typename V::element_t reduce(
    const V& vec,
    rts::ElementVersion version,
    ReduceOperation oper_kind,
    F op,
    typename V::element_t init,
    MPI_Comm comm);

template <typename V, typename F, typename E>
typename V::element_t reduce(
    const V& vec,
    rts::ElementVersion version,
    ReduceOperation oper_kind,
    F op,
    typename V::element_t init,
    MPI_Comm comm,
    E& executor);

} // namespace algo

#include "Reduction.inl"
