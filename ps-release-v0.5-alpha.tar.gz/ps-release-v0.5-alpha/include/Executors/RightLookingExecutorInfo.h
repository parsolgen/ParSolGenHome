#pragma once

#ifdef SG_USE_ACCEL
#include "DeviceUtils/Types.h"
#endif

#include <cstdint>
#include <vector>

namespace rts {

struct RightLookingExecutorInfo final {
  std::size_t n_ready_inputs = 0;
  bool reduction_barrier_task = false;
  bool executed = false;

  inline void reset() {
    n_ready_inputs = 0;
    executed = false;
  }
};

inline void Serialize(const RightLookingExecutorInfo& info, std::vector<std::uint64_t>& buffer) {
  buffer.push_back(info.n_ready_inputs);
}

} // namespace rts