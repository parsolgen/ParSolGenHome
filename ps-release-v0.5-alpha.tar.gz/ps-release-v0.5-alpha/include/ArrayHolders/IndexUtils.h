#pragma once

#include "Task/Task.h"
#include "Utils/Unreachable.h"

namespace rts
{
namespace impl
{

template<ArrayDim N>
constexpr ArrayElementCoordinates<N> get_zero_coords()
{
    if constexpr (N == 1) {
        return ArrayElementCoordinates<N>{0};
    }
    if constexpr (N == 2) {
        return ArrayElementCoordinates<N>{0, 0};
    }
    if constexpr (N == 3) {
        return ArrayElementCoordinates<N>{0, 0, 0};
    }
    assert(false);
    return ArrayElementCoordinates<N>{};
}

} // namespace impl

template<ArrayDim N>
std::size_t array_coords_to_index_offset(
    const ArrayElementCoordinates<2>& coords,
    const ArrayDimensions<N>& array_dims,
    const ArrayDimensions<N>& subarray_coords);

template<ArrayDim N, ArrayDim BlockN>
ArrayDimensions<BlockN> calculate_last_block_dims(
    const ArrayElementCoordinates<3>& block_coords,
    const ArrayDimensions<N>& glob_array_dims,
    const ArrayDimensions<BlockN>& block_dims,
    const ArrayDimensions<BlockN>& last_block_dims)
{
    if constexpr (N == 1) {
        if (block_coords[0] != glob_array_dims[0] - 1) {
            return block_dims;
        }
        if constexpr (BlockN == 1) {
            return ArrayDimensions<1>{last_block_dims[0]};
        }
        if constexpr (BlockN == 2) {
            return ArrayDimensions<2>{block_dims[0], last_block_dims[0]};
        }
        if constexpr (BlockN == 3) {
            return ArrayDimensions<3>{block_dims[0], last_block_dims[0], block_dims[2]};
        }
    }
    if constexpr (N == 2) {
        if constexpr (BlockN == 1) {
            if (block_coords[1] == glob_array_dims[1] - 1) {
                return ArrayDimensions<1>{last_block_dims[0]};
            }
            return ArrayDimensions<1>{block_dims[0]};
        }
        else if constexpr (BlockN == 2) {
            if (block_coords[0] != glob_array_dims[0] - 1
                && block_coords[1] != glob_array_dims[1] - 1)
            {
                return block_dims;
            }
            if (block_coords[0] == glob_array_dims[0] - 1
                && block_coords[1] == glob_array_dims[1] - 1) {
                    return ArrayDimensions<2>{last_block_dims[0], last_block_dims[1]};
            }
            if (block_coords[0] == glob_array_dims[0] - 1) {
                return ArrayDimensions<2>{last_block_dims[0], block_dims[1]};
            }
            if (block_coords[1] == glob_array_dims[1] - 1) {
                return ArrayDimensions<2>{block_dims[0], last_block_dims[1]};
            }
        }
        else if constexpr (BlockN == 3) {
            if (block_coords[0] != glob_array_dims[0] - 1
                && block_coords[1] != glob_array_dims[1] - 1
                && block_coords[2] != glob_array_dims[2] - 1)
            {
                return block_dims;
            }
            if (block_coords[0] == glob_array_dims[0] - 1
                && block_coords[1] == glob_array_dims[1] - 1) {
                    return ArrayDimensions<3>{
                        last_block_dims[0], 
                        last_block_dims[1],
                        block_dims[2]};
            }
            if (block_coords[0] == glob_array_dims[0] - 1) {
                return ArrayDimensions<3>{
                    last_block_dims[0],
                    block_dims[1],
                    block_dims[2]};
            }
            if (block_coords[1] == glob_array_dims[1] - 1) {
                return ArrayDimensions<3>{
                    block_dims[0],
                    last_block_dims[1],
                    block_dims[2]};
            }
        }
    }
    if constexpr (N == 3) {
        if constexpr (BlockN == 1) {
            if (block_coords[2] == glob_array_dims[2] - 1) {
                return ArrayDimensions<1>{last_block_dims[0]};
            }
            return ArrayDimensions<1>{block_dims[0]};
        }
        else if constexpr (BlockN == 2) {
            return ArrayDimensions<2>{
                block_coords[1] == glob_array_dims[1] - 1 ? last_block_dims[0] : block_dims[0],
                block_coords[2] == glob_array_dims[2] - 1 ? last_block_dims[1] : block_dims[1]};
        }
        else if constexpr (BlockN == 3) {
            return ArrayDimensions<3>{
                block_coords[0] == glob_array_dims[0] - 1 ? last_block_dims[0] : block_dims[0],
                block_coords[1] == glob_array_dims[1] - 1 ? last_block_dims[1] : block_dims[1],
                block_coords[2] == glob_array_dims[2] - 1 ? last_block_dims[2] : block_dims[2]};
        }
    }

    assert(false);
    sg_unreachable();

    return ArrayDimensions<BlockN>{};
}

} // namespace rts

#include "IndexUtils.inl"
