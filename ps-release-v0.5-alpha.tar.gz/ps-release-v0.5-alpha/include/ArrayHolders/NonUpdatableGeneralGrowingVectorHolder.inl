#pragma once

#include "NonUpdatableGeneralGrowingVectorHolder.h"
#include "ArrayUtils.h"

#include "Utils/Unused.h"
#include "Utils/Unreachable.h"

#include <numeric>
#include <cstring>

namespace rts
{

template<ArrayDim N, typename T>
NonUpdatableGeneralGrowingVectorHolder<N, T>::NonUpdatableGeneralGrowingVectorHolder(
    ArrayKey array_id,
    ElementVersion nversions,
    ArrayDimensions<N> global_array_dims,
    ArrayDimensions<N> local_subarray_dims,
    ArrayElementCoordinates<N> local_subarray_coords,
    std::size_t default_el_len)
    : array_id_{array_id}
    , nversions_{nversions}
    , global_array_dims_{global_array_dims}
    , local_subarray_dims_{local_subarray_dims}
    , local_subarray_coords_{local_subarray_coords}
    , index_{nversions, impl::get_zero_coords<N>(), global_array_dims}
{
    if (default_el_len > 0) {
        default_el_len_ = default_el_len;
    }
    init(nversions,
        global_array_dims);
}

template<ArrayDim N, typename T>
NonUpdatableGeneralGrowingVectorHolder<N, T>::Element*
NonUpdatableGeneralGrowingVectorHolder<N, T>::GetPtr(
    const TaskArgument& arg)
{
    std::lock_guard guard{m_};

    assert(arg.version != std::numeric_limits<int>::max());
    const auto offset_or_none = index_.get(arg);
    assert(offset_or_none.has_value());
    const auto offset = offset_or_none.value();
    assert(offset < map_.size());
    return map_[offset];
}

template<ArrayDim N, typename T>
const NonUpdatableGeneralGrowingVectorHolder<N, T>::Element*
NonUpdatableGeneralGrowingVectorHolder<N, T>::GetPtr(
    const TaskArgument& arg) const
{
    std::lock_guard guard{m_};

    assert(arg.version != std::numeric_limits<int>::max());
    const auto offset_or_none = index_.get(arg);
    assert(offset_or_none.has_value());
    const auto offset = offset_or_none.value();
    assert(offset < map_.size());
    return map_[offset];
}

template<ArrayDim N, typename T>
const NonUpdatableGeneralGrowingVectorHolder<N, T>::Element*
NonUpdatableGeneralGrowingVectorHolder<N, T>::GetInPtr(
    const TaskArgument& arg) const
{
    std::lock_guard guard{m_};

    assert(arg.version != std::numeric_limits<int>::max());
    const auto offset_or_none = index_.get(arg);
    assert(offset_or_none.has_value());
    const auto offset = offset_or_none.value();
    assert(offset < map_.size());
    return map_[offset];
}

template<ArrayDim N, typename T>
comm::SerializedMPIDataType NonUpdatableGeneralGrowingVectorHolder<N, T>::GetMpiTypeForReceivingBlock(
    std::uint8_t* data,
    std::size_t byte_size)
{
    return comm::construct_mpi_datatype(
        comm::ContiguousArray{
            reinterpret_cast<std::uint8_t*>(data),
            byte_size});
}

template<ArrayDim N, typename T>
comm::SerializedMPIDataType NonUpdatableGeneralGrowingVectorHolder<N, T>::GetMpiTypeForSendingBlock(
    const TaskArgument& arg)
{
    const auto offset_or_none = index_.get(arg);
    assert(offset_or_none.has_value());
    auto* element = map_[offset_or_none.value()];
    const auto data_byte_size = element->data_.size() * sizeof(T);
    element->h_.byte_size = sizeof(BlockHeader) + data_byte_size;
    // The element's physical storage slot is shared across every version that
    // maps to it modulo nversions_ (see NonUpdatableArrayIndexStorage::
    // get_element_offset) - with nversions_==1 (as every GrowingArray mailbox
    // here is), ALL versions share the single slot created once by init(),
    // whose h_.version is stamped at that one-time creation and never
    // revisited by plain writes through GetPtr(). Without refreshing it here,
    // a receiver that depends on this exact arg (task-graph identity, fixed
    // at commit() time and reused unchanged across every later re-execution
    // of the committed task graph) sees the stale original version in the
    // wire header instead of the one it is keyed on, and asserts/drops the
    // message in on_var_received - reproducing as "passes at 1 MPI rank,
    // fails only with >1" since a single rank never exercises this Send path.
    element->h_.version = arg.version;

    return comm::construct_mpi_datatype(
        comm::Struct{
            std::tuple{
                comm::ContiguousArray{
                    reinterpret_cast<std::uint8_t*>(&element->h_),
                    sizeof(BlockHeader)
                },
                comm::ContiguousArray{
                    reinterpret_cast<std::uint8_t*>(element->data_.data()),
                    data_byte_size
                }
            }
        });
}

template<ArrayDim N, typename T>
TaskArgument NonUpdatableGeneralGrowingVectorHolder<N, T>::InsertReceivedBlock(
    ArrayKey key,
    std::unique_ptr<std::uint8_t[]>&& block_mem)
{
    std::lock_guard guard{m_};

    assert(key == array_id_);
    const auto* data = block_mem.get();
    const auto& hdr = *reinterpret_cast<const BlockHeader*>(data);
    const auto payload_byte_size = (hdr.byte_size - sizeof(BlockHeader));

    assert(payload_byte_size % sizeof(T) == 0);

    std::vector<T> element_data(payload_byte_size / sizeof(T));
    std::memcpy(
        element_data.data(),
        reinterpret_cast<const uint8_t*>(data) + sizeof(BlockHeader),
        payload_byte_size);

    if constexpr (N == 1) {
        TaskArgument var{key, hdr.version, hdr.coords[0]};
        elements_.emplace_back(hdr, std::move(element_data));
        map_.push_back(&elements_.back());
        const auto block_offset = map_.size() - 1;

        index_.emplace(
            var,
            block_offset);
        return var;
    }
    else if constexpr (N == 2) {
        TaskArgument var{
            key,
            hdr.version,
            ArrayElementCoordinates<2>{hdr.coords[0], hdr.coords[1]}};
        elements_.emplace_back(hdr, std::move(element_data));
        map_.push_back(&elements_.back());
        const auto block_offset = map_.size() - 1;

        index_.emplace(
            var,
            block_offset);
        return var;
    }
    else if constexpr (N == 3)
    {
        TaskArgument var{
            key,
            hdr.version,
            ArrayElementCoordinates<3>{hdr.coords[0], hdr.coords[1], hdr.coords[2]}};
        elements_.emplace_back(hdr, std::move(element_data));
        map_.push_back(&elements_.back());
        const auto block_offset = map_.size() - 1;

        index_.emplace(
            var,
            block_offset);
        return var;
    }

    assert(false);
    sg_unreachable();

    return TaskArgument{};
}

template<ArrayDim N, typename T>
ArrayKey NonUpdatableGeneralGrowingVectorHolder<N, T>::GetKey() const
{
    return array_id_;
}

template<ArrayDim N, typename T>
std::size_t NonUpdatableGeneralGrowingVectorHolder<N, T>::GetLen(
    const TaskArgument& arg) const
{
    std::lock_guard guard{m_};

    assert(arg.version != std::numeric_limits<int>::max());
    const auto offset_or_none = index_.get(arg);
    assert(offset_or_none.has_value());
    const auto offset = offset_or_none.value();
    assert(offset < map_.size());
    return map_[offset]->data.data_.size();
}

template<ArrayDim N, typename T>
NonUpdatableGeneralGrowingVectorHolder<N, T>::Element*
    NonUpdatableGeneralGrowingVectorHolder<N, T>::GetLatestElementPtr(
    const TaskArgument& arg)
{
    SG_UNUSED_PARAMETER(arg);
    assert(false);
    return nullptr;
}

template<ArrayDim N, typename T>
const NonUpdatableGeneralGrowingVectorHolder<N, T>::Element*
    NonUpdatableGeneralGrowingVectorHolder<N, T>::GetLatestElementPtr(
    const TaskArgument& arg) const
{
    SG_UNUSED_PARAMETER(arg);
    assert(false);
    return nullptr;
}

template<ArrayDim N, typename T>
bool NonUpdatableGeneralGrowingVectorHolder<N, T>::isLocal(const TaskArgument& arg) const
{
    return index_.has(arg);
}

template<ArrayDim N, typename T>
void NonUpdatableGeneralGrowingVectorHolder<N, T>::init(
    ElementVersion nversion,
    const ArrayDimensions<N>& array_dims)
{
    const auto build_index_for_version = [&](const auto version) {
        if constexpr (N == 1) {
            const auto end_0 = local_subarray_coords_[0] + local_subarray_dims_[0];
            for (ArrayElementCoord i = local_subarray_coords_[0] + 1; i < end_0; ++i) {
                insert_new_block(
                    version,
                    ArrayElementCoordinates<1>{i});
            }
        }
        else if constexpr (N == 2) {
            const auto end_0 = local_subarray_coords_[0] + local_subarray_dims_[0];
            const auto end_1 = local_subarray_coords_[1] + local_subarray_dims_[1];
            for (ArrayElementCoord i = local_subarray_coords_[0]; i < end_0; ++i) {
                for (ArrayElementCoord j = local_subarray_coords_[1]; j < end_1; ++j) {
                    insert_new_block(
                        version,
                        ArrayElementCoordinates<2>{i, j});
                }
            }
        }
        else if constexpr (N == 3) {
            const auto end_0 = local_subarray_coords_[0] + local_subarray_dims_[0];
            const auto end_1 = local_subarray_coords_[1] + local_subarray_dims_[1];
            const auto end_2 = local_subarray_coords_[2] + local_subarray_dims_[2];
            for (ArrayElementCoord i = local_subarray_coords_[0]; i < end_0; ++i) {
                for (ArrayElementCoord j = local_subarray_coords_[1]; j < end_1; ++j) {
                    for (ArrayElementCoord k = local_subarray_coords_[2]; k < end_2; ++k) {
                        insert_new_block(
                            version,
                            ArrayElementCoordinates<3>{i, j, k});
                    }
                }
            }
        }
        else {
            assert(false);
        }
    };
    for (ElementVersion i = 0; i < nversion; ++i) {
        build_index_for_version(i);
    }
}

template<ArrayDim N, typename T>
void NonUpdatableGeneralGrowingVectorHolder<N, T>::insert_new_block(
    ElementVersion version,
    const ArrayElementCoordinates<N>& coords)
{
    const auto block_byte_size = sizeof(BlockHeader);

    BlockHeader block_hdr;
    const auto el_offset = map_.size();

    block_hdr.array_id = array_id_;
    block_hdr.version = version;
    block_hdr.byte_size = block_byte_size;
    block_hdr.coords[0] = coords[0];

    if constexpr (N == 1) {
        index_.emplace(
            TaskArgument{
                array_id_,
                version,
                coords[0]},
            el_offset);
    }
    else if constexpr (N == 2) {
        index_.emplace(
            TaskArgument{
                array_id_,
                version,
                coords},
            el_offset);
        block_hdr.coords[1] = coords[1];
    }
    else if constexpr (N == 3) {
        index_.emplace(
            TaskArgument{
                array_id_,
                version,
                coords},
            el_offset);
        block_hdr.coords[1] = coords[1];
        block_hdr.coords[2] = coords[2];
    }
    else {
        assert(false);
        sg_unreachable();
    }

    elements_.emplace_back(block_hdr);
    map_.push_back(&elements_.back());
}

} // namespace rts
