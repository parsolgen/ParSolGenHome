#pragma once

#include "Task/Task.h"

namespace rts
{

template<typename T, typename F>
class TmpArraysStorage final
{
public:
    TmpArraysStorage(F initializer);

    void init();

    T* GetPtr(const TaskArgument& arg);

    const T* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& coords);

    TaskArgument InsertReceivedBlock(ArrayKey id, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    bool isLocal(const TaskArgument& var);

    void free(const TaskArgument& var);

private:
    F initializer_;
    std::unordered_map<ArrayKey, T> array_holders_;
};

} // namespace rts

#include "TmpArraysStorage.inl"