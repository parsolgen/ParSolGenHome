#pragma once

#include "TmpContiguousArray.h"

namespace rts
{

template<typename T>
TmpContiguousArray<T>::TmpContiguousArray(
    std::size_t init_n_instances,
    ArrayElementCoord n)
    : block_len_{n}
    , block_size_{n * sizeof(T) + sizeof(Header)}
{
}

template<typename T>
void TmpContiguousArray<T>::allocate(
    const TaskArgument& arg)
{
    if (free_blocks_.empty()) {
        for (std::size_t i = 0; i < free_blocks_.size() * grow_factor; ++i) {
            free_blocks_.emplace_back(
                std::make_unique<std::uint8_t[]>(block_size_));
        }
    }
    auto block = std::move(free_blocks_.back());
    block_key_to_block_ptr_.emplace(
        BlockKey{arg.array_or_var, arg.version},
        std::move(free_blocks_.back()));
    free_blocks_.pop_back();
}

template<typename T>
T* TmpContiguousArray<T>::GetPtr(const TaskArgument& arg)
{
    auto it = block_key_to_block_ptr_.find(
        BlockKey{
            arg.array_or_var,
            arg.version});
    assert(it != block_key_to_block_ptr_.end());
    auto block_ptr = it->second.get();
    return reinterpret_cast<T*>(block_ptr + data_offset_);
}

template<typename T>
const T* TmpContiguousArray<T>::GetPtr(const TaskArgument& arg) const
{
    const auto it = block_key_to_block_ptr_.find(
        BlockKey{
            arg.array_or_var,
            arg.version});
    assert(it != block_key_to_block_ptr_.end());
    const auto block_ptr = it->second.get();
    return reinterpret_cast<const T*>(block_ptr + data_offset_);
}

template<typename T>
comm::SerializedMPIDataType TmpContiguousArray<T>::GetMpiTypeForReceivingBlock(
    std::uint8_t* data,
    std::size_t byte_size)
{
    return comm::construct_mpi_datatype(
        comm::ContiguousArray{
            data,
            byte_size});
}

template<typename T>
comm::SerializedMPIDataType TmpContiguousArray<T>::GetMpiTypeForSendingBlock(
    const TaskArgument& arg)
{
    return comm::construct_mpi_datatype(
        comm::ContiguousArray{
            reinterpret_cast<std::uint8_t*>(GetPtr(arg)),
            block_size_});
}

template<typename T>
TaskArgument TmpContiguousArray<T>::InsertReceivedBlock(
    ArrayKey id,
    std::unique_ptr<std::uint8_t[]>&& block_mem)
{
    const auto* header = reinterpret_cast<const Header*>(
        block_mem.get());
    assert(id == header->array_id);
    block_key_to_block_ptr_.emplace(
        BlockKey{
            header->array_id,
            header->version
        },
        std::move(block_mem));
    return TaskArgument{header->array_id, header->version};
}

template<typename T>
ArrayKey TmpContiguousArray<T>::GetKey() const
{
    assert(false);
    return 0;
}

template<typename T>
std::size_t TmpContiguousArray<T>::GetLen(const TaskArgument& var) const
{
    return block_len_;
}

template<typename T>
bool TmpContiguousArray<T>::isLocal(const TaskArgument& var)
{
    return block_key_to_block_ptr_.find(
        BlockKey{
            var.array_or_var,
            var.version}) != block_key_to_block_ptr_.end();
}

template<typename T>
void TmpContiguousArray<T>::free(const TaskArgument& var)
{
    
}

template<typename T>
bool TmpContiguousArray<T>::BlockKey::operator==(const BlockKey& rhs) const noexcept
{
    return array_id == rhs.array_id && version == rhs.version;
}

} // namespace rts
