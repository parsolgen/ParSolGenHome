#pragma once

#include "Comm/Types.h"

#include "Task/Task.h"

namespace rts
{

template<ArrayDim AreaDim>
ArrayDimensions<1> get_local_subarray_dims(
    const ArrayDimensions<1>& array_dims,
    const ArrayDimensions<2>& area_distr);

template<ArrayDim AreaDim0, ArrayDim AreaDim1>
ArrayDimensions<2> get_local_subarray_dims(
    const ArrayDimensions<2>& array_dims,
    const ArrayDimensions<2>& area_distr);

ArrayDimensions<1> get_local_subarray_dims(
    const ArrayDimensions<1>& array_dims,
    const ArrayDimensions<1>& area_distr);

template<ArrayDim AreaDim0, ArrayDim AreaDim1>
ArrayElementCoordinates<2> get_local_subarray_coords(
    const ArrayDimensions<2>& area_dims,
    const comm::ProcessCoordinates<2>& cart_coords,
    const comm::ProcessCoordinates<2>& cart_size);

template<ArrayDim AreaDim0>
ArrayElementCoordinates<1> get_local_subarray_coords(
    const ArrayDimensions<2>& area_dims,
    const comm::ProcessCoordinates<2>& cart_coords,
    const comm::ProcessCoordinates<2>& cart_size);

} // namespace rts

#include "AreaUtils.inl"
