#pragma once

#include "IndexUtils.h"

namespace rts
{

template<ArrayDim N>
std::size_t array_coords_to_index_offset(
    const ArrayElementCoordinates<3>& coords,
    const ArrayDimensions<N>& array_dims,
    const ArrayDimensions<N>& subarray_coords)
{
    if constexpr (N == 1) {
        assert(coords[0] >= subarray_coords[0]);
        return coords[0] - subarray_coords[0];
    }
    if constexpr (N == 2) {
        assert(coords[0] >= subarray_coords[0]);
        assert(coords[1] >= subarray_coords[1]);
        return (coords[0] - subarray_coords[0]) * array_dims[1]
            + coords[1] - subarray_coords[1];
    }
    if constexpr (N == 3) {
        assert(coords[0] >= subarray_coords[0]);
        assert(coords[1] >= subarray_coords[1]);
        assert(coords[2] >= subarray_coords[2]);
        return (coords[0] - subarray_coords[0]) * array_dims[1] * array_dims[2]
            + (coords[1] - subarray_coords[1]) * array_dims[1]
            + coords[2] - subarray_coords[2];
    }
    assert(false);
    return 0;
}

} // namespace rts
