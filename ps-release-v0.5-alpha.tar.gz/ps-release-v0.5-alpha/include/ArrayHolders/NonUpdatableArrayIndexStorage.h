#pragma once

#include "Task/Task.h"

#include <optional>

namespace rts
{

template<typename T, ArrayDim N>
class NonUpdatableArrayIndexStorage final
{
public:
    NonUpdatableArrayIndexStorage(
        ElementVersion nversions,
        ArrayElementCoordinates<N> array_coords,
        ArrayElementCoordinates<N> array_dims);

    NonUpdatableArrayIndexStorage(
        ElementVersion nversions,
        ArrayElementCoordinates<N> array_coords,
        ArrayElementCoordinates<N> array_dims,
        const T& default_value);

public:
    void insert(const TaskArgument& key, T&& value);

    void insert(const TaskArgument& key, const T& value);

    template<typename... Args>
    void emplace(const TaskArgument& key, Args&&... args);

    std::optional<T> get(const TaskArgument& key) const;

    template<typename F>
    void for_each(F op);

    bool has(const TaskArgument& key) const noexcept;

private:
    T* get_ptr(const TaskArgument& key);

    const T* get_ptr(const TaskArgument& key) const;

    std::size_t get_element_offset(const TaskArgument& key) const;

    void update_presence_flags(const TaskArgument& key);

private:
    ElementVersion nversions_;
    ArrayElementCoordinates<N> array_coords_;
    ArrayDimensions<N> array_dims_;
    ArrayElementCoord array_len_;
    std::vector<T> elements_storage_;
    std::vector<bool> present_elements_;
    std::vector<TaskArgument> coords_;
};

} // namespace rts

#include "NonUpdatableArrayIndexStorage.inl"
