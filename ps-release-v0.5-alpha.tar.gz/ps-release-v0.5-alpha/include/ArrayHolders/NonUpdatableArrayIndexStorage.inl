#pragma once

#include "NonUpdatableArrayIndexStorage.h"

#include "ArrayUtils.h"
#include "IndexUtils.h"

#include <type_traits>

namespace rts
{

template<typename T, ArrayDim N>
NonUpdatableArrayIndexStorage<T, N>::NonUpdatableArrayIndexStorage(
    ElementVersion nversions,
    ArrayElementCoordinates<N> array_coords,
    ArrayElementCoordinates<N> array_dims)
    : nversions_{nversions}
    , array_coords_{std::move(array_coords)}
    , array_dims_{array_dims}
    , array_len_{get_array_length<N>(array_dims)}
    , elements_storage_(array_len_ * nversions)
    , present_elements_(array_len_ * nversions, false)
    , coords_(array_len_ * nversions)
{}

template<typename T, ArrayDim N>
NonUpdatableArrayIndexStorage<T, N>::NonUpdatableArrayIndexStorage(
    ElementVersion nversions,
    ArrayElementCoordinates<N> array_coords,
    ArrayElementCoordinates<N> array_dims,
    const T& default_value)
    : nversions_{nversions}
    , array_coords_{std::move(array_coords)}
    , array_dims_{array_dims}
    , array_len_{get_array_length<N>(array_dims)}
    , elements_storage_(array_len_ * nversions, default_value)
    , present_elements_(array_len_ * nversions, false)
    , coords_(array_len_ * nversions)
{}

template<typename T, ArrayDim N>
void NonUpdatableArrayIndexStorage<T, N>::insert(const TaskArgument& key, T&& value)
{
    update_presence_flags(key);
    *get_ptr(key) = std::forward<T, N>(value);
}

template<typename T, ArrayDim N>
void NonUpdatableArrayIndexStorage<T, N>::insert(const TaskArgument& key, const T& value)
{
    update_presence_flags(key);
    *get_ptr(key) = value;
}

template<typename T, ArrayDim N>
template<typename... Args>
void NonUpdatableArrayIndexStorage<T, N>::emplace(const TaskArgument& key, Args&&... args)
{
    update_presence_flags(key);
    new (get_ptr(key)) T(std::forward<Args>(args)...);
}

template<typename T, ArrayDim N>
std::optional<T> NonUpdatableArrayIndexStorage<T, N>::get(const TaskArgument& key) const
{
    const auto* ptr = get_ptr(key);
    if (ptr == nullptr) {
        return {};
    }
    return *ptr;
}

template<typename T, ArrayDim N>
template<typename F>
void NonUpdatableArrayIndexStorage<T, N>::for_each(F op)
{
    assert(elements_storage_.size() == present_elements_.size());
    assert(elements_storage_.size() == coords_.size());
    for (std::size_t i = 0; i < elements_storage_.size(); ++i) {
        if (present_elements_[i]) {
            op(coords_[i], elements_storage_[i]);
        }
    }
}

template<typename T, ArrayDim N>
bool NonUpdatableArrayIndexStorage<T, N>::has(const TaskArgument& key) const noexcept
{
    const auto offset = get_element_offset(key);
    assert(offset < present_elements_.size());
    return present_elements_[offset];
}

template<typename T, ArrayDim N>
T* NonUpdatableArrayIndexStorage<T, N>::get_ptr(const TaskArgument& key)
{
    const auto offset = get_element_offset(key);
    assert(offset < elements_storage_.size());
    if (!present_elements_[offset]) {
        return nullptr;
    }
    return elements_storage_.data() + offset;
}

template<typename T, ArrayDim N>
const T* NonUpdatableArrayIndexStorage<T, N>::get_ptr(const TaskArgument& key) const
{
    const auto offset = get_element_offset(key);
    assert(offset < elements_storage_.size());
    if (!present_elements_[offset]) {
        return nullptr;
    }
    return elements_storage_.data() + offset;
}

template<typename T, ArrayDim N>
std::size_t NonUpdatableArrayIndexStorage<T, N>::get_element_offset(const TaskArgument& key) const
{
    const auto& coords = key.coords_or_none;
    const std::size_t offset = (key.version % nversions_) * array_len_;
    return offset + array_coords_to_index_offset<N>(
        coords,
        array_dims_,
        array_coords_);
}

template<typename T, ArrayDim N>
void NonUpdatableArrayIndexStorage<T, N>::update_presence_flags(const TaskArgument& key)
{
    const auto offset = get_element_offset(key);
    assert(offset < present_elements_.size());
    assert(offset < coords_.size());
    present_elements_[offset] = true;
    coords_[offset] = key;
}

} // namespace rts
