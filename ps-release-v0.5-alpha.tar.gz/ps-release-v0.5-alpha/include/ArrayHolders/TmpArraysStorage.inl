#pragma once

#include "TmpArraysStorage.h"

namespace rts
{
    
} // namespace rts
