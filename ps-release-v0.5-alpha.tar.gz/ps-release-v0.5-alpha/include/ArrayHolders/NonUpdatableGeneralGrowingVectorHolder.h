#pragma once

#include "IndexUtils.h"

#include "NonUpdatableArrayIndexStorage.h"

#include "Task/Task.h"
#include "Comm/ComplexTypeConstructor.h"

#include <list>
#include <memory>
#include <mutex>

namespace rts
{
struct INonUpdatableSerializableArray
{
    virtual ~INonUpdatableSerializableArray() = default;

    [[nodiscard]]
    virtual comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg) = 0;

    [[nodiscard]]
    virtual TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem) = 0;

    [[nodiscard]]
    virtual ArrayKey GetKey() const = 0;

    [[nodiscard]]
    virtual comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size) = 0;

    void remove_element(const TaskArgument& arg);
};

template<ArrayDim N, typename T>
class NonUpdatableGeneralGrowingVectorHolder final : public INonUpdatableSerializableArray
{
private:
#pragma pack(push, 1)
    struct BlockHeader final
    {
        ArrayKey array_id;
        ElementVersion version;
        ArrayElementCoord coords[N];
        std::size_t byte_size;
    };
#pragma pack(pop)

public:
    struct Element final
    {
        BlockHeader h_;
        std::vector<T> data_;

        Element(BlockHeader in_h, std::vector<T> in_data)
            : h_{in_h}
            , data_{std::move(in_data)}
        {}

        explicit Element(BlockHeader in_h)
            : h_{in_h}
        {}
    };

public:
    NonUpdatableGeneralGrowingVectorHolder(
        ArrayKey array_id,
        ElementVersion nversions,
        ArrayDimensions<N> global_array_dims,
        ArrayDimensions<N> local_subarray_dims,
        ArrayElementCoordinates<N> local_subarray_coords,
        std::size_t default_el_len);

public:
    [[nodiscard]]
    Element* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const Element* GetPtr(const TaskArgument& arg) const;

    [[nodiscard]]
    const Element* GetInPtr(const TaskArgument& arg) const;

    [[nodiscard]]
    virtual comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size) override;

    [[nodiscard]]
    virtual comm::SerializedMPIDataType GetMpiTypeForSendingBlock(
        const TaskArgument& arg) override;

    [[nodiscard]]
    virtual TaskArgument InsertReceivedBlock(
        ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem) override;

    [[nodiscard]]
    virtual ArrayKey GetKey() const override;

    std::size_t GetLen(const TaskArgument& var) const;

    bool isLocal(const TaskArgument& arg) const;

    Element* GetLatestElementPtr(const TaskArgument& arg);

    const Element* GetLatestElementPtr(const TaskArgument& arg) const;

    void reset() {}

private:
    void init(
        ElementVersion nversion,
        const ArrayDimensions<N>& array_dims);

    void insert_new_block(
        ElementVersion version,
        const ArrayElementCoordinates<N>& coords);

private:
    ArrayKey array_id_;
    ElementVersion nversions_;
    ArrayDimensions<N> global_array_dims_;
    ArrayDimensions<N> local_subarray_dims_;
    ArrayElementCoordinates<N> local_subarray_coords_;
    std::size_t default_el_len_ = 100;
    NonUpdatableArrayIndexStorage<std::size_t, N> index_;
    std::list<Element> elements_;
    std::vector<Element*> map_;
    mutable std::mutex m_;
};

} // namespace rts

#include "NonUpdatableGeneralGrowingVectorHolder.inl"
