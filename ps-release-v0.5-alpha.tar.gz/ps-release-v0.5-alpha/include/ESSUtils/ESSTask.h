#pragma once

#include "Task/Task.h"

namespace rts
{

struct OutputToSend final
{
    TaskArgument var;
    int proc;

    OutputToSend(TaskArgument in_var, int in_proc);
};

struct ESSTask final
{
    ESSTask(TaskId in_op,
        std::vector<TaskArgument> in_inputs,
        std::vector<TaskArgument> in_outputs
#ifdef SG_USE_GOOPAX
        , bool in_goopax_support
        , bool in_cpu_support
#endif
    );

    TaskId op;
    std::vector<TaskArgument> inputs;
    std::vector<TaskArgument> outputs;
#ifdef SG_USE_GOOPAX
    bool goopax_support;
    bool cpu_support = true;
#endif
    std::vector<ESSTask*> consumers_;
    std::size_t n_total_inputs_ = 0;
    std::size_t n_ready_inputs_ = 0;
    std::size_t n_referenced_inputs_ = 0;
    std::size_t n_init_ready_inputs_ = 0;
    std::vector<OutputToSend> outputs_to_send_;
};

#ifdef SG_USE_ACCEL
using ESSTaskOperation = std::function<void(DeviceId, ESSTask&)>;
#else
using ESSTaskOperation = std::function<void(ESSTask&)>;
#endif

using ESSTaskOperations = std::vector<ESSTaskOperation>;

} // namespace rts
