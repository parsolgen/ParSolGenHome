#pragma once

#include "ESSDistributorContainer.h"
#include "ESSTask.h"

#include "Comm/Communicator.h"

#include <atomic>
#include <memory>

namespace rts
{

class ESSProblem final
{
public:
    struct Stencil final
    {
        ArrayKey array_id;
        int offset_0;
        int offset_1;
        int offset_2;
    };

public:
    ESSProblem(
        std::size_t n_arrays,
        ElementVersion n_versions,
        ESSDistributorContainer& distributors,
        ESSTaskOperations ops,
        MPI_Comm comm);

    void execute_and_wait();

    void insert_task(
        TaskId op_id,
        std::vector<TaskArgument> inputs,
        std::vector<TaskArgument> outputs,
        std::vector<Stencil> in_stencils,
        bool ready
#ifdef SG_USE_GOOPAX
        , bool cpu_support,
        , bool goopax_support
#endif
        );

    void commit();

    void reset();

    void clear();

#ifndef NDEBUG
    void print();
#endif
private:
    void on_var_received(const TaskArgument& var);

    void on_ready_task(ESSTask* t);

    void submit_task(ESSTask* t);

    void wait_executed();

    inline
    void check_ready_and_submit_task(ESSTask* t)
    {
        std::lock_guard guard_{mutex_};

        if (++t->n_ready_inputs_ == t->n_total_inputs_)
        {
            submit_task(t);
        }
    }

    void submit_task_cpu(ESSTask* t);

    static TaskArgument get_task_arg(const ESSTask* t);

private:
    static constexpr const auto n_default_inputs = 10;

    struct NonLocalNeighbourDescriptor final
    {
#ifndef NDEBUG
        bool init_ = false;
        ArrayElementCoordinates<3> coords_;
#endif
        std::vector<ESSTask*> consumers_;
    };

    struct StencilHash final
    {
        std::size_t operator()(const Stencil& el) const noexcept;
    };

    std::size_t n_arrays_;
    ElementVersion n_versions_;
    ESSDistributorContainer& distributors_;
    ESSTaskOperations ops_;

    comm::Communicator comm_;

    std::unordered_map<TaskArgument, NonLocalNeighbourDescriptor> neighbours_;
    std::unordered_map<TaskArgument, std::unordered_set<int>> non_local_consumers_;

    std::list<ESSTask> tasks_;
    std::list<ESSTask> ready_tasks_;
    std::unordered_map<TaskArgument, ESSTask*> arg_to_task_;
    std::size_t n_tasks_ = 0;
    std::atomic<std::size_t> n_executed_tasks_ = 0;
    std::size_t n_message_to_recv_ = 0;
    std::mutex mutex_;
};

std::unique_ptr<ESSProblem> create_essp(
    std::size_t n_arrays,
    ElementVersion n_versions,
    ESSDistributorContainer& distributors,
    ESSTaskOperations& ops,
    MPI_Comm comm);

bool operator==(const ESSProblem::Stencil& lhs, const ESSProblem::Stencil& rhs);;

} // namespace rts
