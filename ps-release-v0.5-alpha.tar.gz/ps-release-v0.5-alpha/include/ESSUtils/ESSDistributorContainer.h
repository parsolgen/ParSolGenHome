#pragma once

#include "ESSDistributor.h"

namespace rts
{

class ESSDistributorContainer final
{
public:
    explicit ESSDistributorContainer(
        std::size_t n_arrays,
        std::array<ArrayDimSize, 3> ghost_edge_deph_p,
        std::array<ArrayDimSize, 3> ghost_edge_deph_n,
        std::array<int, 3> cart_coords,
        std::array<int, 3> cart_size,
        MPI_Comm cart_comm);

public:
    [[nodiscard]]
    inline
    int get_rank() const noexcept
    {
        return rank_;
    }

    void register_array(ArrayKey array_id, std::array<ArrayDimSize, 3> glob_n);

    [[nodiscard]]
    TaskArgument to_local_coords(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    bool is_border(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    bool is_local(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    std::optional<int> get_target(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    std::vector<int> get_targets(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    std::vector<TaskArgument> get_local_coords(ArrayKey array_id) const noexcept;

private:
    [[nodiscard]]
    const ESSDistributor& get_distributor(const TaskArgument& arg) const noexcept;

public:
    std::array<ArrayDimSize, 3> ghost_edge_deph_p_;
    std::array<ArrayDimSize, 3> ghost_edge_deph_n_;
    std::array<int, 3> cart_coords_;
    std::array<int, 3> cart_size_;
    MPI_Comm cart_comm_;
    int rank_ = 0;
    std::vector<utils::AssertOptional<ESSDistributor>> distributors_;
};

} // namespace rts
