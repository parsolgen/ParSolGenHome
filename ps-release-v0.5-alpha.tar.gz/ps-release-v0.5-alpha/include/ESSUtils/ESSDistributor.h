#pragma once

#include "Task/Task.h"
#include "Storage/VersionedStorage.h"
#include "Utils/AssertOptional.h"
#include "Mpi/Mpi.h"

#include <optional>

namespace rts
{

class ESSDistributor final
{
public:
    ESSDistributor(
        std::array<ArrayDimSize, 3> glob_n,
        std::array<ArrayDimSize, 3> ghost_edge_deph_p,
        std::array<ArrayDimSize, 3> ghost_edge_deph_n,
        std::array<int, 3> cart_coords,
        std::array<int, 3> cart_size,
        MPI_Comm cart_comm);

    struct DDDistribution final
    {
        ArrayElementCoordinates<3> subarea_coords;
        ArrayElementCoordinates<3> subarea_dim;
    };

public:
    [[nodiscard]]
    inline
    int get_rank() const noexcept
    {
        return rank_;
    }

    [[nodiscard]]
    bool is_local(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    bool is_ghost_local(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    std::optional<int> get_target(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    std::vector<int> get_targets(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    inline
    ArrayDimSize get_local_n1() const noexcept
    {
        return loc_n_[0];
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_local_n2() const noexcept
    {
        return loc_n_[1];
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_local_n3() const noexcept
    {
        return loc_n_[2];
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_n1() const noexcept
    {
        return glob_n_[0];
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_n2() const noexcept
    {
        return glob_n_[1];
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_n3() const noexcept
    {
        return glob_n_[2];
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_ghost_deph_n(int i) const noexcept
    {
        return ghost_edge_deph_p_[i] + ghost_edge_deph_n_[i];
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_ghost_deph_n1() const noexcept
    {
        return get_ghost_deph_n(0);
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_ghost_deph_n2() const noexcept
    {
        return get_ghost_deph_n(1);
    }

    [[nodiscard]]
    inline
    ArrayDimSize get_ghost_deph_n3() const noexcept
    {
        return get_ghost_deph_n(2);
    }

    [[nodiscard]]
    TaskArgument to_local_coords(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    bool is_border(const TaskArgument& glob_arg) const noexcept;

    void adjust();

    [[nodiscard]]
    DDDistribution distribute_area(
        const ArrayElementCoordinates<3>& dim) const noexcept;

    [[nodiscard]]
    static DDDistribution distribute_area(
        const ArrayElementCoordinates<3>& dim,
        const std::array<int, 3> cart_coords,
        const std::array<int, 3> cart_size);

    [[nodiscard]]
    inline
    std::vector<TaskArgument> get_local_coords() const noexcept
    {
        return local_elements_;
    }

#ifndef NDEBUG
    void print() const noexcept;
    void print_distr_state() const noexcept;
    void fail_dump(
        const std::string& file,
        int line,
        const TaskArgument& arg) const noexcept;
    void print_map() const noexcept;
#endif

private:
    struct DistributedElement final
    {
        // DLB can re-assign these elements
        // The non-local elements can still appear in the local elements map
        bool local_ = false;
        bool border_ = false;
        int target_ = -1;
    };

    DistributedElement& get_distr_el(const TaskArgument& glob_arg) noexcept;

    const DistributedElement& get_distr_el(const TaskArgument& glob_arg) const noexcept;

    [[nodiscard]]
    bool is_within_subarea(const ArrayElementCoordinates<3>& coords) const noexcept;

private:
    std::array<ArrayDimSize, 3> glob_n_;
    std::array<ArrayDimSize, 3> ghost_edge_deph_p_;
    std::array<ArrayDimSize, 3> ghost_edge_deph_n_;
    std::array<int, 3> cart_coords_;
    std::array<int, 3> cart_size_;
    std::array<ArrayDimSize, 3> loc_n_;
    ArrayElementCoordinates<3> subarea_coords_;
    ArrayElementCoordinates<3> subarea_border_;

    MPI_Comm cart_comm_;
    int rank_ = 0;
    std::vector<TaskArgument> local_elements_;
    
    utils::AssertOptional<NonVersioned3DMeshStorage<DistributedElement>> local_subarea_;
};

} // namespace rts