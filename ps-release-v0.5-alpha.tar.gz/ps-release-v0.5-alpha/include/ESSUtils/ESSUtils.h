#pragma once

#include "ESSProblem.h"

#include <memory>

namespace rts
{

class ESSProblemHolder final
{
public:
    void execute_and_wait();

    void commit();

    void reset();

    void clear();

    template<typename F>
    void initialize(F&& initializer)
    {
        if (impl_ == nullptr)
        {
            impl_ = initializer();
        }
    }

private:
    std::unique_ptr<ESSProblem> impl_ = nullptr;
};

} // namespace rts
