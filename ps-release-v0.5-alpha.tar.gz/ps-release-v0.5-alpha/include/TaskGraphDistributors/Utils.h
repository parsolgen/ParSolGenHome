#pragma once

#include "Task/Task.h"

namespace rts
{

const TaskArgument* arg_by_task(const Task& task);

} // namespace rts
