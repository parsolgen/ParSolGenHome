#pragma once

#include "Comm/Types.h"
#include "Task/Task.h"

#include <unordered_map>
#include <unordered_set>

namespace rts {

using ProcessCoordsVector = std::vector<comm::ProcessCoord>;

using ProcessCoordsUSet = std::unordered_set<comm::ProcessCoord>;

using TaskGraphDistribution = std::unordered_map<TaskArgument, ProcessCoordsVector>;

} // namespace rts