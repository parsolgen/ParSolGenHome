#pragma once

#include "Task/TaskGraph.h"

#include "Types.h"

namespace rts {

TaskGraphDistribution DistributeCSRSlaeSolverLikeAlgorithmGraph(const TaskGraph& graph, int nparts);

} // namespace rts
