#include "Utils.h"

namespace rts
{

const TaskArgument* arg_by_task(const Task& task)
{
    const auto find_arg = [](const std::vector<TaskArgument>& args) -> const TaskArgument* {
        for (const auto& arg : args) {
            if (arg.array) {
                return &arg;
            }
        }
        return nullptr;
    };
    if (!task.outputs.empty()) {
        const auto* result_or_null = find_arg(task.outputs);
        if (result_or_null != nullptr) {
            return result_or_null;
        }
    }
    if (!task.inputs.empty()) {
        const auto* result_or_null = find_arg(task.inputs);
        if (result_or_null != nullptr) {
            return result_or_null;
        }
    }
    return nullptr;
}

} // namespace rts
