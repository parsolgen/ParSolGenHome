#pragma once

#include <tuple>

namespace rts {

template <typename F, typename... Ts>
void for_each_type(F&& visitor, const std::tuple<Ts...>& tuple);

template <typename F, typename... Ts>
void for_each_type(F&& visitor, std::tuple<Ts...>& tuple);

} // namespace rts

#include "TupleIterator.inl"
