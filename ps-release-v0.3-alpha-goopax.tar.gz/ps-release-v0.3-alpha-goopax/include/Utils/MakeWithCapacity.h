#pragma once

#include <cstdint>

namespace utils {

template <typename T>
T MakeWithCapacity(std::size_t capacity);

} // namespace utils

#include "MakeWithCapacity.inl"
