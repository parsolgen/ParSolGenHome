#pragma once

#include "HashCombine.h"

#include <array>
#include <vector>

namespace std
{

template<typename T>
struct hash<std::array<T, 1>> final
{
    size_t operator()(const std::array<T, 1>& el) const noexcept
    {
        return std::hash(el[0]);
    }
};

template<typename T>
struct hash<std::array<T, 2>> final
{
    size_t operator()(const std::array<T, 2>& el) const noexcept
    {
        size_t result = 0;
        utils::hash_combine(result, el[0]);
        utils::hash_combine(result, el[1]);
        return result;
    }
};

} // namespace std
