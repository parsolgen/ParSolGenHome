#pragma once

#include <cstdint>

namespace rts {

using TaskId = std::size_t;

using TaskIndex = std::size_t;

using DeviceId = std::size_t;

constexpr const DeviceId cpu_dev_id = 0;

} // namespace rts