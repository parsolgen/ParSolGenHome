#pragma once

#include "Types.h"

#include "Mpi/Mpi.h"

namespace rts
{

class TaskGraph;

TaskGraphDistribution distribute_explicit_solver_graph(
    int nproc,
    const ArrayDimensions<1>& area_dims,
    const TaskGraph& task_graph);

TaskGraphDistribution distribute_explicit_solver_graph(
    const ArrayDimensions<2>& area_dims,
    const TaskGraph& task_graph,
    const comm::ProcessCoordinates<2>& proc_cart_dims,
    MPI_Comm comm);

ArrayDimensions<1> distribute_area(
    int nproc,
    const ArrayDimensions<1>& area_dims);

ArrayDimensions<2> distribute_area(
    const ArrayDimensions<2>& area_dims,
    const comm::ProcessCoordinates<2>& cart_dims,
    MPI_Comm comm);

} // namespace rts
