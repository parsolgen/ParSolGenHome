#pragma once

#include "IExecutor.h"

#include "Task/TaskGraph.h"
#include "TaskQueue/PrioritizedBWTaskQueue.h"
#ifdef SG_USE_ACCEL
#include "DeviceUtils/Fwd.h"
#include "TaskQueue/PrioritizedBWTaskQueueDev.h"
#endif

#include "CgGate/rts.h"

#include <atomic>
#include <condition_variable>
#include <mutex>

namespace rts
{
namespace impl
{

inline
std::optional<TaskArgument> get_related_var(const Task& task)
{
    if (!task.outputs.empty()) {
        return task.outputs[0];
    }
    if (!task.inputs.empty()) {
        return task.inputs[0];
    }
    return {};
}

} // namespace impl

class ESSExecutor final : public IExecutor
{
public:
    using OnReadyTask = std::function<void(Task& task)>;

public:
    ESSExecutor(
        ArrayElementCoordinates<2> local_subdomain_coords,
        ArrayDimensions<2> local_subdomain_len,
        TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
        TaskGraph local_graph,
        std::size_t nthreads);

public: // public IExecutor
    virtual void wait() override;

    virtual void ready_var(const TaskArgument& var) override;

    virtual void start() override;

    virtual void set_ready_task_handler(OnReadyTask handler) override;

    virtual void ready_task(Task& task) override;

    virtual void stop() override;

    virtual void reset() override;

private:
    [[nodiscard]]
    bool is_border(const TaskArgument& var) const noexcept;

    void submit_task(const Task& task);

    inline
    void submit_task_cpu(const Task& task)
    {
        const auto var_or_none = impl::get_related_var(task);
        if (internal::get_n_threads() == 1) {
            task_queue_.submit(task);
        }
        else if (!var_or_none.has_value()) {
            task_queue_.submit(task);
        }
        else if (is_border(var_or_none.value())) {
            task_queue_.submit_hp(task);
        }
        else {
            task_queue_.submit(task);
        }
    }

#ifdef SG_USE_GOOPAX
    inline
    void submit_task_dev(DeviceId dev_id, const Task& task)
    {
        assert(dev_id != cpu_dev_id);
        const auto var_or_none = impl::get_related_var(task);
        if (!var_or_none.has_value()) {
            goopax_task_queue_.submit(dev_id, task);
        }
        if (is_border(var_or_none.value())) {
            goopax_task_queue_.submit_hp(dev_id, task);
        }
        else {
            goopax_task_queue_.submit(dev_id, task);
        }
    }
#endif

private:
    ArrayElementCoordinates<2> local_subdomain_coords_;
    ArrayDimensions<2> local_subdomain_len_;
#ifdef SG_USE_ACCEL
    std::unique_ptr<IDeviceScheduler> devices_scheduler_;
#endif
    TaskGraph local_task_graph_;
    std::size_t nthreads_;
    PrioritizedBWTaskQueue task_queue_;
    OnReadyTask ready_task_handler_;
    std::atomic<std::size_t> executed_tasks_;
    std::atomic<bool> running_ = false;
    std::mutex mutex_;
#ifdef SG_USE_GOOPAX
    PrioritizedBWTaskQueueDev goopax_task_queue_;
#endif
};

} // namespace rts
