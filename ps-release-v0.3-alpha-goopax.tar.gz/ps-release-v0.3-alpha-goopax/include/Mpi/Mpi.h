#pragma once

#include <cassert>

#define OMPI_SKIP_MPICXX 1

#include <mpi.h>

#define MPI_CHECKED_CALL(x)             \
  do {                                  \
    const auto ___r = x;                 \
    if (___r != 0) {                     \
      MPI_Abort(MPI_COMM_WORLD, ___r);   \
    }                                   \
  } while (false)
