#pragma once

#include "Mpi/Mpi.h"

namespace algo
{

enum class ReduceOperation : std::uint16_t
{
    Sum = 0,
    Max,
    Min,
};

template <typename V, typename F>
typename V::element_t reduce(
    const V& vec,
    rts::ElementVersion version,
    ReduceOperation oper_kind,
    F op,
    typename V::element_t init,
    MPI_Comm comm);

} // namespace algo

#include "Reduction.inl"
