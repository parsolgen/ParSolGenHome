#pragma once

#include "Task/Task.h"
#include "Mpi/Mpi.h"

#include <type_traits>
#ifndef NDEBUG
#include <iostream>
#include <limits>
#endif

namespace algo
{

template <typename V>
typename V::element_t dot(
    const V& lhs,
    rts::ElementVersion version,
    MPI_Comm comm);

template <typename V1, typename V2,
    std::enable_if_t<std::is_same_v<typename V1::element_t, typename V2::element_t>, int> = 0>
typename V1::element_t dot(
    const V1& lhs,
    const V2& rhs,
    rts::ElementVersion version,
    MPI_Comm comm);

template <typename V1, typename V2,
    std::enable_if_t<std::is_same_v<typename V1::element_t, typename V2::element_t>, int> = 0>
typename V1::element_t dot(
    const V1& lhs,
    rts::ElementVersion lhs_version,
    const V2& rhs,
    rts::ElementVersion rhs_version,
    MPI_Comm comm);

template<typename V>
typename V::element_t dot(
    const V& lhs,
    const V& rhs,
    rts::TaskGraph& graph,
    MPI_Comm comm);

template<typename V>
typename V::element_t dot(
    const V& lhs,
    rts::TaskGraph& graph,
    MPI_Comm comm);

template<typename V1, typename V2>
void axpy(
    rts::ElementVersion version,
    const V1& lhs,
    V2& rhs,
    typename V1::element_t alpha);

template<typename V1, typename V2>
void axpy(
    const V1& x,
    rts::ElementVersion x_ver,
    V2& y,
    rts::ElementVersion y_ver,
    typename V1::element_t alpha);

template<typename V>
void scal(
    rts::ElementVersion version,
    V& rhs,
    typename V::element_t alpha);

template<typename V1, typename V2>
void vcopy(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs,
    rts::ElementVersion lhs_ver);

template<typename V1, typename V2, typename V3>
void vsum(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs_1,
    rts::ElementVersion lhs_1_ver,
    const V3& lhs_2,
    rts::ElementVersion lhs_2_ver);

template<typename V1, typename V2, typename V3>
void vsub(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs_1,
    rts::ElementVersion lhs_1_ver,
    const V3& lhs_2,
    rts::ElementVersion lhs_2_ver);

template<typename V1, typename V2, typename V3>
void vmul(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs_1,
    rts::ElementVersion lhs_1_ver,
    const V3& lhs_2,
    rts::ElementVersion lhs_2_ver);

template<typename V1, typename V2>
void vmul(
    V1& rhs,
    rts::ElementVersion rhs_ver,
    const V2& lhs_1,
    rts::ElementVersion lhs_1_ver,
    typename V1::element_t alpha);

#ifndef NDEBUG
template<typename T>
void print_vec(const T& lhs, rts::ElementVersion version)
{
    lhs.ForEachElementWithSpecifiedVersion(
        version,
        [&lhs](
            const auto coord,
            const auto v,
            const auto* ptr,
            const auto length)
        {
            std::cout << "V: " << lhs.GetKey()
                << ", B: " << coord << "[";
            for (std::size_t i = 0; i < length; ++i)
            {
                std::cout << ptr[i] << ", ";
            }
            std::cout << "]\n";
        });
}

template<typename T>
void print_vec_last_version(const T& lhs)
{
    print_vec(lhs, std::numeric_limits<rts::ElementVersion>::max());
}
#endif

} // namespace algo

#include "VectorUtils.inl"
