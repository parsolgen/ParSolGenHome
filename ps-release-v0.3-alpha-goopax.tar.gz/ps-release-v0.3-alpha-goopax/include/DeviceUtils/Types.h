#pragma once

#include <cassert>

namespace rts
{
enum class DriverType : int
{
    Cpu = 0,
#ifdef SG_USE_GOOPAX
    Goopax,
#endif
#ifdef SG_USE_CUDA
    Cuda,
#endif
    Last
};

enum class DeviceDataType
{
    Int,
    Float,
    Double,
};

template<typename T>
struct cpp_type_to_device_dtp final
{
};

template<>
struct cpp_type_to_device_dtp<double> final
{
    static constexpr DeviceDataType value = DeviceDataType::Double;
};

template<>
struct cpp_type_to_device_dtp<float> final
{
    static constexpr DeviceDataType value = DeviceDataType::Float;
};

template<>
struct cpp_type_to_device_dtp<int> final
{
    static constexpr DeviceDataType value = DeviceDataType::Int;
};

template<typename T>
constexpr DeviceDataType cpp_type_to_device_dtp_v = cpp_type_to_device_dtp<T>::value;

template<DeviceDataType DTP>
struct device_dtp_to_cpp final
{
};

template<>
struct device_dtp_to_cpp<DeviceDataType::Double> final
{
    using type = double;
};


template<>
struct device_dtp_to_cpp<DeviceDataType::Float> final
{
    using type = float;
};

template<>
struct device_dtp_to_cpp<DeviceDataType::Int> final
{
    using type = int;
};

[[nodiscard]]
inline
std::size_t get_dev_dtp_byte_size(DeviceDataType dtp)
{
    switch (dtp)
    {
    case DeviceDataType::Int:
        return sizeof(int);
    case DeviceDataType::Float:
        return sizeof(float);
    case DeviceDataType::Double:
        return sizeof(double);
    
    default:
        assert(false);
        return 0;
    }
}

} // namespace rts
