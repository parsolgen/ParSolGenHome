#pragma once

#include "IDeviceBuffer.h"
#include "Types.h"

#include <any>
#include <goopax>

namespace rts
{

class GoopaxBuffer;

template<typename F>
class GoopaxBufferVisitor final : public IDeviceBufferVisitor
{
public:
    explicit GoopaxBufferVisitor(F op)
        : op_{std::move(op)}
    {}

public: // IDeviceBufferVisitor
    virtual void visit(GoopaxBuffer& buffer) override
    {
        op_(buffer);
    }

private:
    F op_;
};

class GoopaxBuffer final : public IDeviceBuffer
{
public:
    GoopaxBuffer(goopax::goopax_device dev, DeviceDataType dtp, std::size_t n, void* ptr = nullptr);

    GoopaxBuffer(const GoopaxBuffer&) = delete;
    GoopaxBuffer& operator=(const GoopaxBuffer&) = delete;

public: // public IDdeviceBuffer
    virtual void accept_visitor(IDeviceBufferVisitor& visitor) override;

    [[nodiscard]]
    inline
    virtual std::size_t byte_size() const override
    {
        return byte_size_;
    }

    [[nodiscard]]
    inline
    virtual std::size_t length() const override
    {
        return len_;        
    }

    virtual void init(DeviceDataType dtp, std::size_t n) override;

    [[nodiscard]]
    inline
    virtual DeviceDataType data_type() const override
    {
        return dtp_;
    }

    virtual void copy_to_host_sync(void* dst) override;
    virtual void copy_to_device_sync(const void* src) override;

public:
    template<typename T>
    [[nodiscard]]
    inline
    goopax::buffer<T> get() noexcept
    {
        return goopax::reinterpret<goopax::buffer<T>>(internal_buffer_);
    }

private:
    goopax::buffer<char> internal_buffer_;
    std::size_t byte_size_;
    std::size_t len_;
    DeviceDataType dtp_;
};

} // namespace rts
