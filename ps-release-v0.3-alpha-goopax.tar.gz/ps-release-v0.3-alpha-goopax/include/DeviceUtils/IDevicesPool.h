#pragma once

#include "Fwd.h"

#include <cstdint>
#include <memory>
#include <vector>

namespace rts
{

using DeviceId = std::size_t;

struct IDevicesPool
{
    virtual ~IDevicesPool() = default;

    virtual void init(DevicesManager& dev_mgr) = 0;

    virtual std::size_t get_n_devices() const = 0;
};

using IDevicesPoolPtr = std::unique_ptr<IDevicesPool>;

} // namespace rts
