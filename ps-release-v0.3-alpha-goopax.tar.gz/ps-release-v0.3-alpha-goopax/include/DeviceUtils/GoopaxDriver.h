#pragma once

#include "IDeviceDriver.h"
#include "Types.h"

#include <goopax>

namespace rts
{

class GoopaxDeviceDriver final : public IDeviceDriver
{
private:
    static constexpr const std::size_t n_init_buffers_ = 10;

public:
    GoopaxDeviceDriver(DeviceId id, goopax::goopax_device&& dev);

public: // public IDeviceDriver
    virtual IDeviceBufferPtr create_host_buffer(DeviceDataType dtp, std::size_t n) override;
    virtual IDeviceBufferPtr create_device_buffer(
        DeviceDataType dtp,
        std::size_t n) override;
    virtual IDeviceBufferPtr create_host_buffer(
        void* host_ptr,
        DeviceDataType dtp,
        std::size_t n) override;

    virtual void release(IDeviceBufferPtr&& buffer) override;

    virtual void host_to_device_sync(
        IDeviceBuffer& src_buffer) override;

    virtual IDeviceBufferPtr host_to_device_sync(
        const void* src,
        DeviceDataType dtp,
        std::size_t n) override;

    virtual void device_to_host(IDeviceBuffer& buffer, void* dst) override;

    [[nodiscard]]
    virtual std::size_t get_free_memory_size() override;

    virtual void execute_kernel(TaskOperation& op) override;

    [[nodiscard]]
    inline
    virtual DriverType get_type() const noexcept
    {
        return DriverType::Goopax;
    }

    [[nodiscard]]
    inline
    virtual DeviceId get_id() const noexcept
    {
        return id_;
    }

    [[nodiscard]]
    goopax::goopax_device get_native_dev() const noexcept
    {
        return dev_;
    }

private:
    DeviceId id_;
    goopax::goopax_device dev_;
};

} // namespace rts
