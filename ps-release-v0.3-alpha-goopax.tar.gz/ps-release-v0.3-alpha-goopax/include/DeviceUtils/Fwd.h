#pragma once

namespace rts
{

#ifdef SG_USE_GOOPAX
template<typename F>
class GoopaxBufferVisitor;
class GoopaxBuffer;
#endif

class DevicesManager;
struct IDeviceExecutor;
struct IDeviceScheduler;
struct IDeviceBuffer;

} // namespace rts
