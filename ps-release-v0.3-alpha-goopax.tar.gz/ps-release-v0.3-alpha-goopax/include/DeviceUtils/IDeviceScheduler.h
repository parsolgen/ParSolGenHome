#pragma once

#include "Fwd.h"
#include "Types.h"

#include "Task/Task.h"

namespace rts
{

struct ScheduledDevice final
{
    DeviceId dev_id;
    DriverType driver_type;

    ScheduledDevice() = delete;
};

struct IDeviceScheduler
{
    virtual ~IDeviceScheduler() = default;

    [[nodiscard]]
    virtual ScheduledDevice get_target_device(
        const Task& arg) = 0;
    virtual void release_device(
        DeviceId device_id,
        const Task& task) = 0;
    virtual void release_device(
        DeviceId device_id,
        const TaskArgument& var) = 0;
    virtual void release_device(DeviceId dev_id) = 0;
};

} // namespace rts
