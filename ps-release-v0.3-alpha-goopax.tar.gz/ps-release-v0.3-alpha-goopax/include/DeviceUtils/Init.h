#pragma once

#include <cstdint>

#include "Task/Task.h"

#include "Fwd.h"

#ifdef SG_USE_GOOPAX
#include <goopax>
#endif

namespace rts
{

void init_accel_support();

[[nodiscard]]
IDeviceBuffer* get_dev_buffer_by_var(const TaskArgument& var);

#ifdef SG_USE_GOOPAX
goopax::goopax_device get_goopax_dev_by_var(const TaskArgument& var);
#endif

} // namespace rts
