#pragma once

#include "IDeviceDriver.h"

#include "DriversList.h"

#include "Storage/VersionedStorage.h"
#include "Task/Task.h"
#include "Utils/AssertOptional.h"
#include "Utils/Cast.h"
#include "Utils/SpinLock.h"

#include <deque>
#include <memory>

namespace rts
{

class DevicesManager final
{
public:
    void alloc_and_copy_to_device(
        const TaskArgument& var,
        DeviceId device_id,
        DriverType driver);

    void alloc_device_buffer(
        const TaskArgument& var,
        DeviceId device_id,
        DriverType driver_type);

    static void copy_to_device(
        IDeviceBufferPtr& host_buffer,
        const void* src);

    void copy_to_host(
        const TaskArgument& var,
        DeviceId device_id,
        DriverType driver_type);

    static void copy_to_host(IDeviceBufferPtr& src_buffer, void* dst);

    void register_device(DeviceId device_id, IDeviceDriverPtr&& driver);

    [[nodiscard]]
    IDeviceBuffer* get_dev_buffer_by_var(const TaskArgument& var);

    [[nodiscard]]
    IDeviceDriver* get_dev(const TaskArgument& var);

    [[nodiscard]]
    inline
    DeviceId get_n_devices() const noexcept
    {
#ifndef NDEBUG
    assert(initiazlied_);
#endif
#ifdef SG_USE_GOOPAX
        return device_drivers_.size();
#endif
    }

    [[nodiscard]]
    std::vector<DeviceId> get_devices_with_driver_support(
        DriverType dt) const noexcept;

    [[nodiscard]]
    inline
    IDeviceDriver& get_device(DeviceId device_id, DriverType driver)
    {
        const auto offset = get_driver_offset(device_id, driver);
        assert(offset < device_drivers_.size());
        assert(device_drivers_[offset] != nullptr);
        return *device_drivers_[offset];
    }

    void init(
        std::size_t n_arrays,
        ArrayDimSize n1,
        ArrayDimSize n2,
        ElementVersion n_versions);

private:
    [[nodiscard]]
    inline
    static std::size_t get_driver_offset(DeviceId device_id, DriverType driver) noexcept
    {
        return device_id
            * (utils::enum_underlying_cast(DriverType::Last))
            + utils::enum_underlying_cast(driver);
    }

private:
    struct VarDescriptor final
    {
        std::size_t device_id = 0;
        TaskArgument var;
        IDeviceBufferPtr buffer = nullptr;
        IDeviceDriver* dev = nullptr;
    };

    std::deque<IDeviceDriverPtr> device_drivers_;
    utils::AssertOptional<VersionedStorage<VarDescriptor>> vars_storage_;
#ifndef NDEBUG
    bool initiazlied_ = false;
#endif
};

DevicesManager& get_devices_manager();

} // namespace rts
