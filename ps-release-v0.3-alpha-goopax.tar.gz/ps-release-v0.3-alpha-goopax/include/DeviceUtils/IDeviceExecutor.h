#pragma once

#include "IDeviceDriver.h"

#include "Task/Task.h"

namespace rts
{

struct IDeviceExecutor
{
    virtual ~IDeviceExecutor() = default;

    virtual void execute(
        Task& task,
        DeviceId device_id,
        DriverType driver_type,
        DevicesManager& dev_mgr) = 0;
};

} // namespace rts
