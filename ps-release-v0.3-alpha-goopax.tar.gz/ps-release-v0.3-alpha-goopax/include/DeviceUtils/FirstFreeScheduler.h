#pragma once

#include "IDeviceScheduler.h"

#include "Utils/SpinLock.h"

namespace rts
{

class FirstFreeScheduler final : public IDeviceScheduler
{
public:
    explicit FirstFreeScheduler(DevicesManager& devcies_mgr);

public: // public IDeviceScheduler
    [[nodiscard]]
    virtual ScheduledDevice get_target_device(
        const Task& task) override;

    virtual void release_device(
        DeviceId device_id,
        const Task& task) override;

    virtual void release_device(
        DeviceId device_id,
        const TaskArgument& var) override;

    virtual void release_device(DeviceId device_id) override;

private:
    void acquire_device(DeviceId dev_id);

private:
    DevicesManager& dev_mgr_;
    SpinLock devices_list_lock_;
    std::vector<std::size_t> device_id_to_free_memory_;
    std::vector<std::size_t> device_id_to_total_memory_;
};

} // namespace rts
