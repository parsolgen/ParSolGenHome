#pragma once

#include "IDeviceBuffer.h"
#include "Types.h"

#include "Task/Task.h"

#include <cstdint>
#include <memory>

namespace rts
{

struct IDeviceDriver
{
    virtual ~IDeviceDriver() = default;

    virtual IDeviceBufferPtr create_host_buffer(DeviceDataType dtp, std::size_t n) = 0;

    virtual IDeviceBufferPtr create_device_buffer(
        DeviceDataType dtp,
        std::size_t n) = 0;

    virtual IDeviceBufferPtr create_host_buffer(void* host_ptr,
        DeviceDataType dtp,
        std::size_t n) = 0;

    virtual void release(IDeviceBufferPtr&& buffer) = 0;

    virtual void host_to_device_sync(
        IDeviceBuffer& src_buffer) = 0;

    virtual IDeviceBufferPtr host_to_device_sync(
        const void* src,
        DeviceDataType dtp,
        std::size_t n) = 0;

    virtual void device_to_host(IDeviceBuffer& buffer, void* dst) = 0;

    [[nodiscard]]
    virtual std::size_t get_free_memory_size() = 0;

    virtual void execute_kernel(TaskOperation& op) = 0;

    [[nodiscard]]
    virtual DriverType get_type() const noexcept = 0;

    [[nodiscard]]
    virtual DeviceId get_id() const noexcept = 0;
};

using IDeviceDriverPtr = std::unique_ptr<IDeviceDriver>;

} // namespace rts
