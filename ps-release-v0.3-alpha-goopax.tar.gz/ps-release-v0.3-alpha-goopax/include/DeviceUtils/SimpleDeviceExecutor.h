#pragma once

#include "IDeviceExecutor.h"

namespace rts
{

class SimpleDeviceExecutor final : public IDeviceExecutor
{
public:
    explicit SimpleDeviceExecutor(TaskOperations ops);

public: // public IDeviceExecutor
    virtual void execute(
        Task& task,
        DeviceId device_id,
        DriverType driver_type,
        DevicesManager& device_mgr) override;

private:
    TaskOperations ops_;
};

} // namespace rts
