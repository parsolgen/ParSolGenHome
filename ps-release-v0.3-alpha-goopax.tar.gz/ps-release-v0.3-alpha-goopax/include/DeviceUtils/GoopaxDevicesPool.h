#pragma once

#include "IDevicesPool.h"

namespace rts
{

class GoopaxDevicesPool final : public IDevicesPool
{
public:  // public IDevicesPool
    virtual void init(DevicesManager& dev_mgr) override;
    [[nodiscard]]
    virtual std::size_t get_n_devices() const override;
};

} // namespace rts
