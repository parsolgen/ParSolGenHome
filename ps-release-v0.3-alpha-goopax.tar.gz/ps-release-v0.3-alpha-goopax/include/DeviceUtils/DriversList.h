#pragma once

#define GOOPAX_DRIVER 0
#define CUDA_DRIVER 1
#define OCL_DRIVER 2
#define HLS_DRIVER 3

#define N_DRIVERS 4
