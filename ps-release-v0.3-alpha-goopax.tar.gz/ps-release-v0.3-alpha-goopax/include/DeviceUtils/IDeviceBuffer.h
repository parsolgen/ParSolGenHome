#pragma once

#include "Fwd.h"

#include "Types.h"

#include <cstdint>
#include <memory>

namespace rts
{

struct IDeviceBufferVisitor
{
    virtual ~IDeviceBufferVisitor() = default;

    virtual void visit(GoopaxBuffer& buffer) = 0;
};

struct IDeviceBuffer 
{
    virtual ~IDeviceBuffer() = default;

    virtual void accept_visitor(IDeviceBufferVisitor& visitor) = 0;

    [[nodiscard]]
    virtual std::size_t byte_size() const = 0;
    
    [[nodiscard]]
    virtual std::size_t length() const = 0;

    virtual void init(DeviceDataType dtp, std::size_t n) = 0;

    [[nodiscard]]
    virtual DeviceDataType data_type() const = 0;

    virtual void copy_to_host_sync(void* dst) = 0;

    virtual void copy_to_device_sync(const void* src) = 0;
};

using IDeviceBufferPtr = std::unique_ptr<IDeviceBuffer>;

} // namespace rts
