#pragma once

#include "DeclareArray.h"
#include "TaskGraphProblem.h"
#include "TaskGraphProblemHolder.h"
#include "DeclareVector.h"
#include "Matrix.h"
#include "BlockCyclicTaskGraphDistributor.h"
#include "SparseDomainTaskGraphDistributor.h"
#include "ExplicitSolverTaskGraphDistributor.h"
#include "TaskGraphUtils.h"
#include "TaskGraphsController.h"
#include "Utils.h"

#include "Mpi/Mpi.h"
#include "Task/Task.h"
#include "ArrayHolders/CSRMatrixBlock.h"
#include "ArrayHolders/TmpContiguousArray.h"
#include "ArrayHolders/ContiguousArray.h"
#include "Executors/RightLookingExecutorInfo.h"
#include "Comm/Utils.h"
#include "TaskGraphDistributors/ExplicitSolverGraphDistributor.h"

#ifdef SG_USE_GOOPAX
#include "DeviceUtils/GoopaxBuffer.h"
#endif

#include "Algorithms/Max.h"
#include "VectorUtils/VectorUtils.h"

#ifdef SG_USE_ACCEL
#include "DeviceUtils/Types.h"
#include "DeviceUtils/Init.h"
#endif

#ifdef SG_USE_GOOPAX
#include <goopax>
#endif

namespace rts
{

class TaskGraph;

namespace comm
{

int get_comm_size(MPI_Comm comm);

} // namespace comm

namespace internal
{

void parse_command_line_args(int argc, char** argv);
void register_dd_array(ArrayKey id, std::size_t size);

using InternalTask = std::function<void(std::size_t)>;
void exec_thread_specific_task(std::size_t tid, InternalTask task);
std::size_t get_n_threads();
void exec_task(InternalTask t);

void exec_hp_task(InternalTask t);
void exec_thread_specific_hp_task(std::size_t tid, InternalTask task);

void exec_dev_task(InternalTask t, DeviceId dev_id);
void exec_dev_hp_task(InternalTask t, DeviceId dev_id);

void register_vec_holder(MemoryOwningVectorHolderD& v);
void register_vec_holder(MemoryOwningVectorHolderS& v);
void register_tg(std::size_t tgp_id, TaskGraph& local_graph);

void* get_ptr_by_arg(const TaskArgument& var);
void register_array_id(ArrayKey array_id, IVariableDataHolder* vh);
#ifdef SG_USE_ACCEL
DeviceDataType get_dev_dtp_by_array_id(ArrayKey array_id);
#endif
std::size_t get_el_len_by_arg(const TaskArgument& var);

} // namespace internal

void register_matrix(int rank, MPI_Comm comm, const BlockedCSRMatrixSI& m);
void register_matrix(int rank, MPI_Comm comm, const BlockedCSRMatrixDI& m);

bool is_zero(const BlockedCSRMatrixSI& m, const TaskArgument& arg);
bool is_zero(const BlockedCSRMatrixDI& m, const TaskArgument& arg);

std::vector<std::string> get_command_line_args();

bool is_array_element_local(const TaskArgument& el);

bool is_array_element_local(const TaskArgument& el, std::size_t tgp_id);

std::vector<comm::ProcessCoord> get_array_el_targets(const TaskArgument& var);

std::vector<comm::ProcessCoord> get_array_el_targets(
    const TaskArgument& var,
    comm::Communicator* comm);

void abort();
void abort(const std::string& message);

void init_thread_pool();

void stop_threads();

std::size_t declare_tgp(TaskGraphProblemHolder&& p);

bool is_tgp_already_declared(std::size_t id);

void reset_tgp(std::size_t id);

void reset_tgp_inside_iter_loop(std::size_t id);

void ref_tgp_in_var(std::size_t id, const TaskArgument& arg);

void ref_tgp_out_var(std::size_t id, const TaskArgument& arg);

void register_tgp(std::size_t id);

void exec_tgp_and_wait(std::size_t id);

bool is_tgp_first_iteration(std::size_t id);

void finish_tgp_first_iteration(std::size_t id);

void finalize();

ArrayDimensions<2> get_local_subarray_dims_01(
    const ArrayDimensions<2>& array_dims,
    const ArrayDimensions<2>& area_dist);

ArrayElementCoordinates<2> get_local_subarray_coords_01(
    const ArrayDimensions<2>& area_dims,
    const comm::ProcessCoordinates<2>& cart_coords,
    const comm::ProcessCoordinates<2>& cart_size);

enum class TGRedistributionStrategy
{
    ByInputs,
    ByOuputs
};

void redistribute_array_sync(
    ArrayKey actual_array_id,
    ArrayKey connected_array_id,
    std::size_t tgp_id,
    TGRedistributionStrategy strategy);

void redistribute_array(ArrayKey array_id, const ArrayDimSize len);

#ifndef NDEBUG
void print_vector(const MemoryOwningVectorHolderD& vec);
void print_vector(const MemoryOwningVectorHolderS& vec);
#endif

void init_arrays_storage(ArrayKey max_n_arrays);

void init_arrays_storage(ArrayKey max_n_arrays, int ndims);

void init(ArrayKey n_arrays, int argc, char** argv);

namespace impl
{

void init_reduction_tmp_arrays_storage();

} // namespace impl

double reduce_array_2_2(
    const NonUpdatableGeneralArrayHolderD& array,
    ElementVersion version,
    MPI_Op op,
    int np,
    MPI_Comm comm);

float reduce_array_2_2(
    const NonUpdatableGeneralArrayHolderS& array,
    ElementVersion version,
    MPI_Op op,
    int np,
    MPI_Comm comm);

#ifdef SG_USE_GOOPAX
template<typename T>
goopax::buffer<T> get_goopax_buffer(const TaskArgument& var)
{
    auto* buffer = get_dev_buffer_by_var(var);
    assert(buffer != nullptr);
    assert(dynamic_cast<GoopaxBuffer*>(buffer) != nullptr);
    return static_cast<GoopaxBuffer*>(buffer)->get<T>();
}

goopax::goopax_device get_goopax_device_by_task(const Task& task);
#endif

} // namespace rts
