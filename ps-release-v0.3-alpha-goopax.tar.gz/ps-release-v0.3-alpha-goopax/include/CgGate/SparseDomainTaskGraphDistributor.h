#pragma once

#include "TaskGraphDistributors/Types.h"

namespace rts
{

class TaskGraph;

struct SparseDomainTaskGraphDistributor final
{
    TaskGraphDistribution operator()(
        const TaskGraph& task_graph,
        int np) const;
};

} // namespace rts
