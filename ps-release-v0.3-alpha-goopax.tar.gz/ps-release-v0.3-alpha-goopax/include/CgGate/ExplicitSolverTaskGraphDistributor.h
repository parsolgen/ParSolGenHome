#pragma once

#include "Mpi/Mpi.h"
#include "TaskGraphDistributors/Types.h"

namespace rts
{

class TaskGraph;

class ExplicitSolverTaskGraphDistributor final
{
public:
    ExplicitSolverTaskGraphDistributor(
        int ncart_dims,
        ArrayDimensions<2> area_dims,
        comm::ProcessCoordinates<2> proc_cart_dims,
        MPI_Comm comm);

    TaskGraphDistribution operator()(
        const TaskGraph& task_graph,
        int np) const;

private:
    int ncart_dims_;
    ArrayDimensions<2> area_dims_;
    comm::ProcessCoordinates<2> proc_cart_dims_;
    MPI_Comm comm_;
};

} // namespace rts
