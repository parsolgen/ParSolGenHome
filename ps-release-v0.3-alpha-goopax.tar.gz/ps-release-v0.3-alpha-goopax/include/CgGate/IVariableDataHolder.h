#pragma once

#include "Array.h"

#include "Task/Task.h"
#include "Comm/Communicator.h"

#ifdef SG_USE_ACCEL
#include "DeviceUtils/Types.h"
#endif

namespace rts
{

struct IVariableDataHolder
{
    virtual ~IVariableDataHolder() = default;

    virtual comm::SerializedMPIDataType recv_message_type(
        std::uint8_t* data,
        std::size_t byte_size) = 0;
    virtual TaskArgument insert_received_block(
        ArrayKey key,
        std::unique_ptr<std::uint8_t[]>&& block_mem) = 0;
    virtual comm::SerializedMPIDataType send_message_type(
        const TaskArgument& arg) = 0;
    [[nodiscard]]
    virtual void* get_ptr(const TaskArgument& var) = 0;
    [[nodiscard]]
    virtual void* get_ptr(const TaskArgument& var) const = 0;
    [[nodiscard]]
    virtual ArrayKey get_id() const = 0;
    [[nodiscard]]
    virtual std::size_t get_len(const TaskArgument& var) const = 0;
#ifdef SG_USE_ACCEL
    [[nodiscard]]
    virtual DeviceDataType get_dev_dtp() const noexcept = 0;
#endif
};

template<typename T>
class VariableDataHolderImpl final : public IVariableDataHolder
{
public:
    explicit VariableDataHolderImpl(T& holder)
        : data_holder_{holder}
    {
#ifdef SG_USE_ACCEL
        dev_dtp_ = cpp_type_to_device_dtp_v<typename T::element_t>;
#endif
    }

public: // IVariableDataHolder
    virtual comm::SerializedMPIDataType recv_message_type(
        std::uint8_t* data,
        std::size_t byte_size) override
    {
        return data_holder_.GetMpiTypeForReceivingBlock(data, byte_size);
    }

    virtual TaskArgument insert_received_block(
        ArrayKey key,
        std::unique_ptr<std::uint8_t[]>&& block_mem) override
    {
        return data_holder_.InsertReceivedBlock(key, std::move(block_mem));
    }

    virtual ArrayKey get_id() const override
    {
        return data_holder_.GetKey();
    }

    virtual comm::SerializedMPIDataType send_message_type(
        const TaskArgument& arg) override
    {
        return data_holder_.GetMpiTypeForSendingBlock(arg);
    }

    [[nodiscard]]
    virtual void* get_ptr(const TaskArgument& var) override
    {
        if constexpr (std::is_same_v<T, ExternalOutNonUpdatableGeneralArrayHolderD>
            || std::is_same_v<T, ExternalOutNonUpdatableGeneralArrayHolderS>
            || std::is_same_v<T, BlockedCSRMatrixDI>
            || std::is_same_v<T, BlockedCSRMatrixSI>)
        {
            assert(false);
            return nullptr;
        }
        else {
            return data_holder_.GetPtr(var);
        }
    }

    [[nodiscard]]
    virtual void* get_ptr(const TaskArgument& var) const override
    {
        if constexpr (std::is_same_v<T, ExternalOutNonUpdatableGeneralArrayHolderD>
            || std::is_same_v<T, ExternalOutNonUpdatableGeneralArrayHolderS>
            || std::is_same_v<T, BlockedCSRMatrixDI>
            || std::is_same_v<T, BlockedCSRMatrixSI>)
        {
            assert(false);
            return nullptr;
        }
        else {
            return data_holder_.GetPtr(var);
        }
    }

#ifdef SG_USE_ACCEL
    [[nodiscard]]
    virtual DeviceDataType get_dev_dtp() const noexcept override
    {
        return dev_dtp_;
    }
#endif

    [[nodiscard]]
    virtual std::size_t get_len(const TaskArgument& var) const override
    {
        return data_holder_.GetLen(var);
    }

private:
    T& data_holder_;
#ifdef SG_USE_ACCEL
    DeviceDataType dev_dtp_;
#endif
};

using IVariableDataHolderPtr = std::unique_ptr<IVariableDataHolder>;

template<typename T>
IVariableDataHolderPtr make_var_holder(T& vh)
{
    return std::make_unique<VariableDataHolderImpl<T>>(vh);
}

} // namespace rts
