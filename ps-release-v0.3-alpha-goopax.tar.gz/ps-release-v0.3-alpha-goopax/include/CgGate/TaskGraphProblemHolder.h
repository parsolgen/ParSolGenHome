#pragma once

#include "TaskGraphProblem.h"

namespace rts
{

class TaskGraphProblemHolder final
{
public:
    void reset();
    void reset_inside_iter_loop();
    void execute_and_wait();
    void stop();

    void ref_in_var(const TaskArgument& arg);

    void ref_out_var(const TaskArgument& arg);

    void broadcast_matrices_root();

    void set_ready_var(const TaskArgument& arg);

    [[nodiscard]]
    bool is_first_iteration() const noexcept
    {
        assert(task_graph_problem_or_null_ != nullptr);
        return task_graph_problem_or_null_->is_first_iteration();
    }

    void finish_first_iteration() noexcept
    {
        assert(task_graph_problem_or_null_ != nullptr);
        task_graph_problem_or_null_->finish_first_iteration();
    }

    [[nodiscard]]
    TaskGraphProblem* get_prob_ptr() noexcept;

    [[nodiscard]]
    const TaskGraphProblem* get_prob_ptr() const noexcept;

    template<typename F>
    void initialize(F&& initializer)
    {
        if (task_graph_problem_or_null_ == nullptr) {
            task_graph_problem_or_null_ = initializer();
        }
    }

private:
    std::unique_ptr<TaskGraphProblem> task_graph_problem_or_null_ = nullptr;
};

} // namespace rts
