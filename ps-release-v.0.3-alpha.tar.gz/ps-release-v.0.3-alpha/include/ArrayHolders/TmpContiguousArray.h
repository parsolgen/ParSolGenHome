#pragma once

#include "Task/Task.h"

#include "Comm/ComplexTypeConstructor.h"

#include "Utils/HashCombine.h"

#include <list>
#include <vector>
#include <unordered_map>
#include <memory>

namespace rts
{

template<typename T>
class TmpContiguousArray final
{
public:
    TmpContiguousArray(
        std::size_t init_n_instances,
        ArrayElementCoord n);

public:
    void allocate(const TaskArgument& arg);

    T* GetPtr(const TaskArgument& arg);

    const T* GetPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(
        const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(
        ArrayKey id,
        std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg);

    void free(const TaskArgument& arg);

private:
    static constexpr const std::size_t grow_factor = 2;
    static constexpr const std::size_t default_list_entry_len = 100;

#pragma pack(push, 1)
    struct Header final
    {
        ArrayKey array_id;
        ElementVersion version;
    };
#pragma pack(pop)

    static constexpr const std::size_t header_size = sizeof(Header);

    struct BlockKey final
    {
        ArrayKey array_id;
        ElementVersion version;

        bool operator==(const BlockKey& rhs) const noexcept;

        BlockKey() = delete;
    };

    struct BlockKeyHash final
    {
        std::size_t operator()(const BlockKey& key) const noexcept
        {
            std::size_t seed = 0;
            utils::hash_combine(seed, key.array_id);
            utils::hash_combine(seed, key.version);
            return seed;
        }
    };

    using DataBlockPtr = std::unique_ptr<std::uint8_t[]>;

private:
    std::size_t block_len_;
    std::size_t block_size_;
    std::list<DataBlockPtr> free_blocks_;
    std::unordered_map<BlockKey, DataBlockPtr, BlockKeyHash> block_key_to_block_ptr_;
    const std::size_t padding_size_ = header_size % sizeof(T);
    const std::size_t data_offset_ = header_size + padding_size_;
};

} // namespace rts

#include "TmpContiguousArray.inl"
