#pragma once

#include "Task/Task.h"

namespace rts
{

using OnReadyTask = std::function<void(Task& task)>;

struct IExecutor
{
    virtual ~IExecutor() = default;

    virtual void wait() = 0;

    virtual void ready_var(const TaskArgument& var) = 0;

    virtual void start() = 0;

    virtual void set_ready_task_handler(OnReadyTask handler) = 0;

    virtual void ready_task(Task& task) = 0;

    virtual void stop() = 0;

    virtual void reset() = 0;
};

} // namespace rts
