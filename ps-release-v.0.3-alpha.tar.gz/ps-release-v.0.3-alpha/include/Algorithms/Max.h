#pragma once

namespace rts
{
namespace algo
{

template<typename T, typename... Ts>
T max(const Ts&... args);

} // namespace algo
} // namespace rts

#include "Max.inl"
