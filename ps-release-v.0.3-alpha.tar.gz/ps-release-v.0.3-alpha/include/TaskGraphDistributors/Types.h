#pragma once

#include "Comm/Types.h"
#include "Task/Task.h"

#include <unordered_map>

namespace rts {

using ProcessCoordsVector = std::vector<comm::ProcessCoord>;

using TaskGraphDistribution = std::unordered_map<TaskArgument, ProcessCoordsVector>;

} // namespace rts