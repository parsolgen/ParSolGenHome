#pragma once

#include "Types.h"
#include "Variable.h"
#include "XContainer.h"

#ifdef SG_USE_ACCEL
#include "DeviceUtils/Types.h"
#endif

#include "Utils/HashCombine.h"

#include <functional>
#include <optional>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>
#include <limits>

namespace rts {

struct TaskArgument final {
  std::uint16_t n = 0;
  bool array = false;
  ArrayKey array_or_var;
  ElementVersion version;
  ArrayElementCoordinates<2> coords_or_none;
  DeviceId deviceId = 0; // cpu

  TaskArgument() = default;

  TaskArgument(ArrayKey in_array_or_var, ElementVersion in_version, ArrayElementCoordinates<2> in_coords_or_none);

  TaskArgument(ArrayKey in_array_or_var, ElementVersion in_version);

  TaskArgument(ArrayKey in_array_or_var, ElementVersion in_version, ArrayElementCoord coord);
};

struct ArrayElementNoVersion final {
  std::uint16_t n;
  ArrayKey array_id;
  ArrayElementCoordinates<2> coords;

  ArrayElementNoVersion(ArrayKey in_array_id, ArrayElementCoord in_coord);
  ArrayElementNoVersion(ArrayKey in_array_id, ArrayElementCoordinates<2> in_coords);
};

bool operator==(const ArrayElementNoVersion& lhs, const ArrayElementNoVersion& rhs);

ArrayElementNoVersion to_array_element_descriptor(const TaskArgument& var);

using TaskArgumentsVector = std::vector<TaskArgument>;

bool operator==(const TaskArgument& lhs, const TaskArgument& rhs);

using TaskArgumentsMap = std::unordered_map<TaskArgument, std::size_t>;

static constexpr const ElementVersion LatestVersion = 2147483647;

#ifndef NDEBUG
std::string to_string(const TaskArgument& arg);
#endif

} // namespace rts

namespace std {

template <>
struct hash<rts::TaskArgument> {
  size_t operator()(const rts::TaskArgument& arg) const {
    std::size_t result = 0;
    utils::hash_combine(result, arg.array);
    utils::hash_combine(result, arg.array_or_var);
    utils::hash_combine(result, arg.n);
    utils::hash_combine(result, arg.version);
    if (arg.n > 0) {
      utils::hash_combine(result, arg.coords_or_none[0]);
    }
    if (arg.n > 1) {
      utils::hash_combine(result, arg.coords_or_none[1]);
    }
    return result;
  }
};

template<>
struct hash<rts::ArrayElementNoVersion> {
  size_t operator()(const rts::ArrayElementNoVersion& var) const {
    size_t result = 0;
    utils::hash_combine(result, var.n);
    utils::hash_combine(result, var.array_id);
    utils::hash_combine(result, var.coords[0]);
    utils::hash_combine(result, var.coords[1]);
    return result;
  }
};

} // namespace std

namespace rts {

struct Task;

using TaskOperation = std::function<void(Task&)>;

using TaskOperations = std::vector<TaskOperation>;

struct Task final {
  TaskId idx_ = 0;
  TaskId op_id;
  TaskArgumentsVector inputs;
  TaskArgumentsVector outputs;
  TaskArgumentsMap inputs_index;
  XContainer xdata;
  std::string debug_string;
  std::size_t n_inputs_to_wait_ = 0;
#ifdef SG_USE_GOOPAX
  bool goopax_supprot_ = false;
#endif
  bool cpu_support_ = false;

  Task(TaskId in_id, TaskArgumentsVector in_inputs, TaskArgumentsVector in_outputs);
  Task(TaskId in_id, TaskArgumentsVector in_inputs, TaskArgumentsVector in_outputs, std::string in_str);
};

TaskArgument get_target_task_arg(const Task& task);

using TaskOrNone = std::optional<Task>;

} // namespace rts

#include "Task.inl"
