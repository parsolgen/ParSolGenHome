#pragma once

#include "ArrayHolders/ContiguousArray.h"
#include "Mpi/Mpi.h"
#include "Task/TaskGraph.h"

namespace rts
{

template<typename T, rts::ArrayDim ReductionDim>
rts::TaskOperation get_reduction_barrier_op(
    const rts::ContiguousArray<2, T>& array,
    const rts::ArrayDimensions<2>& local_subarray_dims,
    rts::ArrayElementCoord second_dim_i,
    MPI_Op mpi_op,
    rts::ContiguousArray<1, T>& result,
    MPI_Comm comm);

template<rts::ArrayDim ReductionDim>
void insert_reduction_barrier_task(
    rts::TaskGraph& task_graph,
    rts::ArrayDimSize dim_size,
    rts::ArrayElementCoord second_dim_i,
    rts::ArrayKey tmp_array_id,
    rts::TaskId barrier_op_id);

template<typename T>
rts::TaskOperation get_reduction_barrier_op(
    const rts::ContiguousArray<1, T>& array,
    const rts::ArrayDimensions<2>& local_subarray_dims,
    MPI_Op mpi_op,
    T& result,
    MPI_Comm comm);

void insert_reduction_barrier_task(
    rts::TaskGraph& task_graph,
    rts::ArrayDimSize dim_size,
    rts::ArrayKey tmp_array_id,
    rts::TaskId barrier_op_id);

} // namespace rts

#include "Reduction.inl"
