#pragma once

#include "Matrix.h"
#include "Types.h"

#include "IVariableDataHolder.h"
#include "TaskGraphDistributors/Types.h"
#include "Mpi/Mpi.h"
#include "Utils/MakeWithCapacity.h"
#include "Utils/ForEach.h"

#include "Executors/IExecutor.h"

#include <optional>
#include <unordered_set>

namespace rts
{
namespace impl
{

template<typename T>
struct is_matrix final : std::false_type {};

template<>
struct is_matrix<BlockedCSRMatrixSI> final
    : std::true_type {};

template<>
struct is_matrix<BlockedCSRMatrixDI> final
    : std::true_type {};

template<typename... Vs>
std::unordered_set<ArrayKey> build_matrices_set(const Vs&... vars)
{
    auto result = utils::MakeWithCapacity<std::unordered_set<ArrayKey>>(
        sizeof...(vars));
    utils::for_each([&result](const auto& var) {
        using T = std::decay_t<decltype(var)>;
        if constexpr (is_matrix<T>::value) {
            result.emplace(var.GetKey());
        }
    }, vars...);
    return result;
}

template<typename... Vs>
std::size_t get_var_holders_vector_size(const Vs&... vars)
{
    ArrayKey result = 0;
    utils::for_each([&result](const auto& holder) {
        result = std::max(result, holder.GetKey());
    }, vars...);
    return utils::cast_to_size(result) + 1;
}

} // namesapce impl

class RightLookingExecutor;
class TaskGraph;

namespace comm
{
class Communicator;
} // namespace comm


class TaskGraphProblem final
{
public:
    enum class ProblemClass
    {
        SLARelated,
        DLArelated,
        ESSRelated
    };

public:
    ~TaskGraphProblem();

    TaskGraphProblem(const TaskGraphProblem&) = default;
    TaskGraphProblem(TaskGraphProblem&&) = default;
    TaskGraphProblem& operator=(const TaskGraphProblem&) = default;
    TaskGraphProblem& operator=(TaskGraphProblem&&) = default;

    void start();

    void stop();

    void reset();

    void reset_inside_iter_loop();

    void execute_and_wait();

    void distribute_matrices_root();

    void set_ready_var(const TaskArgument& arg);

    void ref_in_var(const TaskArgument& arg);

    void ref_out_var(const TaskArgument& arg);

    [[nodiscard]]
    inline
    const TaskGraphDistribution& get_distribution() const noexcept
    {
        return distr_;
    }

    [[nodiscard]]
    inline
    const UniqueDistribution get_desired_inputs_distribuion() const noexcept
    {
        return desired_inputs_distr_;
    }

    [[nodiscard]]
    inline
    const TaskGraph& get_graph() const noexcept
    {
        assert(task_graph_or_null_ != nullptr);
        return *task_graph_or_null_;
    }

    [[nodiscard]]
    inline
    const comm::Communicator& get_comm() const noexcept
    {
        assert(comm_ != nullptr);
        return *comm_;
    }

    [[nodiscard]]
    inline
    comm::Communicator& get_comm() noexcept
    {
        assert(comm_ != nullptr);
        return *comm_;
    }

    [[nodiscard]]
    inline
    const NonVersionizedDistributioon& get_non_versioned_distribution() const noexcept
    {
        return non_versioned_distr_;
    }

    [[nodiscard]]
    bool is_first_iteration() const noexcept
    {
        return first_iter_;
    }

    void finish_first_iteration() noexcept
    {
        first_iter_ = false;
    }

private:
    void init_master_proc(const Distributor& task_graph_distributor);

    void init_slave_proc(int rank);

    [[nodiscard]]
    bool is_array_element_local(const TaskArgument& var) const;

    void distribute_inputs_before_exec();

    void send_output_after_exec(const TaskArgument& arg);

    void build_desired_inputs_distr();

    void build_non_versioned_distr();

public:
    TaskGraphProblem(
        TaskOperations ops,
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        std::unordered_set<ArrayKey> matrices_set,
        std::vector<IVariableDataHolderPtr> var_holders_vec,
        MPI_Comm mpi_comm);

    TaskGraphProblem(
        ProblemClass problem_class,
        TaskOperations ops,
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        std::unordered_set<ArrayKey> matrices_set,
        std::vector<IVariableDataHolderPtr> var_holders_vec,
        MPI_Comm mpi_comm);

    TaskGraphProblem(
        ProblemClass problem_class,
        ArrayElementCoordinates<2> local_subdomain_coords,
        ArrayDimensions<2> local_subdomain_size,
        TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        std::unordered_set<ArrayKey> matrices_set,
        std::vector<IVariableDataHolderPtr> var_holders_vec,
        MPI_Comm mpi_comm);

private:
    static std::unique_ptr<TaskGraphProblem> create(
        ProblemClass problem_class,
        TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        std::unordered_set<ArrayKey> matrices_set,
        std::vector<IVariableDataHolderPtr> var_holders_vec,
        MPI_Comm mpi_comm);

    static std::unique_ptr<TaskGraphProblem> create(
        ProblemClass problem_class,
        ArrayElementCoordinates<2> local_subdomain_coords,
        ArrayDimensions<2> local_subdomain_size,
        TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        std::unordered_set<ArrayKey> matrices_set,
        std::vector<IVariableDataHolderPtr> var_holders_vec,
        MPI_Comm mpi_comm);

    template<typename... Vs>
    friend std::unique_ptr<TaskGraphProblem> create_tg_problem(
        TaskGraphProblem::ProblemClass problem_class,
        TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        MPI_Comm mpi_comm,
        Vs&... vars);

    template<typename... Vs>
    friend std::vector<IVariableDataHolderPtr> build_vec_holders(
        Vs&... vars);

    template<typename... Vs>
    friend std::unique_ptr<TaskGraphProblem> create_tg_problem(
        TaskGraphProblem::ProblemClass problem_class,
        ArrayElementCoordinates<2> local_subdomain_coords,
        ArrayDimensions<2> local_subdomain_size,
        TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
        TaskGraph* task_graph_or_null,
        std::size_t nthreads,
        int np,
        const Distributor& distributor,
        MPI_Comm mpi_comm,
        Vs&... vars);

private:
    void ctor_init(std::size_t nthreads);

    IVariableDataHolderPtr& get_array_holder(ArrayKey array_id);

    [[nodiscard]]
    inline
    bool is_array_redistributable(ArrayKey id) const noexcept
    {
        return non_redistributable_arrays_.find(id) == non_redistributable_arrays_.end()
            && matrices_set_.find(id) == matrices_set_.end();
    }

    [[nodiscard]]
    inline
    bool is_sp_mat_var(const TaskArgument& arg) const noexcept
    {
        return matrices_set_.find(arg.array_or_var) != matrices_set_.end();
    }

private:
    ProblemClass problem_class_ = ProblemClass::SLARelated;
    ArrayElementCoordinates<2> local_subdomain_coords_;
    ArrayDimensions<2> local_subdomain_size_;
    TaskOperations ops_;
#ifdef SG_USE_GOOPAX
    TaskOperations goopax_ops_;
#endif
#ifdef SG_USE_CUDA
    TaskOperations cuda_ops_;
#endif
    TaskGraphPtr task_graph_or_null_;
    int np_;
    MPI_Comm mpi_comm_;
    TaskGraphPtr local_task_graph_;
    std::unique_ptr<comm::Communicator> comm_;
    std::unique_ptr<IExecutor> executor_;
    std::size_t n_messages_to_receive_;
    std::size_t n_messages_to_receive_no_mtcs_;
    TaskGraphDistribution distr_;
    std::unordered_set<ArrayKey> matrices_set_;
    std::vector<IVariableDataHolderPtr> var_data_holders_;
    std::vector<TaskArgument> sp_mat_args_;
    int rank_ = 0;
    std::unordered_set<TaskArgument> ready_vars_;
    std::unordered_set<TaskArgument> referenced_out_vars_;
    UniqueDistribution desired_inputs_distr_;
    std::unordered_set<TaskArgument> graph_outputs_set_;
    bool inside_iter_loop_ = false;
    std::unordered_set<ArrayKey> non_redistributable_arrays_;
    NonVersionizedDistributioon non_versioned_distr_;
    bool first_iter_ = true;
};

template<typename... Vs>
std::vector<IVariableDataHolderPtr> build_vec_holders(
    Vs&... vars)
{
    std::vector<IVariableDataHolderPtr> var_data_holders;
    var_data_holders.resize(impl::get_var_holders_vector_size(
        std::forward<Vs>(vars)...));
    utils::for_each([&var_data_holders](auto&& var_holder) {
        using T = std::decay_t<decltype(var_holder)>;
        const auto id = var_holder.GetKey();
        assert(id < var_data_holders.size());
        if constexpr (impl::is_matrix<T>::value) {
            for (int i = 0; i < var_holder.nb(); ++i) {
                for (int j = 0; j < var_holder.nb(); ++j) {
                    rts::TaskArgument arg{var_holder.GetKey(), 0, ArrayElementCoordinates<2>{
                        utils::cast_to_size(i), utils::cast_to_size(j)}};
                }
            }
        }
        var_data_holders[id] = std::make_unique<VariableDataHolderImpl<T>>(
            var_holder);
    }, vars...);
    return var_data_holders;
}

template<typename... Vs>
std::unique_ptr<TaskGraphProblem> create_tg_problem(
    TaskGraphProblem::ProblemClass problem_class,
    TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
    TaskGraph* task_graph_or_null,
    std::size_t nthreads,
    int np,
    const Distributor& distributor,
    MPI_Comm mpi_comm,
    Vs&... vars)
{
    auto matrices_set = impl::build_matrices_set(vars...);
    auto var_data_holders = build_vec_holders(vars...);

    return TaskGraphProblem::create(
        problem_class,
        std::move(ops),
#ifdef SG_USE_GOOPAX
        std::move(goopax_ops),
#endif
#ifdef SG_USE_CUDA
        std::move(cuda_ops),
#endif
        task_graph_or_null,
        nthreads,
        np,
        distributor,
        std::move(matrices_set),
        std::move(var_data_holders),
        mpi_comm);
}

template<typename... Vs>
std::unique_ptr<TaskGraphProblem> create_tg_problem(
    TaskGraphProblem::ProblemClass problem_class,
    ArrayElementCoordinates<2> local_subdomain_coords,
    ArrayDimensions<2> local_subdomain_size,
    TaskOperations ops,
#ifdef SG_USE_GOOPAX
        TaskOperations goopax_ops,
#endif
#ifdef SG_USE_CUDA
        TaskOperations cuda_ops,
#endif
    TaskGraph* task_graph_or_null,
    std::size_t nthreads,
    int np,
    const Distributor& distributor,
    MPI_Comm mpi_comm,
    Vs&... vars)
{
    auto matrices_set = impl::build_matrices_set(vars...);
    auto var_data_holders = build_vec_holders(vars...);

    return TaskGraphProblem::create(
        problem_class,
        std::move(local_subdomain_coords),
        std::move(local_subdomain_size),
        std::move(ops),
#ifdef SG_USE_GOOPAX
        std::move(goopax_ops),
#endif
#ifdef SG_USE_CUDA
        std::move(cuda_ops),
#endif
        task_graph_or_null,
        nthreads,
        np,
        distributor,
        std::move(matrices_set),
        std::move(var_data_holders),
        mpi_comm);
}

} // namespace rts
