#pragma once

#include "Task/Task.h"

namespace rts
{
namespace impl
{

class TmpArrayIdsStorage final
{
public:
    template<typename T>
    ArrayKey generate_tmp_var_id(const T& array_holder, int i0, int i1);

private:
    struct Key final
    {
        ArrayKey array_id;
        int i0;
        int i1;

        bool operator==(const Key& rhs) const noexcept;

        Key() = delete;
    };

    struct KeyHash final
    {
        std::size_t operator()(Key el) const noexcept;
    };

    std::unordered_map<Key, ArrayKey, KeyHash> ids_storage_; 
};

TmpArrayIdsStorage& get_tmp_array_ids_storage();

} // namespace impl

template<typename T>
std::size_t get_element_len(
    const T& array,
    ElementVersion ver,
    ArrayElementCoord coord);

TaskId genereate_op_id();

template<typename T, typename... Indices>
ArrayKey generate_tmp_var_id(const T& array_holder, Indices... indices);

std::size_t get_default_nthreads();

void reset_task_op_id();

} // namespace rts

#include "Utils.inl"
