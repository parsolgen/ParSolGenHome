#pragma once

#include "ArrayHolders/CSRMatrixBlock.h"

#include "Comm/ComplexTypeConstructor.h"
#include "Comm/Types.h"
#include "Task/Task.h"

namespace rts
{

namespace impl
{
struct IExternalOutputArrayPtr;
} // namespace impl

class ExternalOutputArrayPtrD final
{
public:
    explicit ExternalOutputArrayPtrD(
        std::unique_ptr<impl::IExternalOutputArrayPtr>&& impl);

    double* get() noexcept;

    ~ExternalOutputArrayPtrD();

private:
    std::unique_ptr<impl::IExternalOutputArrayPtr> impl_;
};

class ExternalOutputArrayPtrS final
{
public:
    explicit ExternalOutputArrayPtrS(
        std::unique_ptr<impl::IExternalOutputArrayPtr>&& impl);

    float* get() noexcept;

    ~ExternalOutputArrayPtrS();

private:
    std::unique_ptr<impl::IExternalOutputArrayPtr> impl_;
};

class NonUpdatableGeneralArrayHolderS final
{
public:
    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    ~NonUpdatableGeneralArrayHolderS();

    using element_t = float;

public:
    float* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const float* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const float* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    float* GetLatestElementPtr(const TaskArgument& arg);

    const float* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class NonUpdatableGeneralArrayHolderD final
{
public:
    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<1>& global_array_dims,
        ArrayDimensions<1> local_subarray_dims,
        ArrayElementCoordinates<1> local_subarray_coords,
        const ArrayDimensions<2>& block_size,
        const ArrayDimensions<2>& last_block_size);

    NonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ElementVersion nversions,
        const ArrayDimensions<2>& global_array_dims,
        ArrayDimensions<2> local_subarray_dims,
        ArrayElementCoordinates<2> local_subarray_coords,
        const ArrayDimensions<1>& block_size,
        const ArrayDimensions<1>& last_block_size);

    ~NonUpdatableGeneralArrayHolderD();

    using element_t = double;

public:
    double* GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const double* GetPtr(const TaskArgument& arg) const;
    [[nodiscard]]
    const double* GetInPtr(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    double* GetLatestElementPtr(const TaskArgument& arg);

    const double* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

private:
    ArrayDim n_;
    ArrayDim bn_;
    void* impl_;
};

class ExternalOutNonUpdatableGeneralArrayHolderS final
{
public:
    ExternalOutNonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ArrayDimensions<1> block_size,
        ArrayDimensions<1> last_block_size,
        std::string connection_string);

    ExternalOutNonUpdatableGeneralArrayHolderS(
        ArrayKey array_id,
        ArrayDimensions<2> block_size,
        ArrayDimensions<2> last_block_size,
        std::string connection_string);

    ~ExternalOutNonUpdatableGeneralArrayHolderS();

    using element_t = float;

public:
    ExternalOutputArrayPtrS GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const float* GetPtr(const TaskArgument& arg) const;

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    ExternalOutputArrayPtrS GetLatestElementPtr(const TaskArgument& arg);

    const float* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

private:
    ArrayDim bn_;
    void* impl_;
};

class ExternalOutNonUpdatableGeneralArrayHolderD final
{
public:
    ExternalOutNonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ArrayDimensions<1> block_size,
        ArrayDimensions<1> last_block_size,
        std::string connection_string);

    ExternalOutNonUpdatableGeneralArrayHolderD(
        ArrayKey array_id,
        ArrayDimensions<2> block_size,
        ArrayDimensions<2> last_block_size,
        std::string connection_string);

    ~ExternalOutNonUpdatableGeneralArrayHolderD();

    using element_t = float;

public:
    ExternalOutputArrayPtrD GetPtr(const TaskArgument& arg);

    [[nodiscard]]
    const double* GetPtr(const TaskArgument& arg) const;

    ArrayKey GetKey() const;

    std::size_t GetLen(const TaskArgument& var) const;

    ExternalOutputArrayPtrD GetLatestElementPtr(const TaskArgument& arg);

    const double* GetLatestElementPtr(const TaskArgument& arg) const;

    bool isLocal(const TaskArgument& arg) const;

    comm::SerializedMPIDataType GetMpiTypeForReceivingBlock(
        std::uint8_t* data,
        std::size_t byte_size);

    comm::SerializedMPIDataType GetMpiTypeForSendingBlock(const TaskArgument& arg);

    TaskArgument InsertReceivedBlock(ArrayKey key, std::unique_ptr<std::uint8_t[]>&& block_mem);

private:
    ArrayDim bn_;
    void* impl_;
};

} // namespace rts
