#pragma once

#include "Comm/Types.h"
#include "TaskGraphDistributors/Types.h"
#include "Task/Task.h"

#include <memory>
#include <functional>
#include <unordered_set>
#include <unordered_map>

namespace rts
{

class TaskGraph;

using TaskGraphPtr = std::unique_ptr<TaskGraph>;
using Distributor = std::function<TaskGraphDistribution(const TaskGraph&, int np)>;

using UniqueDistribution = std::unordered_map<TaskArgument, std::unordered_set<comm::ProcessCoord>>;
using NonVersionizedDistributioon = std::unordered_map<ArrayElementNoVersion, std::unordered_set<comm::ProcessCoord>>;

} // namespace rts
