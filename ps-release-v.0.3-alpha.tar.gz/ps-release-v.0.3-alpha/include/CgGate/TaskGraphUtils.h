#pragma once

#include "Task/Task.h"

#include <functional>
#include <memory>

namespace rts
{

class TaskGraph;
using TaskGraphPtr = std::unique_ptr<TaskGraph>;

TaskGraph* declare_task_graph(std::size_t n_arrays,  ArrayElementCoord nx, ArrayElementCoord ny);
TaskGraph* declare_task_graph();
void insert_task(TaskGraph* graph, Task task);
void init_task_graph(TaskGraph* graph);

} // namespace rts
