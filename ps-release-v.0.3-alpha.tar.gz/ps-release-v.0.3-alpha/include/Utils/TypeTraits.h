#pragma once

#include <type_traits>
#include <memory>
#include <variant>

namespace utils
{

template<typename T>
struct remove_cvref final {
    using type = std::remove_cv_t<std::remove_reference_t<T>>;
};

template<typename T>
struct remove_cvrefptr final {
    using type = std::remove_pointer_t<typename remove_cvref<T>::type>;
};

template<typename T>
using remove_cvref_t = typename remove_cvref<T>::type;

template<typename T>
using remove_cvrefptr_t = typename remove_cvrefptr<T>::type;

template<typename T>
struct is_shared_ptr : std::false_type {};

template<typename T>
struct is_shared_ptr<std::shared_ptr<T>> : std::true_type {};

template<typename T>
inline constexpr bool is_shared_ptr_v = is_shared_ptr<T>::value;

namespace detail {

template<typename T, typename ListHead, typename... List>
struct is_type_contained_inside_list final {
    static constexpr const bool value = std::is_same_v<T, ListHead> ? true : is_type_contained_inside_list<T, List...>::value;
};

template<typename T, typename List>
struct is_type_contained_inside_list<T, List> final {
    static constexpr const bool value = std::is_same_v<T, List>;
};

} // namespace detail

template<typename T, typename... List>
struct is_type_contained_inside_list final {
    static constexpr const bool value = detail::is_type_contained_inside_list<T, List...>::value;
};

template<typename T, typename... List>
inline constexpr bool is_type_contained_inside_list_v = is_type_contained_inside_list<T, List...>::value;


namespace detail {

template<typename T, int I, typename ListHead, typename... List>
struct idx_in_list final {
    static constexpr const int value = std::is_same_v<T, ListHead> ? I : idx_in_list<T, I + 1, List...>::value;
};

template<typename T, int I, typename List>
struct idx_in_list<T, I, List> final {
    static constexpr const int value = std::is_same_v<T, List> ? I : -1;
};

template<typename T, typename V>
struct index_of_an_alternative final {
    static constexpr const int value = -1;
};

template<typename T, typename... Ts>
struct index_of_an_alternative<T, std::variant<Ts...>> final {
    static constexpr const int value = idx_in_list<T, 0, Ts...>::value;
};

} // namespace detail

template<typename T, typename V>
struct index_of_an_alternative final {
    static constexpr const int value = detail::index_of_an_alternative<T, V>::value;
};

template<typename T, typename V>
static inline constexpr int index_of_an_alternative_v = index_of_an_alternative<T, V>::value;

} // namespace utils
