#pragma once

#include "ComplexTypeConstructor.h"
#include "Types.h"

#include "Mpi/Mpi.h"
#include "TaskGraphDistributors/Types.h"

#include <list>
#include <vector>
#include <memory>

namespace rts {
namespace comm {

class Communicator final {
public:
  Communicator(const TaskGraphDistribution& distr, std::size_t n_messages_to_receive, MPI_Comm comm);

public:
  template <typename P, typename R, typename S>
  void StartAndWaitAllMessagesReceived(P&& on_ready_message, R&& on_receive_mesasge, S&& serializer);

  void Send(ArrayKey array, SerializedMPIDataType& message, int dst_proc);

  void Send(ArrayKey array, const TaskArgument& var, SerializedMPIDataType& message);

  template <std::uint16_t N>
  int ProcCoordsToRank(const ProcessCoordinates<N>& coords);

  void Finalize() {}

  void Reset(std::size_t n_messages_to_receive);

  [[nodiscard]]
  ProcessCoordinates<2> get_proc_coords() const;

  [[nodiscard]]
  ProcessCoordinates<2> get_cart_size() const;

  [[nodiscard]]
  inline
  int rank() const noexcept {
    return rank_;
  }

  void barrier();

private:
  TaskGraphDistribution distr_;
  std::size_t n_messages_to_receive_;
  MPI_Comm comm_;
  int rank_;
};

void stop_comm_threads();

} // namespace comm
} // namespace rts

#include "Communicator.inl"
