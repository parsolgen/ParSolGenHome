#pragma once

#include "Mpi/Mpi.h"

#include <type_traits>
#include <utility>

namespace rts {
namespace comm {

template <typename T>
struct mpi_data_type final {};

template <>
struct mpi_data_type<int> final {
  static constexpr const MPI_Datatype value = MPI_INT;
};

template <>
struct mpi_data_type<unsigned long> final {
  static constexpr const MPI_Datatype value = MPI_UNSIGNED_LONG;
};

template <>
struct mpi_data_type<long> final {
  static constexpr const MPI_Datatype value = MPI_LONG;
};

template <>
struct mpi_data_type<float> final {
  static constexpr const MPI_Datatype value = MPI_FLOAT;
};

template <>
struct mpi_data_type<double> final {
  static constexpr const MPI_Datatype value = MPI_DOUBLE;
};

template <>
struct mpi_data_type<char> final {
  static constexpr const MPI_Datatype value = MPI_CHAR;
};

template <>
struct mpi_data_type<unsigned char> final {
  static constexpr const MPI_Datatype value = MPI_UNSIGNED_CHAR;
};

template <>
struct mpi_data_type<short> final {
  static constexpr const MPI_Datatype value = MPI_SHORT;
};

template <>
struct mpi_data_type<unsigned short> final {
  static constexpr const MPI_Datatype value = MPI_UNSIGNED_SHORT;
};

template <>
struct mpi_data_type<long long> final {
  static constexpr const MPI_Datatype value = MPI_LONG_LONG;
};

template <>
struct mpi_data_type<unsigned long long> final {
  static constexpr const MPI_Datatype value = MPI_UNSIGNED_LONG_LONG;
};

template <typename, typename = void>
struct is_convertable_to_mpi_type : std::false_type {};

template <typename T>
struct is_convertable_to_mpi_type<T, std::void_t<decltype(mpi_data_type<T>::value)>> : std::true_type {};

template <typename T>
struct StructElement final {
  using type = T;
  static_assert(is_convertable_to_mpi_type<T>::value, "Type must be convertable to elementary MNPI type");
  T* ptr;
  explicit StructElement(T* in_ptr);
};

template <typename T>
struct ContiguousArray final {
  using type = T;
  static_assert(is_convertable_to_mpi_type<T>::value, "Type must be convertable to elementary MNPI type");
  T* ptr;
  std::size_t size;
  ContiguousArray(T* in_ptr, std::size_t in_size);
};

template <typename T>
struct ArrayWithStride final {
  using type = T;
  static_assert(is_convertable_to_mpi_type<T>::value, "Type must be convertable to elementary MNPI type");
  T* ptr;
  std::size_t size;
  std::size_t block_size;
  std::size_t stride;
  ArrayWithStride(T* in_ptr, std::size_t in_size, std::size_t in_block_size, std::size_t ib_stride);
};

template <typename... Ts>
struct Struct final {
  using types = std::tuple<Ts...>;
  types values;

  explicit Struct(types values);
};

template <typename T>
struct is_mpi_struct final {
  static constexpr const bool value = false;
};

template <typename... Ts>
struct is_mpi_struct<Struct<Ts...>> final {
  static constexpr const bool value = true;
};

template <typename T>
inline static constexpr bool is_mpi_struct_v = is_mpi_struct<T>::value;

template <typename T>
struct is_mpi_struct_field_type {
  static constexpr const bool value = false;
};

template <typename T>
struct is_mpi_struct_field_type<ArrayWithStride<T>> {
  static constexpr const bool value = true;
};

template <typename T>
struct is_mpi_struct_field_type<ContiguousArray<T>> {
  static constexpr const bool value = true;
};

template <typename T>
struct is_mpi_struct_field_type<StructElement<T>> {
  static constexpr const bool value = true;
};

template <typename T>
inline static constexpr bool is_mpi_struct_field_type_v = is_mpi_struct_field_type<T>::value;

template <typename T1, typename T2>
struct StructsCat;

template <typename... Ts1, typename... Ts2>
struct StructsCat<Struct<Ts1...>, Struct<Ts2...>> {
  using type = Struct<Ts1..., Ts2...>;
};

using SerializedMPIDataType = std::pair<MPI_Datatype, void*>;

template <typename T>
SerializedMPIDataType construct_mpi_datatype(const T& type);

} // namespace comm
} // namespace rts

#include "ComplexTypeConstructor.inl"