#pragma once

#include "Utils/Hash.h"

#include <array>
#include <cstdint>

namespace rts {
namespace comm {

using ProcessCoord = int;

template <std::uint16_t N>
using ProcessCoordinates = std::array<int, N>;

} // namespace comm
} // namespace rts
